package controller;

import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.image.WritableImage;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.stage.Window;
import model.BarChartP_VO;
import model.BarChartVO;

public class ChartController implements Initializable {
// ���԰� ������ ���ε��� �̱�! �׳� ���λ̴°� ������ ���ϴ�!
	@FXML
	private BarChart barChart;
	@FXML
	private Button btnClose;

	ObservableList barList1 = FXCollections.observableArrayList();
	ObservableList barList2 = FXCollections.observableArrayList();
	ObservableList<BarChartVO> data = FXCollections.observableArrayList();
	ObservableList<BarChartP_VO> p_data = FXCollections.observableArrayList();

	long sum = 0;
	long p_sum = 0;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		try {
			bar_Purchase();
			bar_Sales();

			XYChart.Series series1 = new XYChart.Series();
			series1.setName("������");
			for (int i = 0; i < data.size(); i++) {
				sum = 0;
				for (int j = 0; j < data.size(); j++) {
					if (data.get(j).getBarS_Date().equals(data.get(i).getBarS_Date()))
						sum += data.get(j).getBarS_Sum();
				}
				barList1.add(new XYChart.Data(data.get(i).getBarS_Date() + "", sum));
			}
			series1.setData(barList1);
			barChart.getData().add(series1);

			XYChart.Series series2 = new XYChart.Series();
			series2.setName("������");
			for (int i = 0; i < p_data.size(); i++) {
				p_sum = 0;
				for (int j = 0; j < p_data.size(); j++) {
					if (p_data.get(j).getBar_Date().equals(p_data.get(i).getBar_Date()))
					p_sum += p_data.get(j).getBarP_Sum();
				}
				barList2.add(new XYChart.Data(p_data.get(i).getBar_Date() + "", p_sum));
			}

			series2.setData(barList2);
			barChart.getData().add(series2);
		} catch (Exception e) {
			System.out.println(e + "   0000");
		}

		btnClose.setOnAction(event -> btnCloseHandler(event));
	}

	public  void btnCloseHandler(ActionEvent event) {
		Stage oldstage = (Stage) btnClose.getScene().getWindow();
		
		oldstage.close();
	}

	public void bar_Sales() {
		try {

			ChartDAO dao = new ChartDAO();
			ArrayList<BarChartVO> list = new ArrayList<>();
			BarChartVO vo = null;
			list = dao.getSalesTotal(vo);
			int count = list.size();
			for (int i = 0; i < count; i++) {
				vo = list.get(i);
				data.addAll(vo);
			}
		} catch (Exception e) {

		}
	}

	public void bar_Purchase() {
		try {

			ChartDAO dao = new ChartDAO();
			ArrayList<BarChartP_VO> list = new ArrayList<>();
			BarChartP_VO vo = null;
			list = dao.getPurchaseTotal(vo);
			int count = list.size();
			for (int i = 0; i < count; i++) {
				vo = list.get(i);
				p_data.addAll(vo);
			}
		} catch (Exception e) {

		}
	}

}
