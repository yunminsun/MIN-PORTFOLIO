package controller;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import model.PurchaseVO;
import model.SalesVO;

public class PurchaseExcel {
	public boolean excelWiter(List<PurchaseVO> list, String saveDir) {

		// ��ũ�� ����
		XSSFWorkbook workbook = new XSSFWorkbook();
		// ��ũ��Ʈ ����
		XSSFSheet sheet = workbook.createSheet();
		// �� ����
		XSSFRow row = sheet.createRow(0);
		// �� ����
		XSSFCell cell;
		// ��� ���� ����
		// ��� ��������
		cell = row.createCell(0);
		cell.setCellValue("�����ȣ");
		cell = row.createCell(1);
		cell.setCellValue("�߱�����");
		cell = row.createCell(2);
		cell.setCellValue("����ڵ�Ϲ�ȣ");
		cell = row.createCell(3);
		cell.setCellValue("��ü��");
		cell = row.createCell(4);
		cell.setCellValue("��ǥ��");
		cell = row.createCell(5);
		cell.setCellValue("���ް���");
		cell = row.createCell(6);
		cell.setCellValue("����");
		cell = row.createCell(7);
		cell.setCellValue("�հ�ݾ�");
		cell = row.createCell(8);
		cell.setCellValue("ǰ��");
		cell = row.createCell(9);
		cell.setCellValue("�����");
		cell = row.createCell(10);
		cell.setCellValue("�ŷ�����");
		cell = row.createCell(11);
		cell.setCellValue("������");
		cell = row.createCell(12);
		cell.setCellValue("����");
		cell = row.createCell(13);
		cell.setCellValue("���ޱݾ�");
		cell = row.createCell(14);
		cell.setCellValue("�����ޱݾ�");
		cell = row.createCell(15);
		cell.setCellValue("����");
		cell = row.createCell(16);
		cell.setCellValue("���޿�����");
		cell = row.createCell(17);
		cell.setCellValue("����ó");
		cell = row.createCell(18);
		cell.setCellValue("����");
		cell = row.createCell(19);
		cell.setCellValue("���");
		cell = row.createCell(20);
		cell.setCellValue("1�� ��¥");
		cell = row.createCell(21);
		cell.setCellValue("��������");
		cell = row.createCell(22);
		cell.setCellValue("�Աݾ�");
		cell = row.createCell(23);
		cell.setCellValue("2�� ��¥");
		cell = row.createCell(24);
		cell.setCellValue("��������");
		cell = row.createCell(25);
		cell.setCellValue("�Աݾ�");
		cell = row.createCell(26);
		cell.setCellValue("3�� ��¥");
		cell = row.createCell(27);
		cell.setCellValue("��������");
		cell = row.createCell(28);
		cell.setCellValue("�Աݾ�");
		cell = row.createCell(29);
		cell.setCellValue("4�� ��¥");
		cell = row.createCell(30);
		cell.setCellValue("��������");
		cell = row.createCell(31);
		cell.setCellValue("�Աݾ�");
		cell = row.createCell(32);
		cell.setCellValue("5�� ��¥");
		cell = row.createCell(33);
		cell.setCellValue("��������");
		cell = row.createCell(34);
		cell.setCellValue("�Աݾ�");
		cell = row.createCell(35);
		cell.setCellValue("6�� ��¥");
		cell = row.createCell(36);
		cell.setCellValue("��������");
		cell = row.createCell(37);
		cell.setCellValue("�Աݾ�");
		cell = row.createCell(38);
		cell.setCellValue("7�� ��¥");
		cell = row.createCell(39);
		cell.setCellValue("��������");
		cell = row.createCell(40);
		cell.setCellValue("�Աݾ�");

		PurchaseVO vo;
		for (int rowldx = 0; rowldx < list.size(); rowldx++) {
			vo = list.get(rowldx);

			// �� ����
			row = sheet.createRow(rowldx + 1);

			cell = row.createCell(0);
			cell.setCellValue(vo.getNumber());
			cell = row.createCell(1);
			cell.setCellValue(vo.getDate());
			cell = row.createCell(2);
			cell.setCellValue(vo.getLicenseenumber());
			cell = row.createCell(3);
			cell.setCellValue(vo.getOwner());
			cell = row.createCell(4);
			cell.setCellValue(vo.getCompany());
			cell = row.createCell(5);
			cell.setCellValue(vo.getSupplyValue());
			cell = row.createCell(6);
			cell.setCellValue(vo.getTax());
			cell = row.createCell(7);
			cell.setCellValue(vo.getTotalmoney());
			cell = row.createCell(8);
			cell.setCellValue(vo.getItem());
			cell = row.createCell(9);
			cell.setCellValue(vo.getOnsite());
			cell = row.createCell(10);
			cell.setCellValue(vo.getTransactionaccount());
			cell = row.createCell(11);
			cell.setCellValue(vo.getAccountholder());
			cell = row.createCell(12);
			cell.setCellValue(vo.getBank());
			cell = row.createCell(13);
			cell.setCellValue(vo.getPayment());
			cell = row.createCell(14);
			cell.setCellValue(vo.getArrear());
			cell = row.createCell(15);
			cell.setCellValue(vo.getWhether());
			cell = row.createCell(16);
			cell.setCellValue(vo.getGivedate());
			cell = row.createCell(17);
			cell.setCellValue(vo.getContact());
			cell = row.createCell(18);
			cell.setCellValue(vo.getDivision());
			cell = row.createCell(19);
			cell.setCellValue(vo.getNote());
			cell = row.createCell(20);
			cell.setCellValue(vo.getDepositdate_One());
			cell = row.createCell(21);
			cell.setCellValue(vo.getReceipts_One());
			cell = row.createCell(22);
			cell.setCellValue(vo.getDeposit_One());
			cell = row.createCell(23);
			cell.setCellValue(vo.getDepositdate_Two());
			cell = row.createCell(24);
			cell.setCellValue(vo.getReceipts_Two());
			cell = row.createCell(25);
			cell.setCellValue(vo.getDeposit_Two());
			cell = row.createCell(26);
			cell.setCellValue(vo.getDepositdate_Three());
			cell = row.createCell(27);
			cell.setCellValue(vo.getReceipts_Three());
			cell = row.createCell(28);
			cell.setCellValue(vo.getDeposit_Three());
			cell = row.createCell(29);
			cell.setCellValue(vo.getDepositdate_Four());
			cell = row.createCell(30);
			cell.setCellValue(vo.getReceipts_Four());
			cell = row.createCell(31);
			cell.setCellValue(vo.getDeposit_Four());
			cell = row.createCell(32);
			cell.setCellValue(vo.getDepositdate_Five());
			cell = row.createCell(33);
			cell.setCellValue(vo.getReceipts_Five());
			cell = row.createCell(34);
			cell.setCellValue(vo.getDeposit_Five());
			cell = row.createCell(35);
			cell.setCellValue(vo.getDepositdate_Six());
			cell = row.createCell(36);
			cell.setCellValue(vo.getReceipts_Six());
			cell = row.createCell(37);
			cell.setCellValue(vo.getDeposit_Six());
			cell = row.createCell(38);
			cell.setCellValue(vo.getDepositdate_Seven());
			cell = row.createCell(39);
			cell.setCellValue(vo.getReceipts_Seven());
			cell = row.createCell(40);
			cell.setCellValue(vo.getDeposit_Seven());
		}
		// �Էµ� ���� ���Ϸ� ����
		String strReportPDFName = "Purchase_" + System.currentTimeMillis() + ".xlsx";
		File file = new File(saveDir + "\\" + strReportPDFName);
		FileOutputStream fileOutputStream = null;

		boolean saveSuccess = false;

		try {
			fileOutputStream = new FileOutputStream(file);
			if (fileOutputStream != null) {
				workbook.write(fileOutputStream);
				saveSuccess = true;
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (workbook != null)
					workbook.close();
				if (fileOutputStream != null)
					fileOutputStream.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		return saveSuccess;

	}
}
