package controller;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.text.DecimalFormat;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.DirectoryChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import model.PurchaseVO;
import model.SalesVO;
import controller.SalesDAO;
import controller.PurchaseDAO;

public class RootController implements Initializable {
	private Stage primaryStage ;
	// ����
	@FXML
	private TextField txtS_Date; // �߱�����
	@FXML
	private TextField txtS_Licenseenumber;// ����ڵ�Ϲ�ȣ
	@FXML
	private TextField txtS_Owner; // ��ǥ��
	@FXML
	private TextField txtS_Company; // ȸ���
	@FXML
	private TextField txtS_SupplyValue; // ���ް���
	@FXML
	private TextField txtS_Tax; // ����
	@FXML
	private TextField txtS_Totalmoney; // �հ�ݾ�
	@FXML
	private TextField txtS_Item; // ǰ��
	@FXML
	private TextField txtS_Onsite; // �����
	@FXML
	private TextField txtS_Collection; // ����
	@FXML
	private TextField txtS_Outstanding; // �̼���
	@FXML
	private TextField txtS_Duedate; // ���ݿ�����
	@FXML
	private TextField txtS_Contact; // ����ó
	@FXML
	private TextField txtS_Note; // ���
	@FXML
	private TextField txtS_Depositdate_One;// 1�� �Աݳ���
	@FXML
	private TextField txtS_Receipts_One;
	@FXML
	private TextField txtS_Deposit_One;
	@FXML
	private TextField txtS_Depositdate_Two;// 2�� �Աݳ���
	@FXML
	private TextField txtS_Receipts_Two;
	@FXML
	private TextField txtS_Deposit_Two;
	@FXML
	private TextField txtS_Depositdate_Three;// 3���Աݳ���
	@FXML
	private TextField txtS_Receipts_Three;
	@FXML
	private TextField txtS_Deposit_Three;
	@FXML
	private TextField txtS_Depositdate_Four;// 4���Աݳ���
	@FXML
	private TextField txtS_Receipts_Four;
	@FXML
	private TextField txtS_Deposit_Four;
	@FXML
	private TextField txtS_Depositdate_Five;// 5���Աݳ���
	@FXML
	private TextField txtS_Receipts_Five;
	@FXML
	private TextField txtS_Deposit_Five;
	@FXML
	private TextField txtS_Depositdate_Six;// 6���Աݳ���
	@FXML
	private TextField txtS_Receipts_Six;
	@FXML
	private TextField txtS_Deposit_Six;
	@FXML
	private TextField txtS_Depositdate_Seven;// 7���Աݳ���
	@FXML
	private TextField txtS_Receipts_Seven;
	@FXML
	private TextField txtS_Deposit_Seven;
	// ��ȸ
	@FXML
	private TextField txtS_SearchDate; // �߱�����
	@FXML
	private TextField txtS_SearchLicenseenumber; // ����ڵ�Ϲ�ȣ
	@FXML
	private TextField txtS_SearchCompany; // ȸ���
	@FXML
	private TextField txtS_SearchOwner; // ��ǥ��
	@FXML
	private TextField txtS_SearchOnsite; // �����
	// �հ�
	@FXML
	private TextField txtS_TotSupplyValue; // ���ް���
	@FXML
	private TextField txtS_TotTax; // ����
	@FXML
	private TextField txtS_TotTotalmoney; // �հ�ݾ�
	@FXML
	private TextField txtS_TotCollection; // ����
	@FXML
	private TextField txtS_TotOutstanding; // �̼���
	// ��ư
	@FXML
	private Button btnS_Tax; // ����Ȯ��
	@FXML
	private Button btnS_Totalmoney; // �հ�ݾ�Ȯ��
	@FXML
	private Button btnS_Ok; // ���
	@FXML
	private Button btnS_Modify; // ����
	@FXML
	private Button btnS_Init; // �ʱ�ȭ
	@FXML
	private Button btnS_Re_InputInit;// ����
	@FXML
	private Button btnS_Delete; // ����
	@FXML
	private Button btnS_Search; // ��ȸ
	@FXML
	private Button btnS_TotalList; // ��ü

	@FXML
	private TextField txtS_SaveFileDir; //�������� �н�
	@FXML
	private Button btnS_Excel;	//����
	@FXML
	private Button btnS_SaveFileDir; //���ϰ��
	@FXML
	private Button btnS_PDF;	//PDF
	
	@FXML
	private Button btnBarChart;
	// ���̺���
	@FXML
	private TableView<SalesVO> tableView_Sales = new TableView<>();
	// ������ �߻��� �ð��� ������ �� �ִ� ������ ������ �ϴ� list
	// list �����̶� ���ο� ����������,������ �߻��Ҷ����� ��ڵ带 �ڵ����� �����Ų��.
	ObservableList<SalesVO> dataSales = FXCollections.observableArrayList();
	// ���̺����� ������ ���� ����
	ObservableList<SalesVO> selectSales = null;

	SalesVO sales = new SalesVO();
	// ���̺����� ������ ���� �ε��� ����
	int selectedIndex_S;

	/************************************************************
	 * ���δ� ���� �Ʒ��δ� ����
	 ***********************************************************/

	@FXML
	private TextField txtP_Date; // �߱�����
	@FXML
	private TextField txtP_Licenseenumber; // ����ڵ�Ϲ�ȣ
	@FXML
	private TextField txtP_Owner; // ��ǥ��
	@FXML
	private TextField txtP_Company; // ��ü��
	@FXML
	private TextField txtP_SupplyValue; // ���ް���
	@FXML
	private TextField txtP_Tax; // ����
	@FXML
	private TextField txtP_Totalmoney; // �հ�ݾ�
	@FXML
	private TextField txtP_Item; // ǰ��
	@FXML
	private TextField txtP_Onsite; // �����
	@FXML
	private TextField txtP_Transactionaccount; // �ŷ�����
	@FXML
	private TextField txtP_Accountholder; // ������
	@FXML
	private TextField txtP_Bank; // ����
	@FXML
	private TextField txtP_Payment; // ���ޱݾ�
	@FXML
	private TextField txtP_Arrear; // �����ޱݾ�
	@FXML
	private ToggleGroup tgP_group; // ����
	@FXML
	private RadioButton rbP_Yeo; // ��
	@FXML
	private RadioButton rbP_Boo; // ��
	@FXML
	private RadioButton rbP_Gyeong; // ��
	@FXML
	private RadioButton rbP_No; // ��
	@FXML
	private TextField txtP_Givedate; // ���޿�����
	@FXML
	private TextField txtP_Contact; // ����ó
	@FXML
	private ComboBox<String> cbP_Division; // ����
	@FXML
	private TextField txtP_Note; // ���
	@FXML
	private TextField txtP_Depositdate_One; // 1�� �Ա�
	@FXML
	private TextField txtP_Receipts_One;
	@FXML
	private TextField txtP_Deposit_One;
	@FXML
	private TextField txtP_Depositdate_Two; // 2�� �Ա�
	@FXML
	private TextField txtP_Receipts_Two;
	@FXML
	private TextField txtP_Deposit_Two;
	@FXML
	private TextField txtP_Depositdate_Three; // 3�� �Ա�
	@FXML
	private TextField txtP_Receipts_Three;
	@FXML
	private TextField txtP_Deposit_Three;
	@FXML
	private TextField txtP_Depositdate_Four; // 4�� �Ա�
	@FXML
	private TextField txtP_Receipts_Four;
	@FXML
	private TextField txtP_Deposit_Four;
	@FXML
	private TextField txtP_Depositdate_Five; // 5�� �Ա�
	@FXML
	private TextField txtP_Receipts_Five;
	@FXML
	private TextField txtP_Deposit_Five;
	@FXML
	private TextField txtP_Depositdate_Six; // 6�� �Ա�
	@FXML
	private TextField txtP_Receipts_Six;
	@FXML
	private TextField txtP_Deposit_Six;
	@FXML
	private TextField txtP_Depositdate_Seven; // 7�� �Ա�
	@FXML
	private TextField txtP_Receipts_Seven;
	@FXML
	private TextField txtP_Deposit_Seven;

	@FXML
	private TextField txtP_SearchDate; // ��¥�˻�
	/* @FXML private TextField txtP_SearchLicenseenumber; */ // ��ȸ �������� �ʹ����Ƽ� ����.
	@FXML
	private TextField txtP_SearchCompany; // ��ü�� �˻� �Է�â
	@FXML
	private TextField txtP_SearchOwner; // ��ǥ�� �˻� �Է�â
	@FXML
	private TextField txtP_SearchOnsite; // ����� �˻� �Է�â
	@FXML
	private ToggleGroup tgP_SearchGroup; // ���� �˻� �Է�â
	@FXML
	private RadioButton rbP_SearchYeo; // ��
	@FXML
	private RadioButton rbP_SearchBoo; // ��
	@FXML
	private RadioButton rbP_SearchGyeong; // ��
	@FXML
	private RadioButton rbP_SearchNo; // ��
	@FXML
	private TextField txtP_SearchDivision; // ���� �˻� �Է�â
	@FXML
	private TextField txtP_TotSupplyValue; // �˻��� �� ���ް���
	@FXML
	private TextField txtP_TotTax; // �˻��� �� ����
	@FXML
	private TextField txtP_TotTotalmoney; // �˻��� �� �հ�ݾ�
	@FXML
	private TextField txtP_TotPayment; // �˻��� �� ���ޱݾ�
	@FXML
	private TextField txtP_TotArrear; // �˻��� �� �����ޱݾ�

	@FXML
	private Button btnP_Tax; // ���� ��� ��ư
	@FXML
	private Button btnP_Totalmoney; // �հ� ��� ��ư
	@FXML
	private Button btnP_Ok; // ��� ��ư
	@FXML
	private Button btnP_Modify; // ������ư
	@FXML
	private Button btnP_Init; // �ʱ�ȭ��ư
	@FXML
	private Button btnP_Re_InputInit; // �����ʱ�ȭ��ư
	@FXML
	private Button btnP_Delete; // ������ư
	@FXML
	private Button btnP_Search; // ��ȸ��ư
	@FXML
	private Button btnP_TotalList; // ��ü��� ��ư
	
	@FXML
	private TextField txtP_SaveFileDir; //�������� �н�
	@FXML
	private Button btnP_Excel;	//����
	@FXML
	private Button btnP_SaveFileDir; //���ϰ��
	@FXML
	private Button btnP_PDF;	//PDF

	@FXML
	private Button btnP_BarChart;
	@FXML
	private TableView<PurchaseVO> tableView_Purchase; // ������ ���̺���

	ObservableList<PurchaseVO> dataPurchase = FXCollections.observableArrayList();
	// ���̺����� ������ ���� ����
	ObservableList<PurchaseVO> selectPurchase = null;
	PurchaseVO purchase = new PurchaseVO();

	// ���̺����� ������ ���� �ε��� ����
	int selectedIndex_P;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// ó������ ����
		btnS_Ok.setDisable(true);
		btnS_Modify.setDisable(true);
		btnS_Re_InputInit.setDisable(true);
		btnS_Delete.setDisable(true);
		txtS_SupplyValue.setText(0 + "");
		txtS_Tax.setText(0 + "");
		txtS_Totalmoney.setText(0 + "");
		txtS_Collection.setText(0 + "");
		txtS_Outstanding.setText(0 + "");
		txtS_Deposit_One.setText(0 + "");
		txtS_Deposit_Two.setText(0 + "");
		txtS_Deposit_Three.setText(0 + "");
		txtS_Deposit_Four.setText(0 + "");
		txtS_Deposit_Five.setText(0 + "");
		txtS_Deposit_Six.setText(0 + "");
		txtS_Deposit_Seven.setText(0 + "");
		btnS_Excel.setDisable(true);
		btnS_PDF.setDisable(true);

		/**************************************************/
		// ó������ ����
		btnP_Ok.setDisable(true);
		btnP_Modify.setDisable(true);
		btnP_Re_InputInit.setDisable(true);
		btnP_Delete.setDisable(true);
		txtP_SupplyValue.setText(0 + "");
		txtP_Tax.setText(0 + "");
		txtP_Totalmoney.setText(0 + "");
		txtP_Payment.setText(0 + "");
		txtP_Arrear.setText(0 + "");
		txtP_Deposit_One.setText(0 + "");
		txtP_Deposit_Two.setText(0 + "");
		txtP_Deposit_Three.setText(0 + "");
		txtP_Deposit_Four.setText(0 + "");
		txtP_Deposit_Five.setText(0 + "");
		txtP_Deposit_Six.setText(0 + "");
		txtP_Deposit_Seven.setText(0 + "");
		btnP_Excel.setDisable(true);
		btnP_PDF.setDisable(true);
		/***************************************
		 * textFile �Է����ѱ�� ������ �ʵ帶�� �ʿ��Ѱ��� �־��־���.
		 * 
		 * �߱����ڴ� ��¥���Ŀ� �´� �Է¼� , ����ڹ�ȣ�� 10�ڸ������� �ֹε�Ϲ�ȣ�� �Է��Ҽ������� �װͱ������� ���ڸ� ����Ҽ��ְ� �ߴ�.
		 * �ݾ��̵������Ŀ� ������ ���ڸ� �Է� �����ϰ� ����ߴ�. Ž�� ���ĵ� ���������̴�.
		 ***************************************/

		DecimalFormat format = new DecimalFormat("#,###,###,###,###");
		// �߱����� �Է�����
		txtS_Date.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			ParsePosition parsePosition = new ParsePosition(0);
			Object object = format.parse(event.getControlNewText(), parsePosition);

			if (object == null || event.getControlNewText().length() >= 11) {
				return null;
			} else {
				return event;
			}
		}));
		// ����� �Է�����
		txtS_Licenseenumber.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			ParsePosition parsePosition = new ParsePosition(0);
			Object object = format.parse(event.getControlNewText(), parsePosition);

			if (object == null || event.getControlNewText().length() >= 15) {
				return null;
			} else {
				return event;
			}
		}));
		// ���ް��� ���ڸ��Է�
		txtS_SupplyValue.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			ParsePosition parsePosition = new ParsePosition(0);
			Object object = format.parse(event.getControlNewText(), parsePosition);

			if (object == null || parsePosition.getIndex() < event.getControlNewText().length()) {
				return null;
			} else {
				return event;
			}

		}));
		// ���� ���ڸ��Է�
		txtS_Tax.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			ParsePosition parsePosition = new ParsePosition(0);
			Object object = format.parse(event.getControlNewText(), parsePosition);

			if (object == null || parsePosition.getIndex() < event.getControlNewText().length()) {
				return null;
			} else {
				return event;
			}

		}));
		// �հ�ݾ� ���ڸ�
		txtS_Totalmoney.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			ParsePosition parsePosition = new ParsePosition(0);
			Object object = format.parse(event.getControlNewText(), parsePosition);

			if (object == null || parsePosition.getIndex() < event.getControlNewText().length()) {
				return null;
			} else {
				return event;
			}

		}));
		// �Աݾ� 1��~7��
		txtS_Deposit_One.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			ParsePosition parsePosition = new ParsePosition(0);
			Object object = format.parse(event.getControlNewText(), parsePosition);

			if (object == null || parsePosition.getIndex() < event.getControlNewText().length()) {
				return null;
			} else {
				return event;
			}

		}));
		txtS_Deposit_Two.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			ParsePosition parsePosition = new ParsePosition(0);
			Object object = format.parse(event.getControlNewText(), parsePosition);

			if (object == null || parsePosition.getIndex() < event.getControlNewText().length()) {
				return null;
			} else {
				return event;
			}

		}));
		txtS_Deposit_Three.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			ParsePosition parsePosition = new ParsePosition(0);
			Object object = format.parse(event.getControlNewText(), parsePosition);

			if (object == null || parsePosition.getIndex() < event.getControlNewText().length()) {
				return null;
			} else {
				return event;
			}

		}));
		txtS_Deposit_Four.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			ParsePosition parsePosition = new ParsePosition(0);
			Object object = format.parse(event.getControlNewText(), parsePosition);

			if (object == null || parsePosition.getIndex() < event.getControlNewText().length()) {
				return null;
			} else {
				return event;
			}

		}));
		txtS_Deposit_Five.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			ParsePosition parsePosition = new ParsePosition(0);
			Object object = format.parse(event.getControlNewText(), parsePosition);

			if (object == null || parsePosition.getIndex() < event.getControlNewText().length()) {
				return null;
			} else {
				return event;
			}

		}));
		txtS_Deposit_Six.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			ParsePosition parsePosition = new ParsePosition(0);
			Object object = format.parse(event.getControlNewText(), parsePosition);

			if (object == null || parsePosition.getIndex() < event.getControlNewText().length()) {
				return null;
			} else {
				return event;
			}

		}));
		txtS_Deposit_Seven.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			ParsePosition parsePosition = new ParsePosition(0);
			Object object = format.parse(event.getControlNewText(), parsePosition);

			if (object == null || parsePosition.getIndex() < event.getControlNewText().length()) {
				return null;
			} else {
				return event;
			}

		}));
		// ��¥ �˻����Ķ��� ���Ͱ���.
		txtS_SearchDate.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			ParsePosition parsePosition = new ParsePosition(0);
			Object object = format.parse(event.getControlNewText(), parsePosition);

			if (object == null || event.getControlNewText().length() >= 12) {
				return null;
			} else {
				return event;
			}

		}));
		txtS_SearchLicenseenumber.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			ParsePosition parsePosition = new ParsePosition(0);
			Object object = format.parse(event.getControlNewText(), parsePosition);

			if (object == null || event.getControlNewText().length() >= 13) {
				return null;
			} else {
				return event;
			}

		}));

		/*******************************************************
		 * �����Ѱ� ������ ���м�
		 *****************************************************/
		// �߱����� ���Ŀ� ���� 10�ڸ� �� ���ڸ� ���
		txtP_Date.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			ParsePosition parsePosition = new ParsePosition(0);
			Object object = format.parse(event.getControlNewText(), parsePosition);

			if (object == null || event.getControlNewText().length() >= 11) {
				return null;
			} else {
				return event;
			}
		}));
		// ����� ��Ϲ�ȣ ���Ŀ� ���� 10�ڸ� ������ �ֹε�Ϲ�ȣ�� �Է��Ҽ����־ 14�ڸ��� -�� ����Ͽ� 15�ڸ�
		txtP_Licenseenumber.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			ParsePosition parsePosition = new ParsePosition(0);
			Object object = format.parse(event.getControlNewText(), parsePosition);

			if (object == null || event.getControlNewText().length() >= 15) {
				return null;
			} else {
				return event;
			}
		}));
		// ���ڸ� ����ϴ� ���ް���
		txtP_SupplyValue.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			ParsePosition parsePosition = new ParsePosition(0);
			Object object = format.parse(event.getControlNewText(), parsePosition);

			if (object == null || parsePosition.getIndex() < event.getControlNewText().length()) {
				return null;
			} else {
				return event;
			}

		}));
		// ���ڸ� ����ϴ� ����
		txtP_Tax.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			ParsePosition parsePosition = new ParsePosition(0);
			Object object = format.parse(event.getControlNewText(), parsePosition);

			if (object == null || parsePosition.getIndex() < event.getControlNewText().length()) {
				return null;
			} else {
				return event;
			}

		}));
		// ���ڸ� ����ϴ� �հ�ݾ�
		txtP_Totalmoney.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			ParsePosition parsePosition = new ParsePosition(0);
			Object object = format.parse(event.getControlNewText(), parsePosition);

			if (object == null || parsePosition.getIndex() < event.getControlNewText().length()) {
				return null;
			} else {
				return event;
			}

		}));
		// ���ڸ� ����ϴ� ���ޱݾ�
		txtP_Payment.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			ParsePosition parsePosition = new ParsePosition(0);
			Object object = format.parse(event.getControlNewText(), parsePosition);

			if (object == null || parsePosition.getIndex() < event.getControlNewText().length()) {
				return null;
			} else {
				return event;
			}

		}));
		// ���ڸ� ����ϴ� �����ޱݾ�
		txtP_Arrear.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			ParsePosition parsePosition = new ParsePosition(0);
			Object object = format.parse(event.getControlNewText(), parsePosition);

			if (object == null || parsePosition.getIndex() < event.getControlNewText().length()) {
				return null;
			} else {
				return event;
			}

		}));
		// �Աݾ� 1��~7��
		txtP_Deposit_One.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			ParsePosition parsePosition = new ParsePosition(0);
			Object object = format.parse(event.getControlNewText(), parsePosition);

			if (object == null || parsePosition.getIndex() < event.getControlNewText().length()) {
				return null;
			} else {
				return event;
			}

		}));
		txtP_Deposit_Two.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			ParsePosition parsePosition = new ParsePosition(0);
			Object object = format.parse(event.getControlNewText(), parsePosition);

			if (object == null || parsePosition.getIndex() < event.getControlNewText().length()) {
				return null;
			} else {
				return event;
			}

		}));
		txtP_Deposit_Three.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			ParsePosition parsePosition = new ParsePosition(0);
			Object object = format.parse(event.getControlNewText(), parsePosition);

			if (object == null || parsePosition.getIndex() < event.getControlNewText().length()) {
				return null;
			} else {
				return event;
			}

		}));
		txtP_Deposit_Four.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			ParsePosition parsePosition = new ParsePosition(0);
			Object object = format.parse(event.getControlNewText(), parsePosition);

			if (object == null || parsePosition.getIndex() < event.getControlNewText().length()) {
				return null;
			} else {
				return event;
			}

		}));
		txtP_Deposit_Five.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			ParsePosition parsePosition = new ParsePosition(0);
			Object object = format.parse(event.getControlNewText(), parsePosition);

			if (object == null || parsePosition.getIndex() < event.getControlNewText().length()) {
				return null;
			} else {
				return event;
			}

		}));
		txtP_Deposit_Six.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			ParsePosition parsePosition = new ParsePosition(0);
			Object object = format.parse(event.getControlNewText(), parsePosition);

			if (object == null || parsePosition.getIndex() < event.getControlNewText().length()) {
				return null;
			} else {
				return event;
			}

		}));
		txtP_Deposit_Seven.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			ParsePosition parsePosition = new ParsePosition(0);
			Object object = format.parse(event.getControlNewText(), parsePosition);

			if (object == null || parsePosition.getIndex() < event.getControlNewText().length()) {
				return null;
			} else {
				return event;
			}

		}));
		txtP_SearchDate.setTextFormatter(new TextFormatter<>(event -> {
			if (event.getControlNewText().isEmpty()) {
				return event;
			}
			ParsePosition parsePosition = new ParsePosition(0);
			Object object = format.parse(event.getControlNewText(), parsePosition);

			if (object == null || event.getControlNewText().length() >= 12) {
				return null;
			} else {
				return event;
			}

		}));

		/*******************************************
		 * tableview �÷� �÷������� 36���̸� view �ܿ� �Ǿ� �÷��� �����ȣ�� ������ ��ȣ�̴�. �������� 1���� ���Ѵ�� �����Ѵ�.
		 * 
		 *******************************************/
		// ���� ���̺���
		tableView_Sales.setEditable(false);
		TableColumn colNumber = new TableColumn("�����ȣ");
		colNumber.setPrefWidth(60);
		colNumber.setCellValueFactory(new PropertyValueFactory<>("number"));
		TableColumn colDate = new TableColumn("�߱�����");
		colDate.setPrefWidth(80);
		colDate.setCellValueFactory(new PropertyValueFactory<>("date"));
		TableColumn colLicenseenumber = new TableColumn("����ڵ�Ϲ�ȣ");
		colLicenseenumber.setPrefWidth(80);
		colLicenseenumber.setCellValueFactory(new PropertyValueFactory<>("licenseenumber"));
		TableColumn colCompany = new TableColumn("��ü��");
		colCompany.setPrefWidth(80);
		colCompany.setCellValueFactory(new PropertyValueFactory<>("company"));
		TableColumn colOwner = new TableColumn("��ǥ��");
		colOwner.setPrefWidth(80);
		colOwner.setCellValueFactory(new PropertyValueFactory<>("owner"));
		TableColumn colSupplyValue = new TableColumn("���ް���");
		colSupplyValue.setPrefWidth(80);
		colSupplyValue.setCellValueFactory(new PropertyValueFactory<>("supplyValue"));
		TableColumn colTax = new TableColumn("��  ��");
		colTax.setPrefWidth(80);
		colTax.setCellValueFactory(new PropertyValueFactory<>("tax"));
		TableColumn colTotalmoney = new TableColumn("�հ�ݾ�");
		colTotalmoney.setPrefWidth(80);
		colTotalmoney.setCellValueFactory(new PropertyValueFactory<>("totalmoney"));
		TableColumn colItem = new TableColumn("ǰ  ��");
		colItem.setPrefWidth(80);
		colItem.setCellValueFactory(new PropertyValueFactory<>("item"));
		TableColumn colOnsite = new TableColumn("�����");
		colOnsite.setPrefWidth(80);
		colOnsite.setCellValueFactory(new PropertyValueFactory<>("onsite"));
		TableColumn colCollection = new TableColumn("���ݾ�");
		colCollection.setPrefWidth(80);
		colCollection.setCellValueFactory(new PropertyValueFactory<>("collection"));
		TableColumn colOutstanding = new TableColumn("�̼���");
		colOutstanding.setPrefWidth(80);
		colOutstanding.setCellValueFactory(new PropertyValueFactory<>("outstanding"));
		TableColumn colDuedate = new TableColumn("���ݿ�����");
		colDuedate.setPrefWidth(80);
		colDuedate.setCellValueFactory(new PropertyValueFactory<>("duedate"));
		TableColumn colContact = new TableColumn("����ó");
		colContact.setPrefWidth(80);
		colContact.setCellValueFactory(new PropertyValueFactory<>("contact"));
		TableColumn colNote = new TableColumn("���");
		colNote.setPrefWidth(80);
		colNote.setCellValueFactory(new PropertyValueFactory<>("note"));
		TableColumn colDepositdate_One = new TableColumn("1�� ��¥");
		colDepositdate_One.setPrefWidth(80);
		colDepositdate_One.setCellValueFactory(new PropertyValueFactory<>("depositdate_One"));
		TableColumn colReceipts_One = new TableColumn("��������");
		colReceipts_One.setPrefWidth(80);
		colReceipts_One.setCellValueFactory(new PropertyValueFactory<>("receipts_One"));
		TableColumn colDeposit_One = new TableColumn("�Աݾ�");
		colDeposit_One.setPrefWidth(80);
		colDeposit_One.setCellValueFactory(new PropertyValueFactory<>("deposit_One"));
		TableColumn colDepositdate_Two = new TableColumn("2�� ��¥");
		colDepositdate_Two.setPrefWidth(80);
		colDepositdate_Two.setCellValueFactory(new PropertyValueFactory<>("depositdate_Two"));
		TableColumn colReceipts_Two = new TableColumn("��������");
		colReceipts_Two.setPrefWidth(80);
		colReceipts_Two.setCellValueFactory(new PropertyValueFactory<>("receipts_Two"));
		TableColumn colDeposit_Two = new TableColumn("�Աݾ�");
		colDeposit_Two.setPrefWidth(80);
		colDeposit_Two.setCellValueFactory(new PropertyValueFactory<>("deposit_Two"));
		TableColumn colDepositdate_Three = new TableColumn("3�� ��¥");
		colDepositdate_Three.setPrefWidth(80);
		colDepositdate_Three.setCellValueFactory(new PropertyValueFactory<>("depositdate_Three"));
		TableColumn colReceipts_Three = new TableColumn("��������");
		colReceipts_Three.setPrefWidth(80);
		colReceipts_Three.setCellValueFactory(new PropertyValueFactory<>("receipts_Three"));
		TableColumn colDeposit_Three = new TableColumn("�Աݾ�");
		colDeposit_Three.setPrefWidth(80);
		colDeposit_Three.setCellValueFactory(new PropertyValueFactory<>("deposit_Three"));
		TableColumn colDepositdate_Four = new TableColumn("4�� ��¥");
		colDepositdate_Four.setPrefWidth(80);
		colDepositdate_Four.setCellValueFactory(new PropertyValueFactory<>("depositdate_Four"));
		TableColumn colReceipts_Four = new TableColumn("��������");
		colReceipts_Four.setPrefWidth(80);
		colReceipts_Four.setCellValueFactory(new PropertyValueFactory<>("receipts_Four"));
		TableColumn colDeposit_Four = new TableColumn("�Աݾ�");
		colDeposit_Four.setPrefWidth(80);
		colDeposit_Four.setCellValueFactory(new PropertyValueFactory<>("deposit_Four"));
		TableColumn colDepositdate_Five = new TableColumn("5�� ��¥");
		colDepositdate_Five.setPrefWidth(80);
		colDepositdate_Five.setCellValueFactory(new PropertyValueFactory<>("depositdate_Five"));
		TableColumn colReceipts_Five = new TableColumn("��������");
		colReceipts_Five.setPrefWidth(80);
		colReceipts_Five.setCellValueFactory(new PropertyValueFactory<>("receipts_Five"));
		TableColumn colDeposit_Five = new TableColumn("�Աݾ�");
		colDeposit_Five.setPrefWidth(80);
		colDeposit_Five.setCellValueFactory(new PropertyValueFactory<>("deposit_Five"));
		TableColumn colDepositdate_Six = new TableColumn("6�� ��¥");
		colDepositdate_Six.setPrefWidth(80);
		colDepositdate_Six.setCellValueFactory(new PropertyValueFactory<>("depositdate_Six"));
		TableColumn colReceipts_Six = new TableColumn("��������");
		colReceipts_Six.setPrefWidth(80);
		colReceipts_Six.setCellValueFactory(new PropertyValueFactory<>("receipts_Six"));
		TableColumn colDeposit_Six = new TableColumn("�Աݾ�");
		colDeposit_Six.setPrefWidth(80);
		colDeposit_Six.setCellValueFactory(new PropertyValueFactory<>("deposit_Six"));
		TableColumn colDepositdate_Seven = new TableColumn("7�� ��¥");
		colDepositdate_Seven.setPrefWidth(80);
		colDepositdate_Seven.setCellValueFactory(new PropertyValueFactory<>("depositdate_Seven"));
		TableColumn colReceipts_Seven = new TableColumn("��������");
		colReceipts_Seven.setPrefWidth(80);
		colReceipts_Seven.setCellValueFactory(new PropertyValueFactory<>("receipts_Seven"));
		TableColumn colDeposit_Seven = new TableColumn("�Աݾ�");
		colDeposit_Seven.setPrefWidth(80);
		colDeposit_Seven.setCellValueFactory(new PropertyValueFactory<>("deposit_Seven"));
		// SalesVO��ä�� ����ϰ�
		tableView_Sales.setItems(dataSales);
		// �� �÷��� ��ȯ�Ѵ�
		tableView_Sales.getColumns().addAll(colNumber, colDate, colLicenseenumber, colCompany, colOwner, colSupplyValue,
				colTax, colTotalmoney, colItem, colOnsite, colCollection, colOutstanding, colDuedate, colContact,
				colNote, colDepositdate_One, colReceipts_One, colDeposit_One, colDepositdate_Two, colReceipts_Two,
				colDeposit_Two, colDepositdate_Three, colReceipts_Three, colDeposit_Three, colDepositdate_Four,
				colReceipts_Four, colDeposit_Four, colDepositdate_Five, colReceipts_Five, colDeposit_Five,
				colDepositdate_Six, colReceipts_Six, colDeposit_Six, colDepositdate_Seven, colReceipts_Seven,
				colDeposit_Seven);
		// ù db ���� ���� ����� ��ó���� ����� ����ش�
		totalList();
		/***********************************************
		 * p_Tableview �÷� �÷������� 41���̸� view �ܿ� �Ǿ� �÷��� �����ȣ�� ������ ��ȣ�̴�. �������� 1���� ���Ѵ�� �����Ѵ�.
		 ***********************************************/
		tableView_Purchase.setEditable(false);
		// ������ ���ú���
		cbP_Division.setItems(FXCollections.observableArrayList("���ݰ�꼭(����)", "���԰�꼭(�����)", "�빫��", "���"));

		TableColumn colP_Number = new TableColumn("�����ȣ");
		colP_Number.setPrefWidth(60);
		colP_Number.setCellValueFactory(new PropertyValueFactory<>("number"));
		TableColumn colP_Date = new TableColumn("�߱�����");
		colP_Date.setPrefWidth(80);
		colP_Date.setCellValueFactory(new PropertyValueFactory<>("date"));
		TableColumn colP_Licenseenumber = new TableColumn("����ڵ�Ϲ�ȣ");
		colP_Licenseenumber.setPrefWidth(80);
		colP_Licenseenumber.setCellValueFactory(new PropertyValueFactory<>("licenseenumber"));
		TableColumn colP_Company = new TableColumn("��ü��");
		colP_Company.setPrefWidth(80);
		colP_Company.setCellValueFactory(new PropertyValueFactory<>("company"));
		TableColumn colP_Owner = new TableColumn("��ǥ��");
		colP_Owner.setPrefWidth(80);
		colP_Owner.setCellValueFactory(new PropertyValueFactory<>("owner"));
		TableColumn colP_SupplyValue = new TableColumn("���ް���");
		colP_SupplyValue.setPrefWidth(80);
		colP_SupplyValue.setCellValueFactory(new PropertyValueFactory<>("supplyValue"));
		TableColumn colP_Tax = new TableColumn("��  ��");
		colP_Tax.setPrefWidth(80);
		colP_Tax.setCellValueFactory(new PropertyValueFactory<>("tax"));
		TableColumn colP_Totalmoney = new TableColumn("�հ�ݾ�");
		colP_Totalmoney.setPrefWidth(80);
		colP_Totalmoney.setCellValueFactory(new PropertyValueFactory<>("totalmoney"));
		TableColumn colP_Item = new TableColumn("ǰ  ��");
		colP_Item.setPrefWidth(80);
		colP_Item.setCellValueFactory(new PropertyValueFactory<>("item"));
		TableColumn colP_Onsite = new TableColumn("�����");
		colP_Onsite.setPrefWidth(80);
		colP_Onsite.setCellValueFactory(new PropertyValueFactory<>("onsite"));

		TableColumn colP_Transactionaccount = new TableColumn("�ŷ�����");
		colP_Transactionaccount.setPrefWidth(80);
		colP_Transactionaccount.setCellValueFactory(new PropertyValueFactory<>("transactionaccount"));
		TableColumn colP_Accountholder = new TableColumn("������");
		colP_Accountholder.setPrefWidth(80);
		colP_Accountholder.setCellValueFactory(new PropertyValueFactory<>("accountholder"));
		TableColumn colP_Bank = new TableColumn("����");
		colP_Bank.setPrefWidth(80);
		colP_Bank.setCellValueFactory(new PropertyValueFactory<>("bank"));
		TableColumn colP_Payment = new TableColumn("���ޱݾ�");
		colP_Payment.setPrefWidth(80);
		colP_Payment.setCellValueFactory(new PropertyValueFactory<>("payment"));
		TableColumn colP_Arrear = new TableColumn("�����ޱݾ�");
		colP_Arrear.setPrefWidth(80);
		colP_Arrear.setCellValueFactory(new PropertyValueFactory<>("arrear"));
		TableColumn colP_Whether = new TableColumn("����");
		colP_Whether.setPrefWidth(80);
		colP_Whether.setCellValueFactory(new PropertyValueFactory<>("whether"));
		TableColumn colP_Givedate = new TableColumn("���޿�����");
		colP_Givedate.setPrefWidth(80);
		colP_Givedate.setCellValueFactory(new PropertyValueFactory<>("givedate"));
		TableColumn colP_Contact = new TableColumn("����ó");
		colP_Contact.setPrefWidth(80);
		colP_Contact.setCellValueFactory(new PropertyValueFactory<>("contact"));
		TableColumn colP_Division = new TableColumn("����");
		colP_Division.setPrefWidth(80);
		colP_Division.setCellValueFactory(new PropertyValueFactory<>("division"));
		TableColumn colP_Note = new TableColumn("���");
		colP_Note.setPrefWidth(80);
		colP_Note.setCellValueFactory(new PropertyValueFactory<>("note"));
		TableColumn colP_Depositdate_One = new TableColumn("1�� ��¥");
		colP_Depositdate_One.setPrefWidth(80);
		colP_Depositdate_One.setCellValueFactory(new PropertyValueFactory<>("depositdate_One"));
		TableColumn colP_Receipts_One = new TableColumn("��������");
		colP_Receipts_One.setPrefWidth(80);
		colP_Receipts_One.setCellValueFactory(new PropertyValueFactory<>("receipts_One"));
		TableColumn colP_Deposit_One = new TableColumn("�Աݾ�");
		colP_Deposit_One.setPrefWidth(80);
		colP_Deposit_One.setCellValueFactory(new PropertyValueFactory<>("deposit_One"));
		TableColumn colP_Depositdate_Two = new TableColumn("2�� ��¥");
		colP_Depositdate_Two.setPrefWidth(80);
		colP_Depositdate_Two.setCellValueFactory(new PropertyValueFactory<>("depositdate_Two"));
		TableColumn colP_Receipts_Two = new TableColumn("��������");
		colP_Receipts_Two.setPrefWidth(80);
		colP_Receipts_Two.setCellValueFactory(new PropertyValueFactory<>("receipts_Two"));
		TableColumn colP_Deposit_Two = new TableColumn("�Աݾ�");
		colP_Deposit_Two.setPrefWidth(80);
		colP_Deposit_Two.setCellValueFactory(new PropertyValueFactory<>("deposit_Two"));
		TableColumn colP_Depositdate_Three = new TableColumn("3�� ��¥");
		colP_Depositdate_Three.setPrefWidth(80);
		colP_Depositdate_Three.setCellValueFactory(new PropertyValueFactory<>("depositdate_Three"));
		TableColumn colP_Receipts_Three = new TableColumn("��������");
		colP_Receipts_Three.setPrefWidth(80);
		colP_Receipts_Three.setCellValueFactory(new PropertyValueFactory<>("receipts_Three"));
		TableColumn colP_Deposit_Three = new TableColumn("�Աݾ�");
		colP_Deposit_Three.setPrefWidth(80);
		colP_Deposit_Three.setCellValueFactory(new PropertyValueFactory<>("deposit_Three"));
		TableColumn colP_Depositdate_Four = new TableColumn("4�� ��¥");
		colP_Depositdate_Four.setPrefWidth(80);
		colP_Depositdate_Four.setCellValueFactory(new PropertyValueFactory<>("depositdate_Four"));
		TableColumn colP_Receipts_Four = new TableColumn("��������");
		colP_Receipts_Four.setPrefWidth(80);
		colP_Receipts_Four.setCellValueFactory(new PropertyValueFactory<>("receipts_Four"));
		TableColumn colP_Deposit_Four = new TableColumn("�Աݾ�");
		colP_Deposit_Four.setPrefWidth(80);
		colP_Deposit_Four.setCellValueFactory(new PropertyValueFactory<>("deposit_Four"));
		TableColumn colP_Depositdate_Five = new TableColumn("5�� ��¥");
		colP_Depositdate_Five.setPrefWidth(80);
		colP_Depositdate_Five.setCellValueFactory(new PropertyValueFactory<>("depositdate_Five"));
		TableColumn colP_Receipts_Five = new TableColumn("��������");
		colP_Receipts_Five.setPrefWidth(80);
		colP_Receipts_Five.setCellValueFactory(new PropertyValueFactory<>("receipts_Five"));
		TableColumn colP_Deposit_Five = new TableColumn("�Աݾ�");
		colP_Deposit_Five.setPrefWidth(80);
		colP_Deposit_Five.setCellValueFactory(new PropertyValueFactory<>("deposit_Five"));
		TableColumn colP_Depositdate_Six = new TableColumn("6�� ��¥");
		colP_Depositdate_Six.setPrefWidth(80);
		colP_Depositdate_Six.setCellValueFactory(new PropertyValueFactory<>("depositdate_Six"));
		TableColumn colP_Receipts_Six = new TableColumn("��������");
		colP_Receipts_Six.setPrefWidth(80);
		colP_Receipts_Six.setCellValueFactory(new PropertyValueFactory<>("receipts_Six"));
		TableColumn colP_Deposit_Six = new TableColumn("�Աݾ�");
		colP_Deposit_Six.setPrefWidth(80);
		colP_Deposit_Six.setCellValueFactory(new PropertyValueFactory<>("deposit_Six"));
		TableColumn colP_Depositdate_Seven = new TableColumn("7�� ��¥");
		colP_Depositdate_Seven.setPrefWidth(80);
		colP_Depositdate_Seven.setCellValueFactory(new PropertyValueFactory<>("depositdate_Seven"));
		TableColumn colP_Receipts_Seven = new TableColumn("��������");
		colP_Receipts_Seven.setPrefWidth(80);
		colP_Receipts_Seven.setCellValueFactory(new PropertyValueFactory<>("receipts_Seven"));
		TableColumn colP_Deposit_Seven = new TableColumn("�Աݾ�");
		colP_Deposit_Seven.setPrefWidth(80);
		colP_Deposit_Seven.setCellValueFactory(new PropertyValueFactory<>("deposit_Seven"));

		tableView_Purchase.setItems(dataPurchase);
		//
		tableView_Purchase.getColumns().addAll(colP_Number, colP_Date, colP_Licenseenumber, colP_Company, colP_Owner,
				colP_SupplyValue, colP_Tax, colP_Totalmoney, colP_Item, colP_Onsite, colP_Transactionaccount,
				colP_Accountholder, colP_Bank, colP_Payment, colP_Arrear, colP_Whether, colP_Givedate, colP_Contact,
				colP_Division, colP_Note, colP_Depositdate_One, colP_Receipts_One, colP_Deposit_One,
				colP_Depositdate_Two, colP_Receipts_Two, colP_Deposit_Two, colP_Depositdate_Three, colP_Receipts_Three,
				colP_Deposit_Three, colP_Depositdate_Four, colP_Receipts_Four, colP_Deposit_Four, colP_Depositdate_Five,
				colP_Receipts_Five, colP_Deposit_Five, colP_Depositdate_Six, colP_Receipts_Six, colP_Deposit_Six,
				colP_Depositdate_Seven, colP_Receipts_Seven, colP_Deposit_Seven);

		p_TotalList();

		/***********************
		 * ������ �ܰ� ��ư���� ����. ��ư ok�� ����ϴ� ��ư�̴�. �����ȣ �ܿ� ���� �Է½��״�. �� , ���ܰ� ����.
		 **********************/

		btnS_Ok.setOnAction(event -> {
			try {

				SalesVO salesVO = null;
				SalesDAO salesDAO = new SalesDAO();
				// ���� �ڸ��� ���Ѱ� �ΰ��϶� �Է� �Ұ� â ����ֱ�
				// ������ not null�� �����̴�. �� �Է��� �ʿ��Ѱ��� �Է¹޴´�.
				if (txtS_Date.getText().trim().length() == 10 && txtS_Licenseenumber.getText().length() >= 10
						&& txtS_Company.getText().length() > 0 && txtS_Owner.getText().length() > 0
						&& txtS_SupplyValue.getText().length() > 0 && txtS_Totalmoney.getText().length() > 0
						&& txtS_Onsite.getText().length() > 0) {

					// �� �����ڿ� ����Է����Ѵ�,
					salesVO = new SalesVO(txtS_Date.getText().trim(), txtS_Licenseenumber.getText().trim(), txtS_Company.getText().trim(),
							txtS_Owner.getText().trim(), Long.parseLong(txtS_SupplyValue.getText().trim()),
							Long.parseLong(txtS_Tax.getText().trim()), Long.parseLong(txtS_Totalmoney.getText().trim()),
							txtS_Item.getText().trim(), txtS_Onsite.getText().trim(), Long.parseLong(txtS_Collection.getText().trim()),
							Long.parseLong(txtS_Outstanding.getText().trim()), txtS_Duedate.getText().trim(), txtS_Contact.getText().trim(),
							txtS_Note.getText().trim(), txtS_Depositdate_One.getText().trim(), txtS_Receipts_One.getText().trim(),
							Long.parseLong(txtS_Deposit_One.getText().trim()), txtS_Depositdate_Two.getText().trim(),
							txtS_Receipts_Two.getText().trim(), Long.parseLong(txtS_Deposit_Two.getText().trim()),
							txtS_Depositdate_Three.getText().trim(), txtS_Receipts_Three.getText().trim(),
							Long.parseLong(txtS_Deposit_Three.getText().trim()), txtS_Depositdate_Four.getText().trim(),
							txtS_Receipts_Four.getText().trim(), Long.parseLong(txtS_Deposit_Four.getText().trim()),
							txtS_Depositdate_Five.getText().trim(), txtS_Receipts_Five.getText().trim(),
							Long.parseLong(txtS_Deposit_Five.getText().trim()), txtS_Depositdate_Six.getText().trim(),
							txtS_Receipts_Six.getText().trim(), Long.parseLong(txtS_Deposit_Six.getText().trim()),
							txtS_Depositdate_Seven.getText().trim(), txtS_Receipts_Seven.getText().trim(),
							Long.parseLong(txtS_Deposit_Seven.getText().trim()));
					//�Է��Ѱ��� �����ͺ��̽��� �Է��Ѵ�.
					salesDAO.getSalesRegister(salesVO);
					//�������ִ� ���� ��� ���ְ� ���ο� ���� �޽��ϴ�.
					dataSales.removeAll(dataSales);
					dataSales.add(salesVO);

					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("���� �Է�");
					alert.setHeaderText(txtS_Company.getText() + " ������ ���������� �߰��Ǿ����ϴ�.");
					alert.showAndWait();
					dataSales.removeAll(dataSales);
					totalList();
					handleBtnS_Init(event);
				} else {
					//��ȸ���� �ʼ������� �˻��ϵ��� �߽��ϴ�.
					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("���� ����!");
					alert.setHeaderText("���� �Է��� �����߽��ϴ�.");
					alert.setContentText(
							"�߱�����, ����ڵ�Ϲ�ȣ, ��ǥ��, ��ü��, ���ް���, ����� �� �ʼ��� �Է��ؾ��մϴ�. \n��¥ �Է� ������ ex) 1983-02-06 �Դϴ�");
					alert.showAndWait();

				}

			} catch (Exception e) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("���� �Է� ����");
				alert.setHeaderText("������ ��Ȯ�� �Է��Ͻÿ�.");
				alert.setContentText("�������� �����ϼ���!");
				alert.showAndWait();
			}

		});
		// ���� ��Ϲ�ư
		btnP_Ok.setOnAction(event -> {
			PurchaseVO purchaseVO = null;
			PurchaseDAO purchaseDAO = new PurchaseDAO();

			try {

				if (txtP_Date.getText().trim().length() == 10 && txtP_Licenseenumber.getText().trim().length() >= 10
						&& !txtP_Company.getText().trim().equals("") && !txtP_Owner.getText().trim().equals("")
						&& !txtP_Onsite.getText().trim().equals("")
						&& !tgP_group.getSelectedToggle().getUserData().toString().trim().equals("")
						&& !cbP_Division.getSelectionModel().getSelectedItem().equals("")) {

					purchaseVO = new PurchaseVO(txtP_Date.getText().trim(), txtP_Licenseenumber.getText().trim(),
							txtP_Company.getText().trim(), txtP_Owner.getText().trim(),
							Long.parseLong(txtP_SupplyValue.getText().trim()),
							Long.parseLong(txtP_Tax.getText().trim()), Long.parseLong(txtP_Totalmoney.getText().trim()),
							txtP_Item.getText().trim(), txtP_Onsite.getText().trim(),
							txtP_Transactionaccount.getText().trim(), txtP_Accountholder.getText().trim(),
							txtP_Bank.getText().trim(), Long.parseLong(txtP_Payment.getText().trim()),
							Long.parseLong(txtP_Arrear.getText().trim()),
							tgP_group.getSelectedToggle().getUserData().toString(), txtP_Givedate.getText().trim(),
							txtP_Contact.getText().trim(), cbP_Division.getSelectionModel().getSelectedItem(),
							txtP_Note.getText().trim(), txtP_Depositdate_One.getText().trim(),
							txtP_Receipts_One.getText().trim(), Long.parseLong(txtP_Deposit_One.getText().trim()),
							txtP_Depositdate_Two.getText().trim(), txtP_Receipts_Two.getText().trim(),
							Long.parseLong(txtP_Deposit_Two.getText().trim()), txtP_Depositdate_Three.getText().trim(),
							txtP_Receipts_Three.getText().trim(), Long.parseLong(txtP_Deposit_Three.getText().trim()),
							txtP_Depositdate_Four.getText().trim(), txtP_Receipts_Four.getText().trim(),
							Long.parseLong(txtP_Deposit_Four.getText().trim()), txtP_Depositdate_Five.getText().trim(),
							txtP_Receipts_Five.getText().trim(), Long.parseLong(txtP_Deposit_Five.getText().trim()),
							txtP_Depositdate_Six.getText().trim(), txtP_Receipts_Six.getText().trim(),
							Long.parseLong(txtP_Deposit_Six.getText().trim()), txtP_Depositdate_Seven.getText().trim(),
							txtP_Receipts_Seven.getText().trim(), Long.parseLong(txtP_Deposit_Seven.getText().trim()));

					purchaseDAO.getPurchaseRegister(purchaseVO);
					dataPurchase.removeAll(dataPurchase);
					dataPurchase.add(purchaseVO);

					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("���� �Է�");
					alert.setHeaderText(txtS_Company.getText() + " ������ ���������� �߰��Ǿ����ϴ�.");
					alert.showAndWait();
					dataPurchase.removeAll(dataPurchase);

					p_TotalList();
					// ���� ����� ���� ����.
					handleBtnP_Init(event);
				} else {
					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("���� �Է� ����!");
					alert.setHeaderText("���� �Է��� �����߽��ϴ�.");
					alert.setContentText("�߱�����, ����ڵ�Ϲ�ȣ, ��ǥ��, ��ü��, ���ް���, �����, ����, ���� ��/�� �ʼ��� �Է� �Ǵ� ���� �ؾ��մϴ�."
							+ " \n��¥ �Է� ������ ex) 1983-02-06 �Դϴ�.");
					alert.showAndWait();

				}
			} catch (Exception e) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("���� �Է� ����");
				alert.setHeaderText("������ ��Ȯ�� �Է��Ͻÿ�.");
				alert.setContentText("�������� �����ϼ���!");
				alert.showAndWait();
			}

		});

		// ���� ��� �ڵ� 10%
		// ���� ����� �������̹Ƿ� �����Էµ� �����ϴ�.
		btnS_Tax.setOnAction(event -> {
			long tax = (long) (Long.parseLong(txtS_SupplyValue.getText()) * 0.1);
			txtS_Tax.setText(tax + "");

		});
		btnP_Tax.setOnAction(event -> {
			long tax = (long) (Long.parseLong(txtP_SupplyValue.getText()) * 0.1);
			txtP_Tax.setText(tax + "");
		});

		// �հ��� Ŭ���� ���ް��� ���� �ձݾ��̳����� �Աݾ��� ���� ���ݾ��̵ǰ� �ձݾ� - ���ݾ� = �̼���
		btnS_Totalmoney.setOnAction(event -> {
			// 1��~7�� �Աݾ� ��
			long one = Long.parseLong(txtS_Deposit_One.getText());
			long two = Long.parseLong(txtS_Deposit_Two.getText());
			long three = Long.parseLong(txtS_Deposit_Three.getText());
			long four = Long.parseLong(txtS_Deposit_Four.getText());
			long five = Long.parseLong(txtS_Deposit_Five.getText());
			long six = Long.parseLong(txtS_Deposit_Six.getText());
			long seven = Long.parseLong(txtS_Deposit_Seven.getText());

			long collection = one + two + three + four + five + six + seven;

			long totalmoney = Long.parseLong(txtS_SupplyValue.getText()) + Long.parseLong(txtS_Tax.getText());

			txtS_Totalmoney.setText(totalmoney + "");
			txtS_Collection.setText(collection + "");

			long outstanding = Long.parseLong(txtS_Totalmoney.getText()) - Long.parseLong(txtS_Collection.getText());
			txtS_Outstanding.setText(outstanding + "");
			// ����� ������ ����� �ǵ��� �ߴµ�. ���̺��信 �������ߴٸ� ������ ���������ߴٸ� ����� �ϵ��� �����ߴ�.
			if (selectSales == null) {
				btnS_Ok.setDisable(false);
			} else {
				btnS_Modify.setDisable(false);
			}
			/* btnS_Tax.setDisable(true); */
		});
		btnP_Totalmoney.setOnAction(event -> {
			long one = Long.parseLong(txtP_Deposit_One.getText());
			long two = Long.parseLong(txtP_Deposit_Two.getText());
			long three = Long.parseLong(txtP_Deposit_Three.getText());
			long four = Long.parseLong(txtP_Deposit_Four.getText());
			long five = Long.parseLong(txtP_Deposit_Five.getText());
			long six = Long.parseLong(txtP_Deposit_Six.getText());
			long seven = Long.parseLong(txtP_Deposit_Seven.getText());

			long payment = one + two + three + four + five + six + seven;

			long totalmoney = Long.parseLong(txtP_SupplyValue.getText()) + Long.parseLong(txtP_Tax.getText());

			txtP_Totalmoney.setText(totalmoney + "");
			txtP_Payment.setText(payment + "");

			long arrear = Long.parseLong(txtP_Totalmoney.getText()) - Long.parseLong(txtP_Payment.getText());
			txtP_Arrear.setText(arrear + "");
			// ����ư Ŭ���� �������϶� ������ư�� ������ ���ߴٸ� ��Ϲ�ư�� Ų��
			if (selectPurchase == null) {
				btnP_Ok.setDisable(false);
			} else {
				btnP_Modify.setDisable(false);
			}
		});

		// �ʱ�ȭ ��ư
		btnS_Init.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				handleBtnS_Init(event);
			}
		});
		btnP_Init.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				handleBtnP_Init(event);

			}

		});
		// ���� ��ư
		btnS_Modify.setOnAction(event -> {

			SalesVO salesVO = null;
			SalesDAO salesDAO = null;

			try {
				// ���� �ڸ��� ���Ѱ� �ΰ��϶� �Է� �Ұ� â ����ֱ�
				if (txtS_Date.getText().trim().length() == 10 && txtS_Licenseenumber.getText().length() > 0
						&& txtS_Company.getText().length() > 0 && txtS_Owner.getText().length() > 0
						&& txtS_SupplyValue.getText().length() > 0 && txtS_Totalmoney.getText().length() > 0
						&& txtS_Onsite.getText().length() > 0) {
					// �Է� ������ ���
					salesVO = new SalesVO(txtS_Date.getText(), txtS_Licenseenumber.getText(), txtS_Company.getText(),
							txtS_Owner.getText(), Long.parseLong(txtS_SupplyValue.getText()),
							Long.parseLong(txtS_Tax.getText()), Long.parseLong(txtS_Totalmoney.getText()),
							txtS_Item.getText(), txtS_Onsite.getText(), Long.parseLong(txtS_Collection.getText()),
							Long.parseLong(txtS_Outstanding.getText()), txtS_Duedate.getText(), txtS_Contact.getText(),
							txtS_Note.getText(), txtS_Depositdate_One.getText(), txtS_Receipts_One.getText(),
							Long.parseLong(txtS_Deposit_One.getText()), txtS_Depositdate_Two.getText(),
							txtS_Receipts_Two.getText(), Long.parseLong(txtS_Deposit_Two.getText()),
							txtS_Depositdate_Three.getText(), txtS_Receipts_Three.getText(),
							Long.parseLong(txtS_Deposit_Three.getText()), txtS_Depositdate_Four.getText(),
							txtS_Receipts_Four.getText(), Long.parseLong(txtS_Deposit_Four.getText()),
							txtS_Depositdate_Five.getText(), txtS_Receipts_Five.getText(),
							Long.parseLong(txtS_Deposit_Five.getText()), txtS_Depositdate_Six.getText(),
							txtS_Receipts_Six.getText(), Long.parseLong(txtS_Deposit_Six.getText()),
							txtS_Depositdate_Seven.getText(), txtS_Receipts_Seven.getText(),
							Long.parseLong(txtS_Deposit_Seven.getText()));
					// ���� ����� ���������� ����ش�.
					dataSales.removeAll(dataSales);
					dataSales.add(salesVO);

					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("���� ����");
					alert.setHeaderText(txtS_Company.getText() + " ������ ���������� �����Ǿ����ϴ�.");
					alert.showAndWait();
					// �ʱ�ȭ �޼�Ʈ
					handleBtnS_Init(event);

					salesDAO = new SalesDAO();
					// ���� ���� ��������ȣ�� �״��.
					salesDAO.getSalesUpdate(salesVO, selectedIndex_S);
					dataSales.removeAll(dataSales);
					totalList();
				} else {

					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("���� ���� ����!");
					alert.setHeaderText("���� ������ �����߽��ϴ�.");
					alert.setContentText(
							"�߱�����, ����ڵ�Ϲ�ȣ, ��ǥ��, ��ü��, �հ�ݾ�, ����� �� �ʼ��� �Է��ؾ��մϴ�. \n��¥ �Է� ������ ex) 1983/02/06 �Դϴ�");
					alert.showAndWait();

				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		});

		btnP_Modify.setOnAction(event -> {

			PurchaseVO purchaseVO = null;
			PurchaseDAO purchaseDAO = null;

			try {
				// �Է� ������ ���

				// ���� ���� givedate ������
				if (txtP_Date.getText().trim().length() == 10 && txtP_Licenseenumber.getText().trim().length() >= 10
						&& !txtP_Company.getText().trim().equals("") && !txtP_Owner.getText().trim().equals("")
						&& !txtP_Onsite.getText().trim().equals("")
						&& !tgP_group.getSelectedToggle().getUserData().toString().equals("")
						&& !cbP_Division.getSelectionModel().getSelectedItem().equals("")) {
					purchaseVO = new PurchaseVO(txtP_Date.getText(), txtP_Licenseenumber.getText(),
							txtP_Company.getText(), txtP_Owner.getText(),
							Long.parseLong(txtP_SupplyValue.getText()),
							Long.parseLong(txtP_Tax.getText()), Long.parseLong(txtP_Totalmoney.getText()),
							txtP_Item.getText(), txtP_Onsite.getText(),
							txtP_Transactionaccount.getText(), txtP_Accountholder.getText(),
							txtP_Bank.getText(), Long.parseLong(txtP_Payment.getText()),
							Long.parseLong(txtP_Arrear.getText()),
							tgP_group.getSelectedToggle().getUserData().toString(), txtP_Givedate.getText(),
							txtP_Contact.getText(), cbP_Division.getSelectionModel().getSelectedItem(),
							txtP_Note.getText(), txtP_Depositdate_One.getText(),
							txtP_Receipts_One.getText(), Long.parseLong(txtP_Deposit_One.getText()),
							txtP_Depositdate_Two.getText(), txtP_Receipts_Two.getText(),
							Long.parseLong(txtP_Deposit_Two.getText()), txtP_Depositdate_Three.getText(),
							txtP_Receipts_Three.getText(), Long.parseLong(txtP_Deposit_Three.getText()),
							txtP_Depositdate_Four.getText(), txtP_Receipts_Four.getText(),
							Long.parseLong(txtP_Deposit_Four.getText()), txtP_Depositdate_Five.getText(),
							txtP_Receipts_Five.getText(), Long.parseLong(txtP_Deposit_Five.getText()),
							txtP_Depositdate_Six.getText(), txtP_Receipts_Six.getText(),
							Long.parseLong(txtP_Deposit_Six.getText()), txtP_Depositdate_Seven.getText(),
							txtP_Receipts_Seven.getText(), Long.parseLong(txtP_Deposit_Seven.getText()));
					dataPurchase.removeAll(dataPurchase);
					dataPurchase.add(purchaseVO);
					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("���� ����");
					alert.setHeaderText(txtP_Company.getText() + " ������ ���������� �����Ǿ����ϴ�.");
					alert.showAndWait();
					purchaseDAO = new PurchaseDAO();
					purchaseDAO.getPurchaseUpdate(purchaseVO, selectedIndex_P);
					dataPurchase.removeAll(dataPurchase);
					p_TotalList();
					// ���� ����� ���� ����.
					handleBtnP_Init(event);

				} else {
					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("���� ���� ����!");
					alert.setHeaderText("������ ���� �Է��� �����߽��ϴ�.");
					alert.setContentText("�߱�����, ����ڵ�Ϲ�ȣ, ��ǥ��, ��ü��, �����, ����, ���� ��/�� �ʼ��� �Է� �Ǵ� ���� �ؾ��մϴ�."
							+ " \n��¥ �Է� ������ ex) 1983-02-06 �Դϴ�");
					alert.showAndWait();

				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		});

		// ���Է� �ʱ�ȭ��ư
		/****************
		 * ��������.
		 * �ߺ��� ȸ�縦 ����ϴ°�찡�ִµ� �װ�츦 �����ߴ�.
		 * ȸ�翡 �����ִ� ����ڹ�ȣ,ȸ���,��ǥ�ڴ� �״�εΰ� �Է��Ҽ��ִ�.
		 ***************/
		btnS_Re_InputInit.setOnAction(event -> {

			btnS_Ok.setDisable(true);
			btnS_Modify.setDisable(true);
			btnS_Re_InputInit.setDisable(true);
			btnS_Delete.setDisable(true);
			btnS_Search.setDisable(false);
			txtS_SupplyValue.setText(0 + "");
			txtS_Tax.setText(0 + "");
			txtS_Totalmoney.clear();
			/* txtS_Totalmoney.setText(0+""); */
			txtS_Item.clear();
			txtS_Collection.setText(0 + "");
			txtS_Outstanding.setText(0 + "");
			txtS_Duedate.clear();
			txtS_Contact.clear();
			txtS_Note.clear();
			txtS_Depositdate_One.clear();
			txtS_Receipts_One.clear();
			txtS_Deposit_One.setText(0 + "");
			txtS_Deposit_Two.setText(0 + "");
			txtS_Depositdate_Two.clear();
			txtS_Receipts_Two.clear();
			txtS_Deposit_Three.setText(0 + "");
			txtS_Depositdate_Three.clear();
			txtS_Receipts_Three.clear();
			txtS_Deposit_Four.setText(0 + "");
			txtS_Depositdate_Four.clear();
			txtS_Receipts_Four.clear();
			txtS_Deposit_Five.setText(0 + "");
			txtS_Depositdate_Five.clear();
			txtS_Receipts_Five.clear();
			txtS_Deposit_Six.setText(0 + "");
			txtS_Depositdate_Six.clear();
			txtS_Receipts_Six.clear();
			txtS_Deposit_Seven.setText(0 + "");
			txtS_Depositdate_Seven.clear();
			txtS_Receipts_Seven.clear();
			txtS_SearchDate.clear();
			txtS_SearchLicenseenumber.clear();
			txtS_SearchCompany.clear();
			txtS_SearchOwner.clear();
			txtS_SearchOnsite.clear();
			txtS_TotSupplyValue.clear();
			txtS_TotTax.clear();
			txtS_TotTotalmoney.clear();
			txtS_TotCollection.clear();
			txtS_TotOutstanding.clear();
			// ����� �������� ������ư�� Ȱ��ȭ�Ǵ���. ��Ϲ�ư�� Ȱ��ȭ�Ǵ��� ����������.
			selectSales = null;
		});
		btnP_Re_InputInit.setOnAction(event -> {

			btnP_Ok.setDisable(true);
			btnP_Modify.setDisable(true);
			btnP_Re_InputInit.setDisable(true);
			btnP_Delete.setDisable(true);
			btnP_Search.setDisable(false);
			txtP_SupplyValue.setText(0 + "");
			txtP_Tax.setText(0 + "");
			txtP_Totalmoney.clear();
			/* txtP_Totalmoney.setText(0+""); */
			txtP_Item.clear();
			txtP_Transactionaccount.clear();
			txtP_Accountholder.clear();
			txtP_Bank.clear();
			txtP_Payment.setText(0 + "");
			txtP_Arrear.setText(0 + "");
			tgP_group.selectToggle(null);
			txtP_Givedate.clear();
			txtP_Contact.clear();
			txtP_Note.clear();
			txtP_Depositdate_One.clear();
			txtP_Receipts_One.clear();
			txtP_Deposit_One.setText(0 + "");
			txtP_Deposit_Two.setText(0 + "");
			txtP_Depositdate_Two.clear();
			txtP_Receipts_Two.clear();
			txtP_Deposit_Three.setText(0 + "");
			txtP_Depositdate_Three.clear();
			txtP_Receipts_Three.clear();
			txtP_Deposit_Four.setText(0 + "");
			txtP_Depositdate_Four.clear();
			txtP_Receipts_Four.clear();
			txtP_Deposit_Five.setText(0 + "");
			txtP_Depositdate_Five.clear();
			txtP_Receipts_Five.clear();
			txtP_Deposit_Six.setText(0 + "");
			txtP_Depositdate_Six.clear();
			txtP_Receipts_Six.clear();
			txtP_Deposit_Seven.setText(0 + "");
			txtP_Depositdate_Seven.clear();
			txtP_Receipts_Seven.clear();
			txtP_SearchDate.clear();
			/* txtP_SearchLicenseenumber.clear(); */
			txtP_SearchCompany.clear();
			txtP_SearchOwner.clear();
			txtP_SearchOnsite.clear();
			txtP_TotSupplyValue.clear();
			txtP_TotTax.clear();
			txtP_TotTotalmoney.clear();
			txtP_TotPayment.clear();
			txtP_TotArrear.clear();
			// ����� �������� ������ư�� Ȱ��ȭ�Ǵ���. ��Ϲ�ư�� Ȱ��ȭ�Ǵ��� ����������.
			selectPurchase = null;
		});

		// �� ����
		btnS_Delete.setOnAction(event -> {
			SalesDAO salesDAO = new SalesDAO();

			try {
				// ���� Ŀ������ ���콺������ �������� ���� ��ȣ�� selectedIndex_S �� ��´�.
				salesDAO.getSalesDelete(selectedIndex_S);
				dataSales.removeAll(dataSales);
				totalList();
				btnS_Ok.setDisable(true);
				btnS_Modify.setDisable(true);
				btnS_Re_InputInit.setDisable(true);
				btnS_Delete.setDisable(true);
				btnS_Search.setDisable(false);
				selectSales = null;

			} catch (Exception e) {
				e.printStackTrace();
			}
		});
		btnP_Delete.setOnAction(event -> {
			PurchaseDAO purchaseDAO = new PurchaseDAO();

			try {
				purchaseDAO.getPurchaseDelete(selectedIndex_P);
				dataPurchase.removeAll(dataPurchase);
				p_TotalList();
				btnP_Ok.setDisable(true);
				btnP_Modify.setDisable(true);
				btnP_Re_InputInit.setDisable(true);
				btnP_Delete.setDisable(true);
				btnP_Search.setDisable(false);
				selectPurchase = null;
			} catch (Exception e) {
				e.printStackTrace();
			}
		});

		// ��ü ��� ��ư
		btnS_TotalList.setOnAction(event -> {
			try {

				dataSales.removeAll(dataSales);
				txtS_TotSupplyValue.clear();
				txtS_TotTax.clear();
				txtS_TotTotalmoney.clear();
				txtS_TotCollection.clear();
				txtS_TotOutstanding.clear();
				totalList();
			} catch (Exception e) {

			}
		});
		btnP_TotalList.setOnAction(event -> {
			dataPurchase.removeAll(dataPurchase);
			txtP_TotSupplyValue.clear();
			txtP_TotTax.clear();
			txtP_TotTotalmoney.clear();
			txtP_TotPayment.clear();
			txtP_TotArrear.clear();
			p_TotalList();
		});
		// tableView_Sales ���콺 ���ý�.

		/******************************************
		 * ���̺��� ���� ���ý� ���� Ȱ���� �����ϴ�. (����,����,���Է��ʱ�ȭ �� �����ϴ�.) ���̺��� mouse event�� ��簪�� �Է���
		 * �ؽ�Ʈ�ʵ忡 ���� �̵��ϰ� ���� ���� ���� �����ϴ�..
		 * 
		 */
		tableView_Sales.setOnMousePressed(new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent event) {
				try {

					selectSales = tableView_Sales.getSelectionModel().getSelectedItems();
					selectedIndex_S = tableView_Sales.getSelectionModel().getSelectedIndex();

					txtS_Date.setText(selectSales.get(0).getDate());
					txtS_Licenseenumber.setText(selectSales.get(0).getLicenseenumber());
					txtS_Company.setText(selectSales.get(0).getCompany());
					txtS_Owner.setText(selectSales.get(0).getOwner());
					txtS_SupplyValue.setText(selectSales.get(0).getSupplyValue() + "");
					txtS_Tax.setText(selectSales.get(0).getTax() + "");
					txtS_Totalmoney.setText(selectSales.get(0).getTotalmoney() + "");
					txtS_Item.setText(selectSales.get(0).getItem());
					txtS_Onsite.setText(selectSales.get(0).getOnsite());
					txtS_Collection.setText(selectSales.get(0).getCollection() + "");
					txtS_Outstanding.setText(selectSales.get(0).getOutstanding() + "");
					txtS_Duedate.setText(selectSales.get(0).getDuedate());
					txtS_Contact.setText(selectSales.get(0).getContact());
					txtS_Note.setText(selectSales.get(0).getNote());

					txtS_Depositdate_One.setText(selectSales.get(0).getDepositdate_One());
					txtS_Receipts_One.setText(selectSales.get(0).getReceipts_One());
					txtS_Deposit_One.setText(selectSales.get(0).getDeposit_One() + "");
					txtS_Depositdate_Two.setText(selectSales.get(0).getDepositdate_Two());
					txtS_Receipts_Two.setText(selectSales.get(0).getReceipts_Two());
					txtS_Deposit_Two.setText(selectSales.get(0).getDeposit_Two() + "");
					txtS_Depositdate_Three.setText(selectSales.get(0).getDepositdate_Three());
					txtS_Receipts_Three.setText(selectSales.get(0).getReceipts_Three());
					txtS_Deposit_Three.setText(selectSales.get(0).getDeposit_Three() + "");
					txtS_Depositdate_Four.setText(selectSales.get(0).getDepositdate_Four());
					txtS_Receipts_Four.setText(selectSales.get(0).getReceipts_Four());
					txtS_Deposit_Four.setText(selectSales.get(0).getDeposit_Four() + "");
					txtS_Depositdate_Five.setText(selectSales.get(0).getDepositdate_Five());
					txtS_Receipts_Five.setText(selectSales.get(0).getReceipts_Five());
					txtS_Deposit_Five.setText(selectSales.get(0).getDeposit_Five() + "");
					txtS_Depositdate_Six.setText(selectSales.get(0).getDepositdate_Six());
					txtS_Receipts_Six.setText(selectSales.get(0).getReceipts_Six());
					txtS_Deposit_Six.setText(selectSales.get(0).getDeposit_Six() + "");
					txtS_Depositdate_Seven.setText(selectSales.get(0).getDepositdate_Seven());
					txtS_Receipts_Seven.setText(selectSales.get(0).getReceipts_Seven());
					txtS_Deposit_Seven.setText(selectSales.get(0).getDeposit_Seven() + "");
					selectedIndex_S = selectSales.get(0).getNumber();

					btnS_Ok.setDisable(true);
					btnS_Modify.setDisable(true);
					/* btnS_Modify.setDisable(false); */
					btnS_Re_InputInit.setDisable(false);
					btnS_Delete.setDisable(false);
					/* btnS_Search.setDisable(true); */
					btnS_Tax.setDisable(false);
					btnS_Totalmoney.setDisable(false);
					btnS_Re_InputInit.setDisable(false);
				} catch (Exception e) {

				}

			}
		});

		tableView_Purchase.setOnMousePressed(new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent event) {
				try {// ���� Ʈ����ĳġ�� �ƹ��͵������� ���̺��並 Ŭ���� ������ �����ϱ�����.

					selectPurchase = tableView_Purchase.getSelectionModel().getSelectedItems();
					selectedIndex_P = tableView_Purchase.getSelectionModel().getSelectedIndex();

					txtP_Date.setText(selectPurchase.get(0).getDate());
					txtP_Licenseenumber.setText(selectPurchase.get(0).getLicenseenumber());
					txtP_Company.setText(selectPurchase.get(0).getCompany());
					txtP_Owner.setText(selectPurchase.get(0).getOwner());
					txtP_SupplyValue.setText(selectPurchase.get(0).getSupplyValue() + "");
					txtP_Tax.setText(selectPurchase.get(0).getTax() + "");
					txtP_Totalmoney.setText(selectPurchase.get(0).getTotalmoney() + "");
					txtP_Item.setText(selectPurchase.get(0).getItem());
					txtP_Onsite.setText(selectPurchase.get(0).getOnsite());
					txtP_Transactionaccount.setText(selectPurchase.get(0).getTransactionaccount());
					txtP_Accountholder.setText(selectPurchase.get(0).getAccountholder());
					txtP_Bank.setText(selectPurchase.get(0).getBank());
					txtP_Payment.setText(selectPurchase.get(0).getPayment() + "");
					txtP_Arrear.setText(selectPurchase.get(0).getArrear() + "");
					if (selectPurchase.get(0).getWhether().equals("��")) {
						rbP_Yeo.setSelected(true);
					} else if (selectPurchase.get(0).getWhether().equals("��")) {
						rbP_Boo.setSelected(true);
					} else if (selectPurchase.get(0).getWhether().equals("��")) {
						rbP_Gyeong.setSelected(true);
					} else if (selectPurchase.get(0).getWhether().equals("��")) {
						rbP_No.setSelected(true);
					}
					txtP_Givedate.setText(selectPurchase.get(0).getGivedate());
					txtP_Contact.setText(selectPurchase.get(0).getContact());
					cbP_Division.setValue(selectPurchase.get(0).getDivision());
					txtP_Note.setText(selectPurchase.get(0).getNote());

					txtP_Depositdate_One.setText(selectPurchase.get(0).getDepositdate_One());
					txtP_Receipts_One.setText(selectPurchase.get(0).getReceipts_One());
					txtP_Deposit_One.setText(selectPurchase.get(0).getDeposit_One() + "");
					txtP_Depositdate_Two.setText(selectPurchase.get(0).getDepositdate_Two());
					txtP_Receipts_Two.setText(selectPurchase.get(0).getReceipts_Two());
					txtP_Deposit_Two.setText(selectPurchase.get(0).getDeposit_Two() + "");
					txtP_Depositdate_Three.setText(selectPurchase.get(0).getDepositdate_Three());
					txtP_Receipts_Three.setText(selectPurchase.get(0).getReceipts_Three());
					txtP_Deposit_Three.setText(selectPurchase.get(0).getDeposit_Three() + "");
					txtP_Depositdate_Four.setText(selectPurchase.get(0).getDepositdate_Four());
					txtP_Receipts_Four.setText(selectPurchase.get(0).getReceipts_Four());
					txtP_Deposit_Four.setText(selectPurchase.get(0).getDeposit_Four() + "");
					txtP_Depositdate_Five.setText(selectPurchase.get(0).getDepositdate_Five());
					txtP_Receipts_Five.setText(selectPurchase.get(0).getReceipts_Five());
					txtP_Deposit_Five.setText(selectPurchase.get(0).getDeposit_Five() + "");
					txtP_Depositdate_Six.setText(selectPurchase.get(0).getDepositdate_Six());
					txtP_Receipts_Six.setText(selectPurchase.get(0).getReceipts_Six());
					txtP_Deposit_Six.setText(selectPurchase.get(0).getDeposit_Six() + "");
					txtP_Depositdate_Seven.setText(selectPurchase.get(0).getDepositdate_Seven());
					txtP_Receipts_Seven.setText(selectPurchase.get(0).getReceipts_Seven());
					txtP_Deposit_Seven.setText(selectPurchase.get(0).getDeposit_Seven() + "");
					selectedIndex_P = selectPurchase.get(0).getNumber();

					btnP_Ok.setDisable(true);
					btnP_Modify.setDisable(true);
					btnP_Re_InputInit.setDisable(false);
					btnP_Delete.setDisable(false);
					btnP_Tax.setDisable(false);
					btnP_Totalmoney.setDisable(false);
					btnP_Re_InputInit.setDisable(false);

				} catch (Exception e) {

				}
			}

		});

		// ��ȸ �޼ҵ�!
		btnS_Search.setOnAction(event -> handlerBtnS_SearchOnAtion(event));
		btnP_Search.setOnAction(event -> handlerBtnP_SearchOnAtion(event));
		
		//���� ����
		btnS_Excel.setOnAction(event -> handlerBtnS_ExcelOnAtion(event));
		btnP_Excel.setOnAction(event -> handlerBtnP_ExcelOnAtion(event));
		//���� ���� ���
		btnS_SaveFileDir.setOnAction(event -> handelrBtnS_SaveFileDirOnAtion(event));
		btnP_SaveFileDir.setOnAction(event -> handelrBtnP_SaveFileDirOnAtion(event));
		//pdf����
		btnS_PDF.setOnAction(event -> handelrBtnS_PDFOnAtion(event));
		btnP_PDF.setOnAction(event -> handelrBtnP_PDFOnAtion(event));
		//��� 
		btnBarChart.setOnAction(event -> handlerBtnBarChartOnAction(event));
		btnP_BarChart.setOnAction(event -> handlerBtnP_BarChartOnAtion(event));
	}

	//���� ����ư
	public void handlerBtnP_BarChartOnAtion(ActionEvent event) {

	
		handlerBtnBarChartOnAction(event);
		
			
		
	}

	// ���� ��� ��ư ����ڷ� ���� ���� ������ ���� ���԰� ������ ���Ҽ��ִ�.
	public void handlerBtnBarChartOnAction(ActionEvent event) {

		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/barChart.fxml"));
			Parent mainView = (Parent)loader.load();
			Scene scene = new Scene(mainView);
			Stage mainMtage = new Stage();
			mainMtage.setTitle("������ ����ڷ�");
			mainMtage.setScene(scene);
			
			mainMtage.show();
			
		}catch(IOException e) {
			System.out.println("���� "+e);
		}
	}


	//���� �ּ� path �� �����ϸ� �����Ҽ��ִ� ��ư�� ����ȴ�.
	public void handelrBtnS_SaveFileDirOnAtion(ActionEvent event) {
		final DirectoryChooser directoryChooser = new DirectoryChooser();
		final File seletedDirectory = directoryChooser.showDialog(primaryStage);
	
		if(seletedDirectory != null) {
			txtS_SaveFileDir.setText(seletedDirectory.getAbsolutePath());
			btnS_Excel.setDisable(false);
			btnS_PDF.setDisable(false);
		}
	}
	public void handelrBtnP_SaveFileDirOnAtion(ActionEvent event) {
		final DirectoryChooser directoryChooser = new DirectoryChooser();
		final File seletedDirectory = directoryChooser.showDialog(primaryStage);
	
		if(seletedDirectory != null) {
			txtP_SaveFileDir.setText(seletedDirectory.getAbsolutePath());
			btnP_Excel.setDisable(false);
			btnP_PDF.setDisable(false);
		}
	}
	//excel ���ϻ���
	public void handlerBtnS_ExcelOnAtion(ActionEvent event) {
		//list �� observable�� �ٲٰ� �� ���� select_S �� �Ѵ�.
		
		SalesDAO salesDAO = new SalesDAO();
		boolean saveSuccess;
		
		ArrayList<SalesVO> list;
		list = salesDAO.getSalesTotal();
		SalesExcel excelWriter = new SalesExcel();
		
		//xlsx ���� ����
		saveSuccess = excelWriter.excelWiter(list, txtS_SaveFileDir.getText());
		if (saveSuccess) {
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("���� ���� ����!");
			alert.setHeaderText("������ ��� ���� ���� ���� ����.");
			alert.setContentText("������ ��� ���� ����");
			alert.showAndWait();
		}
		txtS_SaveFileDir.clear();
		btnS_Excel.setDisable(true);
		btnS_PDF.setDisable(true);
	}
	public void handlerBtnP_ExcelOnAtion(ActionEvent event) {
		PurchaseDAO purchaseDAO = new PurchaseDAO();
		boolean saveSuccess;
		
		ArrayList<PurchaseVO> list;
		list = purchaseDAO.getPurchaseTotal();
		PurchaseExcel excelWriter = new PurchaseExcel();
		
		//xlsx ���� ����
		saveSuccess = excelWriter.excelWiter(list, txtP_SaveFileDir.getText());
		if (saveSuccess) {
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("���� ���� ����!");
			alert.setHeaderText("������ ��� ���� ���� ���� ����.");
			alert.setContentText("������ ��� ���� ����");
			alert.showAndWait();
		}
		txtP_SaveFileDir.clear();
		btnP_Excel.setDisable(true);
		btnP_PDF.setDisable(true);
	}
	// pdf���� ����
	public void handelrBtnS_PDFOnAtion(ActionEvent event) {

			try {
				
			
			//pdf document ����
			//Rectangle pageSize, float marginLeft, float marginRight, float marginTop, float marginBottom)
			Document document = new Document(PageSize.A5,0,0,30,30);
			//pdf ������ ������ ������ ����.pdf������ �����ȴ�. ���� ��Ʈ������ ����.
			String strReportPDFName = "Sales_" + System.currentTimeMillis() + ".pdf";
			PdfWriter.getInstance(document, new FileOutputStream(txtS_SaveFileDir.getText()
					+"\\"+strReportPDFName));
			//document�� ���� pdf������ �����ֵ����Ѵ�.
			document.open();
			//�ѱ�������Ʈ ����
			BaseFont baseFont = BaseFont.createFont("font/MALGUN.TTF",BaseFont.IDENTITY_H,BaseFont.EMBEDDED);
			
			Font font = new Font(baseFont,8,Font.NORMAL);
			Font font2 = new Font(baseFont,14,Font.BOLD);
			//Ÿ��Ʋ
			Paragraph title = new Paragraph("������",font2);
			//�߰�����
			title.setAlignment(Element.ALIGN_CENTER);
			//������ �߰�
			document.add(title);
			document.add(new Paragraph("\r\n"));
			//���� ��¥
			LocalDate localDate = LocalDate.now();
			Paragraph writeDay = new Paragraph(localDate.toString(),font);
			//������ ����
			writeDay.setAlignment(Element.ALIGN_RIGHT);
			//������ �߰�
			document.add(writeDay);
			document.add(new Paragraph("\r\n"));
			
			//���̺����� table��ü���� PdfPTable��ü�� �� �����ϰ� ���̺��� ����� �ִ�.
			//�����ڿ� �÷����� ���ش�
			PdfPTable table = new PdfPTable(36);
			//������ �÷��� width�� ���Ѵ�
			table.setWidths(new int[] {10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,
					10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10
			});
			//�÷� Ÿ��Ʋ
			PdfPCell header1 = new PdfPCell(new Paragraph("�����ȣ",font));
			PdfPCell header2 = new PdfPCell(new Paragraph("�߱�����",font));
			PdfPCell header3 = new PdfPCell(new Paragraph("����ڵ�Ϲ�ȣ",font));
			PdfPCell header4 = new PdfPCell(new Paragraph("��ü��",font));
			PdfPCell header5 = new PdfPCell(new Paragraph("��ǥ��",font));
			PdfPCell header6 = new PdfPCell(new Paragraph("���ް���",font));
			PdfPCell header7 = new PdfPCell(new Paragraph("����",font));
			PdfPCell header8 = new PdfPCell(new Paragraph("�հ�ݾ�",font));
			PdfPCell header9 = new PdfPCell(new Paragraph("ǰ��",font));
			PdfPCell header10= new PdfPCell(new Paragraph("�����",font));
			PdfPCell header11 = new PdfPCell(new Paragraph("���ݾ�",font));
			PdfPCell header12 = new PdfPCell(new Paragraph("�̼���",font));
			PdfPCell header13 = new PdfPCell(new Paragraph("���ݿ�����",font));
			PdfPCell header14 = new PdfPCell(new Paragraph("�ش��ü ����ó",font));
			PdfPCell header15 = new PdfPCell(new Paragraph("���",font));
			PdfPCell header16 = new PdfPCell(new Paragraph("1�� ��¥",font));
			PdfPCell header17 = new PdfPCell(new Paragraph("��������",font));
			PdfPCell header18 = new PdfPCell(new Paragraph("�Աݾ�",font));
			PdfPCell header19 = new PdfPCell(new Paragraph("2�� ��¥",font));
			PdfPCell header20 = new PdfPCell(new Paragraph("��������",font));
			PdfPCell header21 = new PdfPCell(new Paragraph("�Աݾ�",font));
			PdfPCell header22 = new PdfPCell(new Paragraph("3�� ��¥",font));
			PdfPCell header23 = new PdfPCell(new Paragraph("��������",font));
			PdfPCell header24 = new PdfPCell(new Paragraph("�Աݾ�",font));
			PdfPCell header25 = new PdfPCell(new Paragraph("4�� ��¥",font));
			PdfPCell header26 = new PdfPCell(new Paragraph("��������",font));
			PdfPCell header27 = new PdfPCell(new Paragraph("�Աݾ�",font));
			PdfPCell header28 = new PdfPCell(new Paragraph("5�� ��¥",font));
			PdfPCell header29 = new PdfPCell(new Paragraph("��������",font));
			PdfPCell header30 = new PdfPCell(new Paragraph("�Աݾ�",font));
			PdfPCell header31 = new PdfPCell(new Paragraph("6�� ��¥",font));
			PdfPCell header32 = new PdfPCell(new Paragraph("��������",font));
			PdfPCell header33= new PdfPCell(new Paragraph("�Աݾ�",font));
			PdfPCell header34 = new PdfPCell(new Paragraph("7�� ��¥",font));
			PdfPCell header35 = new PdfPCell(new Paragraph("��������",font));
			PdfPCell header36 = new PdfPCell(new Paragraph("�Աݾ�",font));
			
			//��������
			header1.setHorizontalAlignment(Element.ALIGN_CENTER);
			header2.setHorizontalAlignment(Element.ALIGN_CENTER);
			header3.setHorizontalAlignment(Element.ALIGN_CENTER);
			header4.setHorizontalAlignment(Element.ALIGN_CENTER);
			header5.setHorizontalAlignment(Element.ALIGN_CENTER);
			header6.setHorizontalAlignment(Element.ALIGN_CENTER);
			header7.setHorizontalAlignment(Element.ALIGN_CENTER);
			header8.setHorizontalAlignment(Element.ALIGN_CENTER);
			header9.setHorizontalAlignment(Element.ALIGN_CENTER);
			header10.setHorizontalAlignment(Element.ALIGN_CENTER);
			header11.setHorizontalAlignment(Element.ALIGN_CENTER);
			header12.setHorizontalAlignment(Element.ALIGN_CENTER);
			header13.setHorizontalAlignment(Element.ALIGN_CENTER);
			header14.setHorizontalAlignment(Element.ALIGN_CENTER);
			header15.setHorizontalAlignment(Element.ALIGN_CENTER);
			header16.setHorizontalAlignment(Element.ALIGN_CENTER);
			header17.setHorizontalAlignment(Element.ALIGN_CENTER);
			header18.setHorizontalAlignment(Element.ALIGN_CENTER);
			header19.setHorizontalAlignment(Element.ALIGN_CENTER);
			header20.setHorizontalAlignment(Element.ALIGN_CENTER);
			header21.setHorizontalAlignment(Element.ALIGN_CENTER);
			header22.setHorizontalAlignment(Element.ALIGN_CENTER);
			header23.setHorizontalAlignment(Element.ALIGN_CENTER);
			header24.setHorizontalAlignment(Element.ALIGN_CENTER);
			header25.setHorizontalAlignment(Element.ALIGN_CENTER);
			header26.setHorizontalAlignment(Element.ALIGN_CENTER);
			header27.setHorizontalAlignment(Element.ALIGN_CENTER);
			header28.setHorizontalAlignment(Element.ALIGN_CENTER);
			header29.setHorizontalAlignment(Element.ALIGN_CENTER);
			header30.setHorizontalAlignment(Element.ALIGN_CENTER);
			header31.setHorizontalAlignment(Element.ALIGN_CENTER);
			header32.setHorizontalAlignment(Element.ALIGN_CENTER);
			header33.setHorizontalAlignment(Element.ALIGN_CENTER);
			header34.setHorizontalAlignment(Element.ALIGN_CENTER);
			header35.setHorizontalAlignment(Element.ALIGN_CENTER);
			header36.setHorizontalAlignment(Element.ALIGN_CENTER);
			
			
			//��������
			header1.setVerticalAlignment(Element.ALIGN_MIDDLE);
			header2.setVerticalAlignment(Element.ALIGN_MIDDLE);
			header3.setVerticalAlignment(Element.ALIGN_MIDDLE);
			header4.setVerticalAlignment(Element.ALIGN_MIDDLE);
			header5.setVerticalAlignment(Element.ALIGN_MIDDLE);
			header6.setVerticalAlignment(Element.ALIGN_MIDDLE);
			header7.setVerticalAlignment(Element.ALIGN_MIDDLE);
			header8.setVerticalAlignment(Element.ALIGN_MIDDLE);
			header9.setVerticalAlignment(Element.ALIGN_MIDDLE);
			header10.setVerticalAlignment(Element.ALIGN_MIDDLE);
			header11.setVerticalAlignment(Element.ALIGN_MIDDLE);
			header12.setVerticalAlignment(Element.ALIGN_MIDDLE);
			header13.setVerticalAlignment(Element.ALIGN_MIDDLE);
			header14.setVerticalAlignment(Element.ALIGN_MIDDLE);
			header15.setVerticalAlignment(Element.ALIGN_MIDDLE);
			header16.setVerticalAlignment(Element.ALIGN_MIDDLE);
			header17.setVerticalAlignment(Element.ALIGN_MIDDLE);
			header18.setVerticalAlignment(Element.ALIGN_MIDDLE);
			header19.setVerticalAlignment(Element.ALIGN_MIDDLE);
			header20.setVerticalAlignment(Element.ALIGN_MIDDLE);
			header21.setVerticalAlignment(Element.ALIGN_MIDDLE);
			header22.setVerticalAlignment(Element.ALIGN_MIDDLE);
			header23.setVerticalAlignment(Element.ALIGN_MIDDLE);
			header24.setVerticalAlignment(Element.ALIGN_MIDDLE);
			header25.setVerticalAlignment(Element.ALIGN_MIDDLE);
			header26.setVerticalAlignment(Element.ALIGN_MIDDLE);
			header27.setVerticalAlignment(Element.ALIGN_MIDDLE);
			header28.setVerticalAlignment(Element.ALIGN_MIDDLE);
			header29.setVerticalAlignment(Element.ALIGN_MIDDLE);
			header30.setVerticalAlignment(Element.ALIGN_MIDDLE);
			header31.setVerticalAlignment(Element.ALIGN_MIDDLE);
			header32.setVerticalAlignment(Element.ALIGN_MIDDLE);
			header33.setVerticalAlignment(Element.ALIGN_MIDDLE);
			header34.setVerticalAlignment(Element.ALIGN_MIDDLE);
			header35.setVerticalAlignment(Element.ALIGN_MIDDLE);
			header36.setVerticalAlignment(Element.ALIGN_MIDDLE);
			
			//���̺��� �߰�
			table.addCell(header1);
			table.addCell(header2);
			table.addCell(header3);
			table.addCell(header4);
			table.addCell(header5);
			table.addCell(header6);
			table.addCell(header7);
			table.addCell(header8);
			table.addCell(header9);
			table.addCell(header10);
			table.addCell(header11);
			table.addCell(header12);
			table.addCell(header13);
			table.addCell(header14);
			table.addCell(header15);
			table.addCell(header16);
			table.addCell(header17);
			table.addCell(header18);
			table.addCell(header19);
			table.addCell(header20);
			table.addCell(header21);
			table.addCell(header22);
			table.addCell(header23);
			table.addCell(header24);
			table.addCell(header25);
			table.addCell(header26);
			table.addCell(header27);
			table.addCell(header28);
			table.addCell(header29);
			table.addCell(header30);
			table.addCell(header31);
			table.addCell(header32);
			table.addCell(header33);
			table.addCell(header34);
			table.addCell(header35);
			table.addCell(header36);

			//DB ���� �� ����Ʈ ����
			SalesDAO salesDAO = new SalesDAO();
			SalesVO salesVO = new SalesVO();
			ArrayList<SalesVO>list;
			list = salesDAO.getSalesTotal();
			int rowCount = list.size();
			
			PdfPCell cell1 = null;
			PdfPCell cell2 = null;
			PdfPCell cell3 = null;
			PdfPCell cell4 = null;
			PdfPCell cell5 = null;
			PdfPCell cell6 = null;
			PdfPCell cell7 = null;
			PdfPCell cell8 = null;
			PdfPCell cell9 = null;
			PdfPCell cell10 = null;
			PdfPCell cell11 = null;
			PdfPCell cell12 = null;
			PdfPCell cell13 = null;
			PdfPCell cell14 = null;
			PdfPCell cell15 = null;
			PdfPCell cell16 = null;
			PdfPCell cell17 = null;
			PdfPCell cell18 = null;
			PdfPCell cell19 = null;
			PdfPCell cell20 = null;
			PdfPCell cell21 = null;
			PdfPCell cell22 = null;
			PdfPCell cell23 = null;
			PdfPCell cell24 = null;
			PdfPCell cell25 = null;
			PdfPCell cell26 = null;
			PdfPCell cell27 = null;
			PdfPCell cell28 = null;
			PdfPCell cell29 = null;
			PdfPCell cell30 = null;
			PdfPCell cell31 = null;
			PdfPCell cell32 = null;
			PdfPCell cell33 = null;
			PdfPCell cell34 = null;
			PdfPCell cell35 = null;
			PdfPCell cell36 = null;

			for (int index = 0 ; index<rowCount; index++) {
				salesVO = list.get(index);
				cell1 = new PdfPCell(new Paragraph(salesVO.getNumber() +"",font));
				cell2 = new PdfPCell(new Paragraph(salesVO.getDate() +"",font));
				cell3 = new PdfPCell(new Paragraph(salesVO.getLicenseenumber() +"",font));
				cell4 = new PdfPCell(new Paragraph(salesVO.getCompany() +"",font));
				cell5 = new PdfPCell(new Paragraph(salesVO.getOwner() +"",font));
				cell6 = new PdfPCell(new Paragraph(salesVO.getSupplyValue() +"",font));
				cell7 = new PdfPCell(new Paragraph(salesVO.getTax() +"",font));
				cell8 = new PdfPCell(new Paragraph(salesVO.getTotalmoney() +"",font));
				cell9 = new PdfPCell(new Paragraph(salesVO.getItem() +"",font));
				cell10 = new PdfPCell(new Paragraph(salesVO.getOnsite() +"",font));
				cell11 = new PdfPCell(new Paragraph(salesVO.getCollection() +"",font));
				cell12 = new PdfPCell(new Paragraph(salesVO.getOutstanding() +"",font));
				cell13 = new PdfPCell(new Paragraph(salesVO.getDuedate() +"",font));
				cell14 = new PdfPCell(new Paragraph(salesVO.getContact() +"",font));
				cell15 = new PdfPCell(new Paragraph(salesVO.getNote() +"",font));
				cell16 = new PdfPCell(new Paragraph(salesVO.getDepositdate_One() +"",font));
				cell17 = new PdfPCell(new Paragraph(salesVO.getReceipts_One() +"",font));
				cell18 = new PdfPCell(new Paragraph(salesVO.getDeposit_One() +"",font));
				cell19 = new PdfPCell(new Paragraph(salesVO.getDepositdate_Two() +"",font));
				cell20 = new PdfPCell(new Paragraph(salesVO.getReceipts_Two() +"",font));
				cell21 = new PdfPCell(new Paragraph(salesVO.getDeposit_Two() +"",font));
				cell22 = new PdfPCell(new Paragraph(salesVO.getDepositdate_Three() +"",font));
				cell23 = new PdfPCell(new Paragraph(salesVO.getReceipts_Three() +"",font));
				cell24 = new PdfPCell(new Paragraph(salesVO.getDeposit_Three() +"",font));
				cell25 = new PdfPCell(new Paragraph(salesVO.getDepositdate_Four() +"",font));
				cell26 = new PdfPCell(new Paragraph(salesVO.getReceipts_Four() +"",font));
				cell27 = new PdfPCell(new Paragraph(salesVO.getDeposit_Four() +"",font));
				cell28 = new PdfPCell(new Paragraph(salesVO.getDepositdate_Five() +"",font));
				cell29 = new PdfPCell(new Paragraph(salesVO.getReceipts_Five() +"",font));
				cell30 = new PdfPCell(new Paragraph(salesVO.getDeposit_Five() +"",font));
				cell31 = new PdfPCell(new Paragraph(salesVO.getDepositdate_Six() +"",font));
				cell32 = new PdfPCell(new Paragraph(salesVO.getReceipts_Six() +"",font));
				cell33 = new PdfPCell(new Paragraph(salesVO.getDeposit_Six() +"",font));
				cell34 = new PdfPCell(new Paragraph(salesVO.getDepositdate_Seven() +"",font));
				cell35 = new PdfPCell(new Paragraph(salesVO.getReceipts_Seven() +"",font));
				cell36 = new PdfPCell(new Paragraph(salesVO.getDeposit_Seven() +"",font));
				
				//��������
				cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell4.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell5.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell6.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell7.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell8.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell9.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell10.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell11.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell12.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell13.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell14.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell15.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell16.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell17.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell18.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell19.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell20.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell21.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell22.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell23.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell24.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell25.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell26.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell27.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell28.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell29.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell30.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell31.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell32.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell33.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell34.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell35.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell36.setHorizontalAlignment(Element.ALIGN_CENTER);
				//��������
				cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell2.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell3.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell4.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell5.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell6.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell7.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell8.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell9.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell10.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell11.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell12.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell13.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell14.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell15.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell16.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell17.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell18.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell19.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell20.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell21.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell22.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell23.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell24.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell25.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell26.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell27.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell28.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell29.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell30.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell31.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell32.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell33.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell34.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell35.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell36.setVerticalAlignment(Element.ALIGN_MIDDLE);

				//���̺��� �� �߰�
				table.addCell(cell1);
				table.addCell(cell2);
				table.addCell(cell3);
				table.addCell(cell4);
				table.addCell(cell5);
				table.addCell(cell6);
				table.addCell(cell7);
				table.addCell(cell8);
				table.addCell(cell9);
				table.addCell(cell10);
				table.addCell(cell11);
				table.addCell(cell12);
				table.addCell(cell13);
				table.addCell(cell14);
				table.addCell(cell15);
				table.addCell(cell16);
				table.addCell(cell17);
				table.addCell(cell18);
				table.addCell(cell19);
				table.addCell(cell20);
				table.addCell(cell21);
				table.addCell(cell22);
				table.addCell(cell23);
				table.addCell(cell24);
				table.addCell(cell25);
				table.addCell(cell26);
				table.addCell(cell27);
				table.addCell(cell28);
				table.addCell(cell29);
				table.addCell(cell30);
				table.addCell(cell31);
				table.addCell(cell32);
				table.addCell(cell33);
				table.addCell(cell34);
				table.addCell(cell35);
				table.addCell(cell36);
			}
			//������ ���̺� �߰�.
			document.add(table);
			document.add(new Paragraph("\r\n"));
			Alert alert = new Alert(AlertType.INFORMATION);
			
			//������ �ݴ´�. ���� ����.
			document.close();
			
			
			txtS_SaveFileDir.clear();
			btnS_PDF.setDisable(true);
			btnS_Excel.setDisable(true);
			
			
			alert.setTitle("PDF ���� ����!");
			alert.setHeaderText("������ ��� PDF ���� ���� ����.");
			alert.setContentText("������ ��� PDF ����");
			alert.showAndWait();
			}catch(FileNotFoundException ee) {
				ee.printStackTrace();
			}catch(DocumentException ee) {
				ee.printStackTrace();
			}catch(IOException ee) {
				ee.printStackTrace();
			}
			
			
		
	}
	public void handelrBtnP_PDFOnAtion(ActionEvent event) {
		try {
			
		
		//pdf document ����
		//Rectangle pageSize, float marginLeft, float marginRight, float marginTop, float marginBottom)
		Document document = new Document(PageSize.A4,0,0,30,30);
		//pdf ������ ������ ������ ����.pdf������ �����ȴ�. ���� ��Ʈ������ ����.
		String strReportPDFName = "purchase_" + System.currentTimeMillis() + ".pdf";
		PdfWriter.getInstance(document, new FileOutputStream(txtP_SaveFileDir.getText()
				+"\\"+strReportPDFName));
		//document�� ���� pdf������ �����ֵ����Ѵ�.
		document.open();
		//�ѱ�������Ʈ ����
		BaseFont baseFont = BaseFont.createFont("font/MALGUN.TTF",BaseFont.IDENTITY_H,BaseFont.EMBEDDED);
		
		Font font = new Font(baseFont,8,Font.NORMAL);
		Font font2 = new Font(baseFont,14,Font.BOLD);
		//Ÿ��Ʋ
		Paragraph title = new Paragraph("������",font2);
		//�߰�����
		title.setAlignment(Element.ALIGN_CENTER);
		//������ �߰�
		document.add(title);
		document.add(new Paragraph("\r\n"));
		//���� ��¥
		LocalDate localDate = LocalDate.now();
		Paragraph writeDay = new Paragraph(localDate.toString(),font);
		//������ ����
		writeDay.setAlignment(Element.ALIGN_RIGHT);
		//������ �߰�
		document.add(writeDay);
		document.add(new Paragraph("\r\n"));
		
		//���̺����� table��ü���� PdfPTable��ü�� �� �����ϰ� ���̺��� ����� �ִ�.
		//�����ڿ� �÷����� ���ش�
		PdfPTable table = new PdfPTable(41);
		//������ �÷��� width�� ���Ѵ�
		table.setWidths(new int[] {50,50,50,50,50,50,50,50,10,10,10,10,10,10,10,10,10,10,10,10,
				10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10
		});
		//�÷� Ÿ��Ʋ
		PdfPCell header1 = new PdfPCell(new Paragraph("�����ȣ",font));
		PdfPCell header2 = new PdfPCell(new Paragraph("�߱�����",font));
		PdfPCell header3 = new PdfPCell(new Paragraph("����ڵ�Ϲ�ȣ",font));
		PdfPCell header4 = new PdfPCell(new Paragraph("��ü��",font));
		PdfPCell header5 = new PdfPCell(new Paragraph("��ǥ��",font));
		PdfPCell header6 = new PdfPCell(new Paragraph("���ް���",font));
		PdfPCell header7 = new PdfPCell(new Paragraph("����",font));
		PdfPCell header8 = new PdfPCell(new Paragraph("�հ�ݾ�",font));
		PdfPCell header9 = new PdfPCell(new Paragraph("ǰ��",font));
		PdfPCell header10 = new PdfPCell(new Paragraph("�����",font));
		PdfPCell header11 = new PdfPCell(new Paragraph("�ŷ�����",font));
		PdfPCell header12 = new PdfPCell(new Paragraph("������",font));
		PdfPCell header13 = new PdfPCell(new Paragraph("����",font));
		PdfPCell header14 = new PdfPCell(new Paragraph("���ޱݾ�",font));
		PdfPCell header15 = new PdfPCell(new Paragraph("�����ޱݾ�",font));
		PdfPCell header16 = new PdfPCell(new Paragraph("����",font));
		PdfPCell header17 = new PdfPCell(new Paragraph("���޿�����",font));
		PdfPCell header18 = new PdfPCell(new Paragraph("����ó",font));
		PdfPCell header19 = new PdfPCell(new Paragraph("����",font));
		PdfPCell header20 = new PdfPCell(new Paragraph("���",font));
		PdfPCell header21 = new PdfPCell(new Paragraph("1�� ��¥",font));
		PdfPCell header22 = new PdfPCell(new Paragraph("��������",font));
		PdfPCell header23 = new PdfPCell(new Paragraph("�Աݾ�",font));
		PdfPCell header24 = new PdfPCell(new Paragraph("2�� ��¥",font));
		PdfPCell header25 = new PdfPCell(new Paragraph("��������",font));
		PdfPCell header26 = new PdfPCell(new Paragraph("�Աݾ�",font));
		PdfPCell header27 = new PdfPCell(new Paragraph("3�� ��¥",font));
		PdfPCell header28 = new PdfPCell(new Paragraph("��������",font));
		PdfPCell header29 = new PdfPCell(new Paragraph("�Աݾ�",font));
		PdfPCell header30 = new PdfPCell(new Paragraph("4�� ��¥",font));
		PdfPCell header31 = new PdfPCell(new Paragraph("��������",font));
		PdfPCell header32 = new PdfPCell(new Paragraph("�Աݾ�",font));
		PdfPCell header33 = new PdfPCell(new Paragraph("5�� ��¥",font));
		PdfPCell header34 = new PdfPCell(new Paragraph("��������",font));
		PdfPCell header35 = new PdfPCell(new Paragraph("�Աݾ�",font));
		PdfPCell header36 = new PdfPCell(new Paragraph("6�� ��¥",font));
		PdfPCell header37 = new PdfPCell(new Paragraph("��������",font));
		PdfPCell header38 = new PdfPCell(new Paragraph("�Աݾ�",font));
		PdfPCell header39 = new PdfPCell(new Paragraph("7�� ��¥",font));
		PdfPCell header40 = new PdfPCell(new Paragraph("��������",font));
		PdfPCell header41 = new PdfPCell(new Paragraph("�Աݾ�",font));

		//��������
		header1.setHorizontalAlignment(Element.ALIGN_CENTER);
		header2.setHorizontalAlignment(Element.ALIGN_CENTER);
		header3.setHorizontalAlignment(Element.ALIGN_CENTER);
		header4.setHorizontalAlignment(Element.ALIGN_CENTER);
		header5.setHorizontalAlignment(Element.ALIGN_CENTER);
		header6.setHorizontalAlignment(Element.ALIGN_CENTER);
		header7.setHorizontalAlignment(Element.ALIGN_CENTER);
		header8.setHorizontalAlignment(Element.ALIGN_CENTER);
		header9.setHorizontalAlignment(Element.ALIGN_CENTER);
		header10.setHorizontalAlignment(Element.ALIGN_CENTER);
		header11.setHorizontalAlignment(Element.ALIGN_CENTER);
		header12.setHorizontalAlignment(Element.ALIGN_CENTER);
		header13.setHorizontalAlignment(Element.ALIGN_CENTER);
		header14.setHorizontalAlignment(Element.ALIGN_CENTER);
		header15.setHorizontalAlignment(Element.ALIGN_CENTER);
		header16.setHorizontalAlignment(Element.ALIGN_CENTER);
		header17.setHorizontalAlignment(Element.ALIGN_CENTER);
		header18.setHorizontalAlignment(Element.ALIGN_CENTER);
		header19.setHorizontalAlignment(Element.ALIGN_CENTER);
		header20.setHorizontalAlignment(Element.ALIGN_CENTER);
		header21.setHorizontalAlignment(Element.ALIGN_CENTER);
		header22.setHorizontalAlignment(Element.ALIGN_CENTER);
		header23.setHorizontalAlignment(Element.ALIGN_CENTER);
		header24.setHorizontalAlignment(Element.ALIGN_CENTER);
		header25.setHorizontalAlignment(Element.ALIGN_CENTER);
		header26.setHorizontalAlignment(Element.ALIGN_CENTER);
		header27.setHorizontalAlignment(Element.ALIGN_CENTER);
		header28.setHorizontalAlignment(Element.ALIGN_CENTER);
		header29.setHorizontalAlignment(Element.ALIGN_CENTER);
		header30.setHorizontalAlignment(Element.ALIGN_CENTER);
		header31.setHorizontalAlignment(Element.ALIGN_CENTER);
		header32.setHorizontalAlignment(Element.ALIGN_CENTER);
		header33.setHorizontalAlignment(Element.ALIGN_CENTER);
		header34.setHorizontalAlignment(Element.ALIGN_CENTER);
		header35.setHorizontalAlignment(Element.ALIGN_CENTER);
		header36.setHorizontalAlignment(Element.ALIGN_CENTER);
		header37.setHorizontalAlignment(Element.ALIGN_CENTER);
		header38.setHorizontalAlignment(Element.ALIGN_CENTER);
		header39.setHorizontalAlignment(Element.ALIGN_CENTER);
		header40.setHorizontalAlignment(Element.ALIGN_CENTER);
		header41.setHorizontalAlignment(Element.ALIGN_CENTER);

		//��������
		header1.setVerticalAlignment(Element.ALIGN_MIDDLE);
		header2.setVerticalAlignment(Element.ALIGN_MIDDLE);
		header3.setVerticalAlignment(Element.ALIGN_MIDDLE);
		header4.setVerticalAlignment(Element.ALIGN_MIDDLE);
		header5.setVerticalAlignment(Element.ALIGN_MIDDLE);
		header6.setVerticalAlignment(Element.ALIGN_MIDDLE);
		header7.setVerticalAlignment(Element.ALIGN_MIDDLE);
		header8.setVerticalAlignment(Element.ALIGN_MIDDLE);
		header9.setVerticalAlignment(Element.ALIGN_MIDDLE);
		header10.setVerticalAlignment(Element.ALIGN_MIDDLE);
		header11.setVerticalAlignment(Element.ALIGN_MIDDLE);
		header12.setVerticalAlignment(Element.ALIGN_MIDDLE);
		header13.setVerticalAlignment(Element.ALIGN_MIDDLE);
		header14.setVerticalAlignment(Element.ALIGN_MIDDLE);
		header15.setVerticalAlignment(Element.ALIGN_MIDDLE);
		header16.setVerticalAlignment(Element.ALIGN_MIDDLE);
		header17.setVerticalAlignment(Element.ALIGN_MIDDLE);
		header18.setVerticalAlignment(Element.ALIGN_MIDDLE);
		header19.setVerticalAlignment(Element.ALIGN_MIDDLE);
		header20.setVerticalAlignment(Element.ALIGN_MIDDLE);
		header21.setVerticalAlignment(Element.ALIGN_MIDDLE);
		header22.setVerticalAlignment(Element.ALIGN_MIDDLE);
		header23.setVerticalAlignment(Element.ALIGN_MIDDLE);
		header24.setVerticalAlignment(Element.ALIGN_MIDDLE);
		header25.setVerticalAlignment(Element.ALIGN_MIDDLE);
		header26.setVerticalAlignment(Element.ALIGN_MIDDLE);
		header27.setVerticalAlignment(Element.ALIGN_MIDDLE);
		header28.setVerticalAlignment(Element.ALIGN_MIDDLE);
		header29.setVerticalAlignment(Element.ALIGN_MIDDLE);
		header30.setVerticalAlignment(Element.ALIGN_MIDDLE);
		header31.setVerticalAlignment(Element.ALIGN_MIDDLE);
		header32.setVerticalAlignment(Element.ALIGN_MIDDLE);
		header33.setVerticalAlignment(Element.ALIGN_MIDDLE);
		header34.setVerticalAlignment(Element.ALIGN_MIDDLE);
		header35.setVerticalAlignment(Element.ALIGN_MIDDLE);
		header36.setVerticalAlignment(Element.ALIGN_MIDDLE);
		header37.setVerticalAlignment(Element.ALIGN_MIDDLE);
		header38.setVerticalAlignment(Element.ALIGN_MIDDLE);
		header39.setVerticalAlignment(Element.ALIGN_MIDDLE);
		header40.setVerticalAlignment(Element.ALIGN_MIDDLE);
		header41.setVerticalAlignment(Element.ALIGN_MIDDLE);

		//���̺��� �߰�
		table.addCell(header1);
		table.addCell(header2);
		table.addCell(header3);
		table.addCell(header4);
		table.addCell(header5);
		table.addCell(header6);
		table.addCell(header7);
		table.addCell(header8);
		table.addCell(header9);
		table.addCell(header10);
		table.addCell(header11);
		table.addCell(header12);
		table.addCell(header13);
		table.addCell(header14);
		table.addCell(header15);
		table.addCell(header16);
		table.addCell(header17);
		table.addCell(header18);
		table.addCell(header19);
		table.addCell(header20);
		table.addCell(header21);
		table.addCell(header22);
		table.addCell(header23);
		table.addCell(header24);
		table.addCell(header25);
		table.addCell(header26);
		table.addCell(header27);
		table.addCell(header28);
		table.addCell(header29);
		table.addCell(header30);
		table.addCell(header31);
		table.addCell(header32);
		table.addCell(header33);
		table.addCell(header34);
		table.addCell(header35);
		table.addCell(header36);
		table.addCell(header37);
		table.addCell(header38);
		table.addCell(header39);
		table.addCell(header40);
		table.addCell(header41);

		//DB ���� �� ����Ʈ ����
		PurchaseDAO purchaseDAO = new PurchaseDAO();
		PurchaseVO purchaseVO =  new PurchaseVO();
		ArrayList<PurchaseVO> list;
		list = purchaseDAO.getPurchaseTotal();
		int rowCount = list.size();
		
		PdfPCell cell1 = null;
		PdfPCell cell2 = null;
		PdfPCell cell3 = null;
		PdfPCell cell4 = null;
		PdfPCell cell5 = null;
		PdfPCell cell6 = null;
		PdfPCell cell7 = null;
		PdfPCell cell8 = null;
		PdfPCell cell9 = null;
		PdfPCell cell10 = null;
		PdfPCell cell11 = null;
		PdfPCell cell12 = null;
		PdfPCell cell13 = null;
		PdfPCell cell14 = null;
		PdfPCell cell15 = null;
		PdfPCell cell16 = null;
		PdfPCell cell17 = null;
		PdfPCell cell18 = null;
		PdfPCell cell19 = null;
		PdfPCell cell20 = null;
		PdfPCell cell21 = null;
		PdfPCell cell22 = null;
		PdfPCell cell23 = null;
		PdfPCell cell24 = null;
		PdfPCell cell25 = null;
		PdfPCell cell26 = null;
		PdfPCell cell27 = null;
		PdfPCell cell28 = null;
		PdfPCell cell29 = null;
		PdfPCell cell30 = null;
		PdfPCell cell31 = null;
		PdfPCell cell32 = null;
		PdfPCell cell33 = null;
		PdfPCell cell34 = null;
		PdfPCell cell35 = null;
		PdfPCell cell36 = null;
		PdfPCell cell37 = null;
		PdfPCell cell38 = null;
		PdfPCell cell39 = null;
		PdfPCell cell40 = null;
		PdfPCell cell41 = null;

		for(int index = 0 ; index < rowCount ; index++) {
			purchaseVO = list.get(index);
			cell1 = new PdfPCell(new Paragraph(purchaseVO.getNumber() +"",font));
			cell2 = new PdfPCell(new Paragraph(purchaseVO.getDate() +"",font));
			cell3 = new PdfPCell(new Paragraph(purchaseVO.getLicenseenumber() +"",font));
			cell4 = new PdfPCell(new Paragraph(purchaseVO.getCompany() +"",font));
			cell5 = new PdfPCell(new Paragraph(purchaseVO.getOwner() +"",font));
			cell6 = new PdfPCell(new Paragraph(purchaseVO.getSupplyValue() +"",font));
			cell7 = new PdfPCell(new Paragraph(purchaseVO.getTax() +"",font));
			cell8 = new PdfPCell(new Paragraph(purchaseVO.getTotalmoney() +"",font));
			cell9 = new PdfPCell(new Paragraph(purchaseVO.getItem() +"",font));
			cell10 = new PdfPCell(new Paragraph(purchaseVO.getOnsite() +"",font));
			cell11 = new PdfPCell(new Paragraph(purchaseVO.getTransactionaccount() +"",font));
			cell12 = new PdfPCell(new Paragraph(purchaseVO.getAccountholder() +"",font));
			cell13 = new PdfPCell(new Paragraph(purchaseVO.getBank() +"",font));
			cell14 = new PdfPCell(new Paragraph(purchaseVO.getPayment() +"",font));
			cell15 = new PdfPCell(new Paragraph(purchaseVO.getArrear() +"",font));
			cell16 = new PdfPCell(new Paragraph(purchaseVO.getWhether() +"",font));
			cell17 = new PdfPCell(new Paragraph(purchaseVO.getGivedate() +"",font));
			cell18 = new PdfPCell(new Paragraph(purchaseVO.getContact() +"",font));
			cell19 = new PdfPCell(new Paragraph(purchaseVO.getWhether() +"",font));
			cell20 = new PdfPCell(new Paragraph(purchaseVO.getNote() +"",font));
			cell21 = new PdfPCell(new Paragraph(purchaseVO.getDepositdate_One() +"",font));
			cell22 = new PdfPCell(new Paragraph(purchaseVO.getReceipts_One() +"",font));
			cell23 = new PdfPCell(new Paragraph(purchaseVO.getDeposit_One() +"",font));
			cell24 = new PdfPCell(new Paragraph(purchaseVO.getDepositdate_Two() +"",font));
			cell25 = new PdfPCell(new Paragraph(purchaseVO.getReceipts_Two() +"",font));
			cell26 = new PdfPCell(new Paragraph(purchaseVO.getDeposit_Two() +"",font));
			cell27 = new PdfPCell(new Paragraph(purchaseVO.getDepositdate_Three() +"",font));
			cell28 = new PdfPCell(new Paragraph(purchaseVO.getReceipts_Three() +"",font));
			cell29 = new PdfPCell(new Paragraph(purchaseVO.getDeposit_Three() +"",font));
			cell30 = new PdfPCell(new Paragraph(purchaseVO.getDepositdate_Four() +"",font));
			cell31 = new PdfPCell(new Paragraph(purchaseVO.getReceipts_Four() +"",font));
			cell32 = new PdfPCell(new Paragraph(purchaseVO.getDeposit_Four() +"",font));
			cell33 = new PdfPCell(new Paragraph(purchaseVO.getDepositdate_Five() +"",font));
			cell34 = new PdfPCell(new Paragraph(purchaseVO.getReceipts_Five() +"",font));
			cell35 = new PdfPCell(new Paragraph(purchaseVO.getDeposit_Five() +"",font));
			cell36 = new PdfPCell(new Paragraph(purchaseVO.getDepositdate_Six() +"",font));
			cell37 = new PdfPCell(new Paragraph(purchaseVO.getReceipts_Six() +"",font));
			cell38 = new PdfPCell(new Paragraph(purchaseVO.getDeposit_Six() +"",font));
			cell39 = new PdfPCell(new Paragraph(purchaseVO.getDepositdate_Seven() +"",font));
			cell40 = new PdfPCell(new Paragraph(purchaseVO.getReceipts_Seven() +"",font));
			cell41 = new PdfPCell(new Paragraph(purchaseVO.getDeposit_Seven() +"",font));

			//��������
			cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell4.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell5.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell6.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell7.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell8.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell9.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell10.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell11.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell12.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell13.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell14.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell15.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell16.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell17.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell18.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell19.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell20.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell21.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell22.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell23.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell24.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell25.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell26.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell27.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell28.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell29.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell30.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell31.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell32.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell33.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell34.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell35.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell36.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell37.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell38.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell39.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell40.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell41.setHorizontalAlignment(Element.ALIGN_CENTER);
			//��������
			cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell2.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell3.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell4.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell5.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell6.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell7.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell8.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell9.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell10.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell11.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell12.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell13.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell14.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell15.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell16.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell17.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell18.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell19.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell20.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell21.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell22.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell23.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell24.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell25.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell26.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell27.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell28.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell29.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell30.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell31.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell32.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell33.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell34.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell35.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell36.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell37.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell38.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell39.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell40.setVerticalAlignment(Element.ALIGN_MIDDLE);
			cell41.setVerticalAlignment(Element.ALIGN_MIDDLE);
			// ���̺��� �� �߰�
			table.addCell(cell1);
			table.addCell(cell2);
			table.addCell(cell3);
			table.addCell(cell4);
			table.addCell(cell5);
			table.addCell(cell6);
			table.addCell(cell7);
			table.addCell(cell8);
			table.addCell(cell9);
			table.addCell(cell10);
			table.addCell(cell11);
			table.addCell(cell12);
			table.addCell(cell13);
			table.addCell(cell14);
			table.addCell(cell15);
			table.addCell(cell16);
			table.addCell(cell17);
			table.addCell(cell18);
			table.addCell(cell19);
			table.addCell(cell20);
			table.addCell(cell21);
			table.addCell(cell22);
			table.addCell(cell23);
			table.addCell(cell24);
			table.addCell(cell25);
			table.addCell(cell26);
			table.addCell(cell27);
			table.addCell(cell28);
			table.addCell(cell29);
			table.addCell(cell30);
			table.addCell(cell31);
			table.addCell(cell32);
			table.addCell(cell33);
			table.addCell(cell34);
			table.addCell(cell35);
			table.addCell(cell36);
			table.addCell(cell37);
			table.addCell(cell38);
			table.addCell(cell39);
			table.addCell(cell40);
			table.addCell(cell41);
		}
		//������ ���̺� �߰�.
		document.add(table);
		//������ �ݴ´�. ���� ����.
		document.close();
		
		txtS_SaveFileDir.clear();
		btnS_PDF.setDisable(true);
		btnS_Excel.setDisable(true);
		
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("PDF ���� ����!");
		alert.setHeaderText("������ ��� PDF ���� ���� ����.");
		alert.setContentText("������ ��� PDF ����");
		alert.showAndWait();
		
	}catch(FileNotFoundException e) {
		e.printStackTrace();
	}catch(DocumentException e) {
		e.printStackTrace();
	}catch(IOException e) {
		e.printStackTrace();
	}
	}

	
	//��ȸ ��ư
	/***************************
	 * ��ȸ�� ������ 5���� ������ 6���� �� ������ ��ȸ�� �Ҽ��ֵ��� �ߴ�.
	 * 5,6���� ����Ǽ��� ��� ��� ������ �Է��ϵ� ������ ��ȸ�� �����ϵ��� ������� 
	 * ��ȸ�� ���� ��ȸ��Ͽ� ���� ���ް���,����,�հ�ݾ�,���ݾ�,�̼���
	 *      ���� ��ȸ��Ͽ� ���� ���ް���,����,�հ�ݾ�,����,������
	 *      �� �հ踦 ����ش�. ������ ���ݰ���� �����ϱ�����.
	 ***************************/
	public void handlerBtnS_SearchOnAtion(ActionEvent event) {

		try {
			SalesVO salesVO = null;
			SalesDAO salesDAO = new SalesDAO();
			ArrayList<SalesVO> list = null;

			
			//�ҽ��� ����ϰ� �ϱ����ؼ� ����ߴ�.
			//��ȸ���� �ʿ��� ��ι�ȣ
			int i = 0;
			//��ȸ�� �հ�ݾ�.
			long sum_supplyValue = 0;
			long sum_tax = 0;
			long sum_totalmoney = 0;
			long sum_collection = 0;
			long sum_outstanding = 0;
			//�Ű����� ��ġ�� �� ������.
			String one = null;
			String two = null;
			String three = null;
			String four = null;
			String five = null;
			if (!txtS_SearchDate.getText().trim().equals("") && txtS_SearchLicenseenumber.getText().trim().equals("")
					&& txtS_SearchCompany.getText().trim().equals("") && txtS_SearchOwner.getText().trim().equals("")
					&& txtS_SearchOnsite.getText().trim().equals("")) {
				i = 1;
				one = txtS_SearchDate.getText().trim();
				list = salesDAO.getSalesSearch(one, two, three, four, five, i);
			} else if (txtS_SearchDate.getText().trim().equals("")
					&& !txtS_SearchLicenseenumber.getText().trim().equals("")
					&& txtS_SearchCompany.getText().trim().equals("") && txtS_SearchOwner.getText().trim().equals("")
					&& txtS_SearchOnsite.getText().trim().equals("")) {
				i = 2;
				one = txtS_SearchLicenseenumber.getText().trim();
				list = salesDAO.getSalesSearch(one, two, three, four, five, i);
			} else if (txtS_SearchDate.getText().trim().equals("")
					&& txtS_SearchLicenseenumber.getText().trim().equals("")
					&& !txtS_SearchCompany.getText().trim().equals("") && txtS_SearchOwner.getText().trim().equals("")
					&& txtS_SearchOnsite.getText().trim().equals("")) {
				i = 3;
				one = txtS_SearchCompany.getText().trim();
				list = salesDAO.getSalesSearch(one, two, three, four, five, i);
			} else if (txtS_SearchDate.getText().trim().equals("")
					&& txtS_SearchLicenseenumber.getText().trim().equals("")
					&& txtS_SearchCompany.getText().trim().equals("") && !txtS_SearchOwner.getText().trim().equals("")
					&& txtS_SearchOnsite.getText().trim().equals("")) {
				i = 4;
				one = txtS_SearchOwner.getText().trim();
				list = salesDAO.getSalesSearch(one, two, three, four, five, i);
			} else if (txtS_SearchDate.getText().trim().equals("")
					&& txtS_SearchLicenseenumber.getText().trim().equals("")
					&& txtS_SearchCompany.getText().trim().equals("") && txtS_SearchOwner.getText().trim().equals("")
					&& !txtS_SearchOnsite.getText().trim().equals("")) {
				i = 5;
				one = txtS_SearchOnsite.getText().trim();
				list = salesDAO.getSalesSearch(one, two, three, four, five, i);
			} else if (!txtS_SearchDate.getText().trim().equals("")
					&& !txtS_SearchLicenseenumber.getText().trim().equals("")
					&& txtS_SearchCompany.getText().trim().equals("") && txtS_SearchOwner.getText().trim().equals("")
					&& txtS_SearchOnsite.getText().trim().equals("")) {
				i = 6;
				one = txtS_SearchDate.getText().trim();
				two = txtS_SearchLicenseenumber.getText().trim();
				list = salesDAO.getSalesSearch(one, two, three, four, five, i);
			} else if (!txtS_SearchDate.getText().trim().equals("")
					&& txtS_SearchLicenseenumber.getText().trim().equals("")
					&& !txtS_SearchCompany.getText().trim().equals("") && txtS_SearchOwner.getText().trim().equals("")
					&& txtS_SearchOnsite.getText().trim().equals("")) {
				i = 7;
				one = txtS_SearchDate.getText().trim();
				two = txtS_SearchCompany.getText().trim();
				list = salesDAO.getSalesSearch(one, two, three, four, five, i);
			} else if (!txtS_SearchDate.getText().trim().equals("")
					&& txtS_SearchLicenseenumber.getText().trim().equals("")
					&& txtS_SearchCompany.getText().trim().equals("") && !txtS_SearchOwner.getText().trim().equals("")
					&& txtS_SearchOnsite.getText().trim().equals("")) {
				i = 8;
				one = txtS_SearchDate.getText().trim();
				two = txtS_SearchOwner.getText().trim();
				list = salesDAO.getSalesSearch(one, two, three, four, five, i);
			} else if (!txtS_SearchDate.getText().trim().equals("")
					&& txtS_SearchLicenseenumber.getText().trim().equals("")
					&& txtS_SearchCompany.getText().trim().equals("") && txtS_SearchOwner.getText().trim().equals("")
					&& !txtS_SearchOnsite.getText().trim().equals("")) {
				i = 9;
				one = txtS_SearchDate.getText().trim();
				two = txtS_SearchOnsite.getText().trim();
				list = salesDAO.getSalesSearch(one, two, three, four, five, i);
			} else if (txtS_SearchDate.getText().trim().equals("")
					&& !txtS_SearchLicenseenumber.getText().trim().equals("")
					&& !txtS_SearchCompany.getText().trim().equals("") && txtS_SearchOwner.getText().trim().equals("")
					&& txtS_SearchOnsite.getText().trim().equals("")) {
				i = 10;
				one = txtS_SearchLicenseenumber.getText().trim();
				two = txtS_SearchCompany.getText().trim();
				list = salesDAO.getSalesSearch(one, two, three, four, five, i);
			} else if (txtS_SearchDate.getText().trim().equals("")
					&& !txtS_SearchLicenseenumber.getText().trim().equals("")
					&& txtS_SearchCompany.getText().trim().equals("") && !txtS_SearchOwner.getText().trim().equals("")
					&& txtS_SearchOnsite.getText().trim().equals("")) {
				i = 11;
				one = txtS_SearchLicenseenumber.getText().trim();
				two = txtS_SearchOwner.getText().trim();
				list = salesDAO.getSalesSearch(one, two, three, four, five, i);
			} else if (txtS_SearchDate.getText().trim().equals("")
					&& !txtS_SearchLicenseenumber.getText().trim().equals("")
					&& txtS_SearchCompany.getText().trim().equals("") && txtS_SearchOwner.getText().trim().equals("")
					&& !txtS_SearchOnsite.getText().trim().equals("")) {
				i = 12;
				one = txtS_SearchDate.getText().trim();
				two = txtS_SearchOwner.getText().trim();
				list = salesDAO.getSalesSearch(one, two, three, four, five, i);
			} else if (txtS_SearchDate.getText().trim().equals("")
					&& txtS_SearchLicenseenumber.getText().trim().equals("")
					&& !txtS_SearchCompany.getText().trim().equals("") && !txtS_SearchOwner.getText().trim().equals("")
					&& txtS_SearchOnsite.getText().trim().equals("")) {
				i = 13;
				one = txtS_SearchCompany.getText().trim();
				two = txtS_SearchOwner.getText().trim();
				list = salesDAO.getSalesSearch(one, two, three, four, five, i);
			} else if (txtS_SearchDate.getText().trim().equals("")
					&& txtS_SearchLicenseenumber.getText().trim().equals("")
					&& !txtS_SearchCompany.getText().trim().equals("") && txtS_SearchOwner.getText().trim().equals("")
					&& !txtS_SearchOnsite.getText().trim().equals("")) {
				i = 14;
				one = txtS_SearchCompany.getText().trim();
				two = txtS_SearchOnsite.getText().trim();
				list = salesDAO.getSalesSearch(one, two, three, four, five, i);
			} else if (txtS_SearchDate.getText().trim().equals("")
					&& txtS_SearchLicenseenumber.getText().trim().equals("")
					&& txtS_SearchCompany.getText().trim().equals("") && !txtS_SearchOwner.getText().trim().equals("")
					&& !txtS_SearchOnsite.getText().trim().equals("")) {
				i = 15;
				one = txtS_SearchOwner.getText().trim();
				two = txtS_SearchOnsite.getText().trim();
				list = salesDAO.getSalesSearch(one, two, three, four, five, i);
			} else if (!txtS_SearchDate.getText().trim().equals("")
					&& !txtS_SearchLicenseenumber.getText().trim().equals("")
					&& !txtS_SearchCompany.getText().trim().equals("") && txtS_SearchOwner.getText().trim().equals("")
					&& txtS_SearchOnsite.getText().trim().equals("")) {
				i = 16;
				one = txtS_SearchDate.getText().trim();
				two = txtS_SearchLicenseenumber.getText().trim();
				three = txtS_SearchCompany.getText().trim();
				list = salesDAO.getSalesSearch(one, two, three, four, five, i);
			} else if (!txtS_SearchDate.getText().trim().equals("")
					&& !txtS_SearchLicenseenumber.getText().trim().equals("")
					&& txtS_SearchCompany.getText().trim().equals("") && !txtS_SearchOwner.getText().trim().equals("")
					&& txtS_SearchOnsite.getText().trim().equals("")) {
				i = 17;
				one = txtS_SearchDate.getText().trim();
				two = txtS_SearchLicenseenumber.getText().trim();
				three = txtS_SearchOwner.getText().trim();
				list = salesDAO.getSalesSearch(one, two, three, four, five, i);
			} else if (!txtS_SearchDate.getText().trim().equals("")
					&& !txtS_SearchLicenseenumber.getText().trim().equals("")
					&& txtS_SearchCompany.getText().trim().equals("") && txtS_SearchOwner.getText().trim().equals("")
					&& !txtS_SearchOnsite.getText().trim().equals("")) {
				i = 18;
				one = txtS_SearchDate.getText().trim();
				two = txtS_SearchLicenseenumber.getText().trim();
				three = txtS_SearchOnsite.getText().trim();
				list = salesDAO.getSalesSearch(one, two, three, four, five, i);
			} else if (!txtS_SearchDate.getText().trim().equals("")
					&& txtS_SearchLicenseenumber.getText().trim().equals("")
					&& !txtS_SearchCompany.getText().trim().equals("") && !txtS_SearchOwner.getText().trim().equals("")
					&& txtS_SearchOnsite.getText().trim().equals("")) {
				i = 19;
				one = txtS_SearchDate.getText().trim();
				two = txtS_SearchCompany.getText().trim();
				three = txtS_SearchOwner.getText().trim();
				list = salesDAO.getSalesSearch(one, two, three, four, five, i);
			} else if (!txtS_SearchDate.getText().trim().equals("")
					&& txtS_SearchLicenseenumber.getText().trim().equals("")
					&& !txtS_SearchCompany.getText().trim().equals("") && txtS_SearchOwner.getText().trim().equals("")
					&& !txtS_SearchOnsite.getText().trim().equals("")) {
				i = 20;
				one = txtS_SearchDate.getText().trim();
				two = txtS_SearchCompany.getText().trim();
				three = txtS_SearchOnsite.getText().trim();
				list = salesDAO.getSalesSearch(one, two, three, four, five, i);
			} else if (!txtS_SearchDate.getText().trim().equals("")
					&& txtS_SearchLicenseenumber.getText().trim().equals("")
					&& txtS_SearchCompany.getText().trim().equals("") && !txtS_SearchOwner.getText().trim().equals("")
					&& !txtS_SearchOnsite.getText().trim().equals("")) {
				i = 21;
				one = txtS_SearchDate.getText().trim();
				two = txtS_SearchOwner.getText().trim();
				three = txtS_SearchOnsite.getText().trim();
				list = salesDAO.getSalesSearch(one, two, three, four, five, i);
			} else if (txtS_SearchDate.getText().trim().equals("")
					&& !txtS_SearchLicenseenumber.getText().trim().equals("")
					&& !txtS_SearchCompany.getText().trim().equals("") && !txtS_SearchOwner.getText().trim().equals("")
					&& txtS_SearchOnsite.getText().trim().equals("")) {
				i = 22;
				one = txtS_SearchLicenseenumber.getText().trim();
				two = txtS_SearchCompany.getText().trim();
				three = txtS_SearchOwner.getText().trim();
				list = salesDAO.getSalesSearch(one, two, three, four, five, i);
			} else if (txtS_SearchDate.getText().trim().equals("")
					&& !txtS_SearchLicenseenumber.getText().trim().equals("")
					&& !txtS_SearchCompany.getText().trim().equals("") && txtS_SearchOwner.getText().trim().equals("")
					&& !txtS_SearchOnsite.getText().trim().equals("")) {
				i = 23;
				one = txtS_SearchLicenseenumber.getText().trim();
				two = txtS_SearchCompany.getText().trim();
				three = txtS_SearchOnsite.getText().trim();
				list = salesDAO.getSalesSearch(one, two, three, four, five, i);
			} else if (txtS_SearchDate.getText().trim().equals("")
					&& !txtS_SearchLicenseenumber.getText().trim().equals("")
					&& txtS_SearchCompany.getText().trim().equals("") && !txtS_SearchOwner.getText().trim().equals("")
					&& !txtS_SearchOnsite.getText().trim().equals("")) {
				i = 24;
				one = txtS_SearchLicenseenumber.getText().trim();
				two = txtS_SearchOwner.getText().trim();
				three = txtS_SearchOnsite.getText().trim();
				list = salesDAO.getSalesSearch(one, two, three, four, five, i);
			} else if (txtS_SearchDate.getText().trim().equals("")
					&& txtS_SearchLicenseenumber.getText().trim().equals("")
					&& !txtS_SearchCompany.getText().trim().equals("") && !txtS_SearchOwner.getText().trim().equals("")
					&& !txtS_SearchOnsite.getText().trim().equals("")) {
				i = 25;
				one = txtS_SearchCompany.getText().trim();
				two = txtS_SearchOwner.getText().trim();
				three = txtS_SearchOnsite.getText().trim();
				list = salesDAO.getSalesSearch(one, two, three, four, five, i);
			} else if (!txtS_SearchDate.getText().trim().equals("")
					&& !txtS_SearchLicenseenumber.getText().trim().equals("")
					&& !txtS_SearchCompany.getText().trim().equals("") && !txtS_SearchOwner.getText().trim().equals("")
					&& txtS_SearchOnsite.getText().trim().equals("")) {
				i = 26;
				one = txtS_SearchDate.getText().trim();
				two = txtS_SearchLicenseenumber.getText().trim();
				three = txtS_SearchCompany.getText().trim();
				four = txtS_SearchOwner.getText().trim();
				list = salesDAO.getSalesSearch(one, two, three, four, five, i);
			} else if (!txtS_SearchDate.getText().trim().equals("")
					&& !txtS_SearchLicenseenumber.getText().trim().equals("")
					&& !txtS_SearchCompany.getText().trim().equals("") && txtS_SearchOwner.getText().trim().equals("")
					&& !txtS_SearchOnsite.getText().trim().equals("")) {
				i = 27;
				one = txtS_SearchDate.getText().trim();
				two = txtS_SearchLicenseenumber.getText().trim();
				three = txtS_SearchCompany.getText().trim();
				four = txtS_SearchOnsite.getText().trim();
				list = salesDAO.getSalesSearch(one, two, three, four, five, i);
			} else if (!txtS_SearchDate.getText().trim().equals("")
					&& !txtS_SearchLicenseenumber.getText().trim().equals("")
					&& txtS_SearchCompany.getText().trim().equals("") && !txtS_SearchOwner.getText().trim().equals("")
					&& !txtS_SearchOnsite.getText().trim().equals("")) {
				i = 28;
				one = txtS_SearchDate.getText().trim();
				two = txtS_SearchLicenseenumber.getText().trim();
				three = txtS_SearchOwner.getText().trim();
				four = txtS_SearchOnsite.getText().trim();
				list = salesDAO.getSalesSearch(one, two, three, four, five, i);
			} else if (!txtS_SearchDate.getText().trim().equals("")
					&& txtS_SearchLicenseenumber.getText().trim().equals("")
					&& !txtS_SearchCompany.getText().trim().equals("") && !txtS_SearchOwner.getText().trim().equals("")
					&& !txtS_SearchOnsite.getText().trim().equals("")) {
				i = 29;
				one = txtS_SearchDate.getText().trim();
				two = txtS_SearchCompany.getText().trim();
				three = txtS_SearchOwner.getText().trim();
				four = txtS_SearchOnsite.getText().trim();
				list = salesDAO.getSalesSearch(one, two, three, four, five, i);
			} else if (txtS_SearchDate.getText().trim().equals("")
					&& !txtS_SearchLicenseenumber.getText().trim().equals("")
					&& !txtS_SearchCompany.getText().trim().equals("") && !txtS_SearchOwner.getText().trim().equals("")
					&& !txtS_SearchOnsite.getText().trim().equals("")) {
				i = 30;
				one = txtS_SearchLicenseenumber.getText().trim();
				two = txtS_SearchCompany.getText().trim();
				three = txtS_SearchOwner.getText().trim();
				four = txtS_SearchOnsite.getText().trim();
				list = salesDAO.getSalesSearch(one, two, three, four, five, i);
			} else if (!txtS_SearchDate.getText().trim().equals("")
					&& !txtS_SearchLicenseenumber.getText().trim().equals("")
					&& !txtS_SearchCompany.getText().trim().equals("") && !txtS_SearchOwner.getText().trim().equals("")
					&& !txtS_SearchOnsite.getText().trim().equals("")) {
				i = 31;
				one = txtS_SearchDate.getText().trim();
				two = txtS_SearchLicenseenumber.getText().trim();
				three = txtS_SearchCompany.getText().trim();
				four = txtS_SearchOwner.getText().trim();
				five = txtS_SearchOnsite.getText().trim();
				list = salesDAO.getSalesSearch(one, two, three, four, five, i);
			} else {
				txtS_SearchDate.clear();
				txtS_SearchLicenseenumber.clear();
				txtS_SearchCompany.clear();
				txtS_SearchOwner.clear();
				txtS_SearchOnsite.clear();
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("���� �˻�");
				alert.setHeaderText("��ȸ ĭ�� ������ �Է����ּ���.");
				alert.setContentText("�������� �����ϼ���!");
				alert.showAndWait();
				return;
			}
			txtS_SearchDate.clear();
			txtS_SearchLicenseenumber.clear();
			txtS_SearchCompany.clear();
			txtS_SearchOwner.clear();
			txtS_SearchOnsite.clear();

			if (list.size() != 0) {
				int rowCount = list.size();
				dataSales.removeAll(dataSales);
				for (int index = 0; index < rowCount; index++) {
					salesVO = list.get(index);
					dataSales.add(salesVO);
					sum_supplyValue = salesVO.getSupplyValue() + sum_supplyValue;
					sum_tax = salesVO.getTax() + sum_tax;
					sum_totalmoney = salesVO.getTotalmoney() + sum_totalmoney;
					sum_collection = salesVO.getCollection() + sum_collection;
					sum_outstanding = salesVO.getOutstanding() + sum_outstanding;
				}
				txtS_TotSupplyValue.setText(sum_supplyValue + "");
				txtS_TotTax.setText(sum_tax + "");
				txtS_TotTotalmoney.setText(sum_totalmoney + "");
				txtS_TotCollection.setText(sum_collection + "");
				txtS_TotOutstanding.setText(sum_outstanding + "");
			} else {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle(" ���� �˻�");
				alert.setHeaderText("������ ����Ʈ�� �����ϴ�.");
				alert.setContentText("�ٽ� �˻��ϼ���");
				alert.showAndWait();
			}

		} catch (Exception e) {
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("���� �˻� ����");
			alert.setHeaderText("���� �˻��� ������ �߻��Ͽ����ϴ�.");
			alert.setContentText("�ٽ� �ϼ���.");
			alert.showAndWait();
		}

	}

	public void handlerBtnP_SearchOnAtion(ActionEvent event) {
		// ��ġ�� 6������ ��ȸ���� ����Ǽ��� 63������.
		try {
			PurchaseVO purchaseVO = null;
			PurchaseDAO purchaseDAO = new PurchaseDAO();
			ArrayList<PurchaseVO> list = null;

			int i = 0;

			long sum_supplyValue = 0;
			long sum_tax = 0;
			long sum_totalmoney = 0;
			long sum_payment = 0;
			long sum_arrear = 0;

			String one = null;
			String two = null;
			String three = null;
			String four = null;
			String five = null;
			String six = null;
			if (!txtP_SearchDate.getText().trim().equals("") && txtP_SearchCompany.getText().trim().equals("")
					&& txtP_SearchOwner.getText().trim().equals("") && txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() == null && txtP_SearchDivision.getText().trim().equals("")) {
				i = 1;
				one = txtP_SearchDate.getText().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);

			} else if (txtP_SearchDate.getText().trim().equals("") && !txtP_SearchCompany.getText().trim().equals("")
					&& txtP_SearchOwner.getText().trim().equals("") && txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() == null && txtP_SearchDivision.getText().trim().equals("")) {
				i = 2;
				one = txtP_SearchCompany.getText().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (txtP_SearchDate.getText().trim().equals("") && txtP_SearchCompany.getText().trim().equals("")
					&& !txtP_SearchOwner.getText().trim().equals("") && txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() == null && txtP_SearchDivision.getText().trim().equals("")) {
				i = 3;
				one = txtP_SearchOwner.getText().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (txtP_SearchDate.getText().trim().equals("") && txtP_SearchCompany.getText().trim().equals("")
					&& txtP_SearchOwner.getText().trim().equals("") && !txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() == null && txtP_SearchDivision.getText().trim().equals("")) {
				i = 4;
				one = txtP_SearchOnsite.getText().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (txtP_SearchDate.getText().trim().equals("") && txtP_SearchCompany.getText().trim().equals("")
					&& txtP_SearchOwner.getText().trim().equals("") && txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() != null && txtP_SearchDivision.getText().trim().equals("")) {
				i = 5;
				one = tgP_SearchGroup.getSelectedToggle().getUserData().toString().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (txtP_SearchDate.getText().trim().equals("") && txtP_SearchCompany.getText().trim().equals("")
					&& txtP_SearchOwner.getText().trim().equals("") && txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() == null
					&& !txtP_SearchDivision.getText().trim().equals("")) {
				i = 6;
				one = txtP_SearchDivision.getText().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (!txtP_SearchDate.getText().trim().equals("") && !txtP_SearchCompany.getText().trim().equals("")
					&& txtP_SearchOwner.getText().trim().equals("") && txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() == null && txtP_SearchDivision.getText().trim().equals("")) {
				i = 7;
				one = txtP_SearchDate.getText().trim();
				two = txtP_SearchCompany.getText().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (!txtP_SearchDate.getText().trim().equals("") && txtP_SearchCompany.getText().trim().equals("")
					&& !txtP_SearchOwner.getText().trim().equals("") && txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() == null && txtP_SearchDivision.getText().trim().equals("")) {
				i = 8;
				one = txtP_SearchDate.getText().trim();
				two = txtP_SearchOwner.getText().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (!txtP_SearchDate.getText().trim().equals("") && txtP_SearchCompany.getText().trim().equals("")
					&& txtP_SearchOwner.getText().trim().equals("") && !txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() == null && txtP_SearchDivision.getText().trim().equals("")) {
				i = 9;
				one = txtP_SearchDate.getText().trim();
				two = txtP_SearchOnsite.getText().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (!txtP_SearchDate.getText().trim().equals("") && txtP_SearchCompany.getText().trim().equals("")
					&& txtP_SearchOwner.getText().trim().equals("") && txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() != null && txtP_SearchDivision.getText().trim().equals("")) {
				i = 10;
				one = txtP_SearchDate.getText().trim();
				two = tgP_SearchGroup.getSelectedToggle().getUserData().toString().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (!txtP_SearchDate.getText().trim().equals("") && txtP_SearchCompany.getText().trim().equals("")
					&& txtP_SearchOwner.getText().trim().equals("") && txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() == null
					&& !txtP_SearchDivision.getText().trim().equals("")) {
				i = 11;
				one = txtP_SearchDate.getText().trim();
				two = txtP_SearchDivision.getText().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (txtP_SearchDate.getText().trim().equals("") && !txtP_SearchCompany.getText().trim().equals("")
					&& !txtP_SearchOwner.getText().trim().equals("") && txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() == null && txtP_SearchDivision.getText().trim().equals("")) {
				i = 12;
				one = txtP_SearchCompany.getText().trim();
				two = txtP_SearchOwner.getText().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (txtP_SearchDate.getText().trim().equals("") && !txtP_SearchCompany.getText().trim().equals("")
					&& txtP_SearchOwner.getText().trim().equals("") && !txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() == null && txtP_SearchDivision.getText().trim().equals("")) {
				i = 13;
				one = txtP_SearchCompany.getText().trim();
				two = txtP_SearchOnsite.getText().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (txtP_SearchDate.getText().trim().equals("") && !txtP_SearchCompany.getText().trim().equals("")
					&& txtP_SearchOwner.getText().trim().equals("") && txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() != null && txtP_SearchDivision.getText().trim().equals("")) {
				i = 14;
				one = txtP_SearchCompany.getText().trim();
				two = tgP_SearchGroup.getSelectedToggle().getUserData().toString().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (txtP_SearchDate.getText().trim().equals("") && !txtP_SearchCompany.getText().trim().equals("")
					&& txtP_SearchOwner.getText().trim().equals("") && txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() == null
					&& !txtP_SearchDivision.getText().trim().equals("")) {
				i = 15;
				one = txtP_SearchCompany.getText().trim();
				two = txtP_SearchDivision.getText().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (txtP_SearchDate.getText().trim().equals("") && txtP_SearchCompany.getText().trim().equals("")
					&& !txtP_SearchOwner.getText().trim().equals("") && !txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() == null && txtP_SearchDivision.getText().trim().equals("")) {
				i = 16;
				one = txtP_SearchOwner.getText().trim();
				two = txtP_SearchOnsite.getText().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (txtP_SearchDate.getText().trim().equals("") && txtP_SearchCompany.getText().trim().equals("")
					&& !txtP_SearchOwner.getText().trim().equals("") && txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() != null && txtP_SearchDivision.getText().trim().equals("")) {
				i = 17;
				one = txtP_SearchOwner.getText().trim();
				two = tgP_SearchGroup.getSelectedToggle().getUserData().toString().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (txtP_SearchDate.getText().trim().equals("") && txtP_SearchCompany.getText().trim().equals("")
					&& !txtP_SearchOwner.getText().trim().equals("") && txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() == null
					&& !txtP_SearchDivision.getText().trim().equals("")) {
				i = 18;
				one = txtP_SearchOwner.getText().trim();
				two = txtP_SearchDivision.getText().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (txtP_SearchDate.getText().trim().equals("") && txtP_SearchCompany.getText().trim().equals("")
					&& txtP_SearchOwner.getText().trim().equals("") && !txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() != null && txtP_SearchDivision.getText().trim().equals("")) {
				i = 19;
				one = txtP_SearchOwner.getText().trim();
				two = tgP_SearchGroup.getSelectedToggle().getUserData().toString().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (txtP_SearchDate.getText().trim().equals("") && txtP_SearchCompany.getText().trim().equals("")
					&& txtP_SearchOwner.getText().trim().equals("") && !txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() == null
					&& !txtP_SearchDivision.getText().trim().equals("")) {
				i = 20;
				one = txtP_SearchOwner.getText().trim();
				two = txtP_SearchDivision.getText().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (txtP_SearchDate.getText().trim().equals("") && txtP_SearchCompany.getText().trim().equals("")
					&& txtP_SearchOwner.getText().trim().equals("") && txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() != null
					&& !txtP_SearchDivision.getText().trim().equals("")) {
				i = 21;
				one = tgP_SearchGroup.getSelectedToggle().getUserData().toString().trim();
				two = txtP_SearchDivision.getText().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (!txtP_SearchDate.getText().trim().equals("") && !txtP_SearchCompany.getText().trim().equals("")
					&& !txtP_SearchOwner.getText().trim().equals("") && txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() == null && txtP_SearchDivision.getText().trim().equals("")) {
				i = 22;
				one = txtP_SearchDate.getText().trim();
				two = txtP_SearchCompany.getText().trim();
				three = txtP_SearchOwner.getText().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (!txtP_SearchDate.getText().trim().equals("") && !txtP_SearchCompany.getText().trim().equals("")
					&& txtP_SearchOwner.getText().trim().equals("") && !txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() == null && txtP_SearchDivision.getText().trim().equals("")) {
				i = 23;
				one = txtP_SearchDate.getText().trim();
				two = txtP_SearchCompany.getText().trim();
				three = txtP_SearchOnsite.getText().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (!txtP_SearchDate.getText().trim().equals("") && !txtP_SearchCompany.getText().trim().equals("")
					&& txtP_SearchOwner.getText().trim().equals("") && txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() != null && txtP_SearchDivision.getText().trim().equals("")) {
				i = 24;
				one = txtP_SearchDate.getText().trim();
				two = txtP_SearchCompany.getText().trim();
				three = tgP_SearchGroup.getSelectedToggle().getUserData().toString().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (!txtP_SearchDate.getText().trim().equals("") && !txtP_SearchCompany.getText().trim().equals("")
					&& txtP_SearchOwner.getText().trim().equals("") && txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() == null
					&& !txtP_SearchDivision.getText().trim().equals("")) {
				i = 25;
				one = txtP_SearchDate.getText().trim();
				two = txtP_SearchCompany.getText().trim();
				three = txtP_SearchDivision.getText().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (!txtP_SearchDate.getText().trim().equals("") && txtP_SearchCompany.getText().trim().equals("")
					&& !txtP_SearchOwner.getText().trim().equals("") && !txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() == null && txtP_SearchDivision.getText().trim().equals("")) {
				i = 26;
				one = txtP_SearchDate.getText().trim();
				two = txtP_SearchOwner.getText().trim();
				three = txtP_SearchOnsite.getText().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (!txtP_SearchDate.getText().trim().equals("") && txtP_SearchCompany.getText().trim().equals("")
					&& !txtP_SearchOwner.getText().trim().equals("") && txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() != null && txtP_SearchDivision.getText().trim().equals("")) {
				i = 27;
				one = txtP_SearchDate.getText().trim();
				two = txtP_SearchOwner.getText().trim();
				three = tgP_SearchGroup.getSelectedToggle().getUserData().toString().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (!txtP_SearchDate.getText().trim().equals("") && txtP_SearchCompany.getText().trim().equals("")
					&& !txtP_SearchOwner.getText().trim().equals("") && txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() == null
					&& !txtP_SearchDivision.getText().trim().equals("")) {
				i = 28;
				one = txtP_SearchDate.getText().trim();
				two = txtP_SearchOwner.getText().trim();
				three = txtP_SearchDivision.getText().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (!txtP_SearchDate.getText().trim().equals("") && txtP_SearchCompany.getText().trim().equals("")
					&& txtP_SearchOwner.getText().trim().equals("") && !txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() != null && txtP_SearchDivision.getText().trim().equals("")) {
				i = 29;
				one = txtP_SearchDate.getText().trim();
				two = txtP_SearchOnsite.getText().trim();
				three = tgP_SearchGroup.getSelectedToggle().getUserData().toString().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (!txtP_SearchDate.getText().trim().equals("") && txtP_SearchCompany.getText().trim().equals("")
					&& txtP_SearchOwner.getText().trim().equals("") && !txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() == null
					&& !txtP_SearchDivision.getText().trim().equals("")) {
				i = 30;
				one = txtP_SearchDate.getText().trim();
				two = txtP_SearchOnsite.getText().trim();
				three = txtP_SearchDivision.getText().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (!txtP_SearchDate.getText().trim().equals("") && txtP_SearchCompany.getText().trim().equals("")
					&& txtP_SearchOwner.getText().trim().equals("") && txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() != null
					&& !txtP_SearchDivision.getText().trim().equals("")) {
				i = 31;
				one = txtP_SearchDate.getText().trim();
				two = tgP_SearchGroup.getSelectedToggle().getUserData().toString().trim();
				three = txtP_SearchDivision.getText().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (txtP_SearchDate.getText().trim().equals("") && !txtP_SearchCompany.getText().trim().equals("")
					&& !txtP_SearchOwner.getText().trim().equals("") && !txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() == null && txtP_SearchDivision.getText().trim().equals("")) {
				i = 32;
				one = txtP_SearchCompany.getText().trim();
				two = txtP_SearchOwner.getText().trim();
				three = txtP_SearchOnsite.getText().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (txtP_SearchDate.getText().trim().equals("") && !txtP_SearchCompany.getText().trim().equals("")
					&& !txtP_SearchOwner.getText().trim().equals("") && txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() != null && txtP_SearchDivision.getText().trim().equals("")) {
				i = 33;
				one = txtP_SearchCompany.getText().trim();
				two = txtP_SearchOwner.getText().trim();
				three = tgP_SearchGroup.getSelectedToggle().getUserData().toString().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (txtP_SearchDate.getText().trim().equals("") && !txtP_SearchCompany.getText().trim().equals("")
					&& !txtP_SearchOwner.getText().trim().equals("") && txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() == null
					&& !txtP_SearchDivision.getText().trim().equals("")) {
				i = 34;
				one = txtP_SearchCompany.getText().trim();
				two = txtP_SearchOwner.getText().trim();
				three = txtP_SearchDivision.getText().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (txtP_SearchDate.getText().trim().equals("") && !txtP_SearchCompany.getText().trim().equals("")
					&& txtP_SearchOwner.getText().trim().equals("") && !txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() != null && txtP_SearchDivision.getText().trim().equals("")) {
				i = 35;
				one = txtP_SearchCompany.getText().trim();
				two = txtP_SearchOnsite.getText().trim();
				three = tgP_SearchGroup.getSelectedToggle().getUserData().toString().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (txtP_SearchDate.getText().trim().equals("") && !txtP_SearchCompany.getText().trim().equals("")
					&& txtP_SearchOwner.getText().trim().equals("") && !txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() == null
					&& !txtP_SearchDivision.getText().trim().equals("")) {
				i = 36;
				one = txtP_SearchCompany.getText().trim();
				two = txtP_SearchOnsite.getText().trim();
				three = txtP_SearchDivision.getText().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (txtP_SearchDate.getText().trim().equals("") && !txtP_SearchCompany.getText().trim().equals("")
					&& txtP_SearchOwner.getText().trim().equals("") && txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() != null
					&& !txtP_SearchDivision.getText().trim().equals("")) {
				i = 37;
				one = txtP_SearchCompany.getText().trim();
				two = tgP_SearchGroup.getSelectedToggle().getUserData().toString().trim();
				three = txtP_SearchDivision.getText().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (txtP_SearchDate.getText().trim().equals("") && txtP_SearchCompany.getText().trim().equals("")
					&& !txtP_SearchOwner.getText().trim().equals("") && !txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() != null && txtP_SearchDivision.getText().trim().equals("")) {
				i = 38;
				one = txtP_SearchOwner.getText().trim();
				two = txtP_SearchOnsite.getText().trim();
				three = tgP_SearchGroup.getSelectedToggle().getUserData().toString().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (txtP_SearchDate.getText().trim().equals("") && txtP_SearchCompany.getText().trim().equals("")
					&& !txtP_SearchOwner.getText().trim().equals("") && !txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() == null
					&& !txtP_SearchDivision.getText().trim().equals("")) {
				i = 39;
				one = txtP_SearchOwner.getText().trim();
				two = txtP_SearchOnsite.getText().trim();
				three = txtP_SearchDivision.getText().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (txtP_SearchDate.getText().trim().equals("") && txtP_SearchCompany.getText().trim().equals("")
					&& !txtP_SearchOwner.getText().trim().equals("") && txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() != null
					&& !txtP_SearchDivision.getText().trim().equals("")) {
				i = 40;
				one = txtP_SearchOwner.getText().trim();
				two = tgP_SearchGroup.getSelectedToggle().getUserData().toString().trim();
				three = txtP_SearchDivision.getText().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (txtP_SearchDate.getText().trim().equals("") && txtP_SearchCompany.getText().trim().equals("")
					&& txtP_SearchOwner.getText().trim().equals("") && !txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() != null
					&& !txtP_SearchDivision.getText().trim().equals("")) {
				i = 41;
				one = txtP_SearchOnsite.getText().trim();
				two = tgP_SearchGroup.getSelectedToggle().getUserData().toString().trim();
				three = txtP_SearchDivision.getText().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (!txtP_SearchDate.getText().trim().equals("") && !txtP_SearchCompany.getText().trim().equals("")
					&& !txtP_SearchOwner.getText().trim().equals("") && !txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() == null && txtP_SearchDivision.getText().trim().equals("")) {
				i = 42;
				one = txtP_SearchDate.getText().trim();
				two = txtP_SearchCompany.getText().trim();
				three = txtP_SearchOwner.getText().trim();
				four = txtP_SearchOnsite.getText().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (!txtP_SearchDate.getText().trim().equals("") && !txtP_SearchCompany.getText().trim().equals("")
					&& !txtP_SearchOwner.getText().trim().equals("") && txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() != null && txtP_SearchDivision.getText().trim().equals("")) {
				i = 43;
				one = txtP_SearchDate.getText().trim();
				two = txtP_SearchCompany.getText().trim();
				three = txtP_SearchOwner.getText().trim();
				four = tgP_SearchGroup.getSelectedToggle().getUserData().toString().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (!txtP_SearchDate.getText().trim().equals("") && !txtP_SearchCompany.getText().trim().equals("")
					&& !txtP_SearchOwner.getText().trim().equals("") && txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() == null
					&& !txtP_SearchDivision.getText().trim().equals("")) {
				i = 44;
				one = txtP_SearchDate.getText().trim();
				two = txtP_SearchCompany.getText().trim();
				three = txtP_SearchOwner.getText().trim();
				four = txtP_SearchDivision.getText().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (!txtP_SearchDate.getText().trim().equals("") && !txtP_SearchCompany.getText().trim().equals("")
					&& txtP_SearchOwner.getText().trim().equals("") && !txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() != null && txtP_SearchDivision.getText().trim().equals("")) {
				i = 45;
				one = txtP_SearchDate.getText().trim();
				two = txtP_SearchCompany.getText().trim();
				three = txtP_SearchOnsite.getText().trim();
				four = tgP_SearchGroup.getSelectedToggle().getUserData().toString().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (!txtP_SearchDate.getText().trim().equals("") && !txtP_SearchCompany.getText().trim().equals("")
					&& txtP_SearchOwner.getText().trim().equals("") && !txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() == null
					&& !txtP_SearchDivision.getText().trim().equals("")) {
				i = 46;
				one = txtP_SearchDate.getText().trim();
				two = txtP_SearchCompany.getText().trim();
				three = txtP_SearchOnsite.getText().trim();
				four = txtP_SearchDivision.getText().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (!txtP_SearchDate.getText().trim().equals("") && !txtP_SearchCompany.getText().trim().equals("")
					&& txtP_SearchOwner.getText().trim().equals("") && txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() != null
					&& !txtP_SearchDivision.getText().trim().equals("")) {
				i = 47;
				one = txtP_SearchDate.getText().trim();
				two = txtP_SearchCompany.getText().trim();
				three = tgP_SearchGroup.getSelectedToggle().getUserData().toString().trim();
				four = txtP_SearchDivision.getText().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (!txtP_SearchDate.getText().trim().equals("") && txtP_SearchCompany.getText().trim().equals("")
					&& !txtP_SearchOwner.getText().trim().equals("") && !txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() != null && txtP_SearchDivision.getText().trim().equals("")) {
				i = 48;
				one = txtP_SearchDate.getText().trim();
				two = txtP_SearchOwner.getText().trim();
				three = txtP_SearchOnsite.getText().trim();
				four = tgP_SearchGroup.getSelectedToggle().getUserData().toString().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (!txtP_SearchDate.getText().trim().equals("") && txtP_SearchCompany.getText().trim().equals("")
					&& !txtP_SearchOwner.getText().trim().equals("") && !txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() == null
					&& !txtP_SearchDivision.getText().trim().equals("")) {
				i = 49;
				one = txtP_SearchDate.getText().trim();
				two = txtP_SearchOwner.getText().trim();
				three = txtP_SearchOnsite.getText().trim();
				four = txtP_SearchDivision.getText().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (!txtP_SearchDate.getText().trim().equals("") && txtP_SearchCompany.getText().trim().equals("")
					&& !txtP_SearchOwner.getText().trim().equals("") && txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() != null
					&& !txtP_SearchDivision.getText().trim().equals("")) {
				i = 50;
				one = txtP_SearchDate.getText().trim();
				two = txtP_SearchOwner.getText().trim();
				three = tgP_SearchGroup.getSelectedToggle().getUserData().toString().trim();
				four = txtP_SearchDivision.getText().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (!txtP_SearchDate.getText().trim().equals("") && txtP_SearchCompany.getText().trim().equals("")
					&& txtP_SearchOwner.getText().trim().equals("") && !txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() != null
					&& !txtP_SearchDivision.getText().trim().equals("")) {
				i = 51;
				one = txtP_SearchDate.getText().trim();
				two = txtP_SearchOnsite.getText().trim();
				three = tgP_SearchGroup.getSelectedToggle().getUserData().toString().trim();
				four = txtP_SearchDivision.getText().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (txtP_SearchDate.getText().trim().equals("") && !txtP_SearchCompany.getText().trim().equals("")
					&& !txtP_SearchOwner.getText().trim().equals("") && !txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() != null && txtP_SearchDivision.getText().trim().equals("")) {
				i = 52;
				one = txtP_SearchCompany.getText().trim();
				two = txtP_SearchOwner.getText().trim();
				three = txtP_SearchOnsite.getText().trim();
				four = tgP_SearchGroup.getSelectedToggle().getUserData().toString().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (txtP_SearchDate.getText().trim().equals("") && !txtP_SearchCompany.getText().trim().equals("")
					&& !txtP_SearchOwner.getText().trim().equals("") && !txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() == null
					&& !txtP_SearchDivision.getText().trim().equals("")) {
				i = 53;
				one = txtP_SearchCompany.getText().trim();
				two = txtP_SearchOwner.getText().trim();
				three = txtP_SearchOnsite.getText().trim();
				four = txtP_SearchDivision.getText().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (txtP_SearchDate.getText().trim().equals("") && !txtP_SearchCompany.getText().trim().equals("")
					&& !txtP_SearchOwner.getText().trim().equals("") && txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() != null
					&& !txtP_SearchDivision.getText().trim().equals("")) {
				i = 54;
				one = txtP_SearchCompany.getText().trim();
				two = txtP_SearchOwner.getText().trim();
				three = tgP_SearchGroup.getSelectedToggle().getUserData().toString().trim();
				four = txtP_SearchDivision.getText().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (txtP_SearchDate.getText().trim().equals("") && !txtP_SearchCompany.getText().trim().equals("")
					&& txtP_SearchOwner.getText().trim().equals("") && !txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() != null
					&& !txtP_SearchDivision.getText().trim().equals("")) {
				i = 55;
				one = txtP_SearchCompany.getText().trim();
				two = txtP_SearchOnsite.getText().trim();
				three = tgP_SearchGroup.getSelectedToggle().getUserData().toString().trim();
				four = txtP_SearchDivision.getText().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (txtP_SearchDate.getText().trim().equals("") && txtP_SearchCompany.getText().trim().equals("")
					&& !txtP_SearchOwner.getText().trim().equals("") && !txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() != null
					&& !txtP_SearchDivision.getText().trim().equals("")) {
				i = 56;
				one = txtP_SearchOwner.getText().trim();
				two = txtP_SearchOnsite.getText().trim();
				three = tgP_SearchGroup.getSelectedToggle().getUserData().toString().trim();
				four = txtP_SearchDivision.getText().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (!txtP_SearchDate.getText().trim().equals("") && !txtP_SearchCompany.getText().trim().equals("")
					&& !txtP_SearchOwner.getText().trim().equals("") && !txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() != null && txtP_SearchDivision.getText().trim().equals("")) {
				i = 57;
				one = txtP_SearchDate.getText().trim();
				two = txtP_SearchCompany.getText().trim();
				three = txtP_SearchOwner.getText().trim();
				four = txtP_SearchOnsite.getText().trim();
				five = tgP_SearchGroup.getSelectedToggle().getUserData().toString().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (!txtP_SearchDate.getText().trim().equals("") && !txtP_SearchCompany.getText().trim().equals("")
					&& !txtP_SearchOwner.getText().trim().equals("") && !txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() == null
					&& !txtP_SearchDivision.getText().trim().equals("")) {
				i = 58;
				one = txtP_SearchDate.getText().trim();
				two = txtP_SearchCompany.getText().trim();
				three = txtP_SearchOwner.getText().trim();
				four = txtP_SearchOnsite.getText().trim();
				five = txtP_SearchDivision.getText().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (!txtP_SearchDate.getText().trim().equals("") && !txtP_SearchCompany.getText().trim().equals("")
					&& !txtP_SearchOwner.getText().trim().equals("") && txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() != null
					&& !txtP_SearchDivision.getText().trim().equals("")) {
				i = 59;
				one = txtP_SearchDate.getText().trim();
				two = txtP_SearchCompany.getText().trim();
				three = txtP_SearchOwner.getText().trim();
				four = tgP_SearchGroup.getSelectedToggle().getUserData().toString().trim();
				five = txtP_SearchDivision.getText().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (!txtP_SearchDate.getText().trim().equals("") && !txtP_SearchCompany.getText().trim().equals("")
					&& txtP_SearchOwner.getText().trim().equals("") && !txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() != null
					&& !txtP_SearchDivision.getText().trim().equals("")) {
				i = 60;
				one = txtP_SearchDate.getText().trim();
				two = txtP_SearchCompany.getText().trim();
				three = txtP_SearchOnsite.getText().trim();
				four = tgP_SearchGroup.getSelectedToggle().getUserData().toString().trim();
				five = txtP_SearchDivision.getText().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (!txtP_SearchDate.getText().trim().equals("") && txtP_SearchCompany.getText().trim().equals("")
					&& !txtP_SearchOwner.getText().trim().equals("") && !txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() != null
					&& !txtP_SearchDivision.getText().trim().equals("")) {
				i = 61;
				one = txtP_SearchDate.getText().trim();
				two = txtP_SearchOwner.getText().trim();
				three = txtP_SearchOnsite.getText().trim();
				four = tgP_SearchGroup.getSelectedToggle().getUserData().toString().trim();
				five = txtP_SearchDivision.getText().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (txtP_SearchDate.getText().trim().equals("") && !txtP_SearchCompany.getText().trim().equals("")
					&& !txtP_SearchOwner.getText().trim().equals("") && !txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() != null
					&& !txtP_SearchDivision.getText().trim().equals("")) {
				i = 62;
				one = txtP_SearchCompany.getText().trim();
				two = txtP_SearchOwner.getText().trim();
				three = txtP_SearchOnsite.getText().trim();
				four = tgP_SearchGroup.getSelectedToggle().getUserData().toString().trim();
				five = txtP_SearchDivision.getText().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else if (!txtP_SearchDate.getText().trim().equals("") && !txtP_SearchCompany.getText().trim().equals("")
					&& !txtP_SearchOwner.getText().trim().equals("") && !txtP_SearchOnsite.getText().trim().equals("")
					&& tgP_SearchGroup.getSelectedToggle() != null
					&& !txtP_SearchDivision.getText().trim().equals("")) {
				i = 63;
				one = txtP_SearchDate.getText().trim();
				two = txtP_SearchCompany.getText().trim();
				three = txtP_SearchOwner.getText().trim();
				four = txtP_SearchOnsite.getText().trim();
				five = tgP_SearchGroup.getSelectedToggle().getUserData().toString().trim();
				six = txtP_SearchDivision.getText().trim();
				list = purchaseDAO.getPurchaseSearch(one, two, three, four, five, six, i);
			} else {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("���� �˻�");
				alert.setHeaderText("��ȸ ĭ�� ������ �Է����ּ���.");
				alert.setContentText("�������� �����ϼ���!");
				alert.showAndWait();
				return;
			}
			txtP_SearchDate.clear();
			txtP_SearchCompany.clear();
			txtP_SearchOwner.clear();
			txtP_SearchOnsite.clear();
			tgP_SearchGroup.selectToggle(null);
			txtP_SearchDivision.clear();

			DecimalFormat format = new DecimalFormat("###,###,###");

			if (list.size() != 0) {
				int rowCount = list.size();
				dataPurchase.removeAll(dataPurchase);
				for (int index = 0; index < rowCount; index++) {
					purchaseVO = list.get(index);
					dataPurchase.add(purchaseVO);
					sum_supplyValue = purchaseVO.getSupplyValue() + sum_supplyValue;
					sum_tax = purchaseVO.getTax() + sum_tax;
					sum_totalmoney = purchaseVO.getTotalmoney() + sum_totalmoney;
					sum_payment = purchaseVO.getPayment() + sum_payment;
					sum_arrear = purchaseVO.getArrear() + sum_arrear;
				}
				txtP_TotSupplyValue.setText(sum_supplyValue + "");
				txtP_TotTax.setText(sum_tax + "");
				txtP_TotTotalmoney.setText(sum_totalmoney + "");
				txtP_TotPayment.setText(sum_payment + "");
				/* txtP_TotPayment.setText(format.parse(sum_payment+"")+""); */
				txtP_TotArrear.setText(sum_arrear + "");
			} else {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle(" ���� �˻�");
				alert.setHeaderText("������ ����Ʈ�� �����ϴ�.");
				alert.setContentText("�ٽ� �˻��ϼ���");
				alert.showAndWait();
			}

		} catch (Exception e) {
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("���� �˻� ����");
			alert.setHeaderText("���� �˻��� ������ �߻��Ͽ����ϴ�.");
			alert.setContentText("�ٽ� �ϼ���.");
			alert.showAndWait();
		}
	}

	/****************************
	 * totalList�� ���� tableview �� sql�� �����Ǿ� �ԷµǾ��� ��� ���� �ҷ��´�. ��ü �����迭�� ���, ���� ���� �÷�
	 * ���� ���, Ȱ���Ѵ�.
	 * 
	 ****************************/
	public void totalList() {
		Object[][] totalS_Data;
		SalesDAO salesDAO = new SalesDAO();
		SalesVO salesVO = new SalesVO();
		ArrayList<String> title;
		ArrayList<SalesVO> list;

		title = salesDAO.getColumnName();
		int columnCount = title.size();

		list = salesDAO.getSalesTotal();
		int rowCount = list.size();
		totalS_Data = new Object[rowCount][columnCount];

		for (int index = 0; index < rowCount; index++) {
			salesVO = list.get(index);
			dataSales.add(salesVO);
		}

	}

	public void p_TotalList() {
		Object[][] totalP_Data;
		PurchaseDAO purchaseDAO = new PurchaseDAO();
		PurchaseVO purchaseVO = new PurchaseVO();

		ArrayList<String> title;
		ArrayList<PurchaseVO> list;
		// ���ϰ��� ������ ī��Ʈ�Ͽ� �迭�� ���
		title = purchaseDAO.getColumnName();
		int columnCount = title.size();

		list = purchaseDAO.getPurchaseTotal();
		int rowCount = list.size();

		totalP_Data = new Object[rowCount][columnCount];

		for (int index = 0; index < rowCount; index++) {
			purchaseVO = list.get(index);
			dataPurchase.add(purchaseVO);
		}
	}

	// �ʱ�ȭ �޼ҵ�
	public void handleBtnS_Init(ActionEvent event) {
		btnS_Ok.setDisable(true);
		btnS_Modify.setDisable(true);
		btnS_Re_InputInit.setDisable(true);
		btnS_Delete.setDisable(true);
		btnS_Search.setDisable(false);

		txtS_Date.clear();
		txtS_Licenseenumber.clear();
		txtS_Owner.clear();
		txtS_Company.clear();
		txtS_SupplyValue.setText(0 + "");
		txtS_Tax.setText(0 + "");
		/* txtS_Totalmoney.clear(); */

		txtS_Totalmoney.setText(0 + "");
		txtS_Item.clear();
		txtS_Onsite.clear();
		txtS_Collection.setText(0 + "");
		txtS_Outstanding.setText(0 + "");
		txtS_Duedate.clear();
		txtS_Contact.clear();
		txtS_Note.clear();
		txtS_Depositdate_One.clear();
		txtS_Receipts_One.clear();
		txtS_Deposit_One.setText(0 + "");
		txtS_Deposit_Two.setText(0 + "");
		txtS_Depositdate_Two.clear();
		txtS_Receipts_Two.clear();
		txtS_Deposit_Three.setText(0 + "");
		txtS_Depositdate_Three.clear();
		txtS_Receipts_Three.clear();
		txtS_Deposit_Four.setText(0 + "");
		txtS_Depositdate_Four.clear();
		txtS_Receipts_Four.clear();
		txtS_Deposit_Five.setText(0 + "");
		txtS_Depositdate_Five.clear();
		txtS_Receipts_Five.clear();
		txtS_Deposit_Six.setText(0 + "");
		txtS_Depositdate_Six.clear();
		txtS_Receipts_Six.clear();
		txtS_Deposit_Seven.setText(0 + "");
		txtS_Depositdate_Seven.clear();
		txtS_Receipts_Seven.clear();
		txtS_SearchDate.clear();
		txtS_SearchLicenseenumber.clear();
		txtS_SearchCompany.clear();
		txtS_SearchOwner.clear();
		txtS_SearchOnsite.clear();
		txtS_TotSupplyValue.clear();
		txtS_TotTax.clear();
		txtS_TotTotalmoney.clear();
		txtS_TotCollection.clear();
		txtS_TotOutstanding.clear();

		selectSales = null;

	}

	public void handleBtnP_Init(ActionEvent event) {
		btnP_Ok.setDisable(true);
		btnP_Modify.setDisable(true);
		btnP_Re_InputInit.setDisable(true);
		btnP_Delete.setDisable(true);
		btnP_Search.setDisable(false);
		txtP_SaveFileDir.clear();
		txtP_Date.clear();
		txtP_Licenseenumber.clear();
		txtP_Owner.clear();
		txtP_Company.clear();
		txtP_SupplyValue.setText(0 + "");
		txtP_Tax.setText(0 + "");
		/* txtP_Totalmoney.clear(); */

		txtP_Totalmoney.setText(0 + "");
		txtP_Item.clear();
		txtP_Onsite.clear();
		txtP_Transactionaccount.clear();
		txtP_Accountholder.clear();
		txtP_Bank.clear();
		txtP_Payment.setText(0 + "");
		txtP_Arrear.setText(0 + "");
		tgP_group.selectToggle(null);
		txtP_Givedate.clear();
		txtP_Contact.clear();
		cbP_Division.getSelectionModel().clearSelection();
		txtP_Note.clear();
		txtP_Depositdate_One.clear();
		txtP_Receipts_One.clear();
		txtP_Deposit_One.setText(0 + "");
		txtP_Deposit_Two.setText(0 + "");
		txtP_Depositdate_Two.clear();
		txtP_Receipts_Two.clear();
		txtP_Deposit_Three.setText(0 + "");
		txtP_Depositdate_Three.clear();
		txtP_Receipts_Three.clear();
		txtP_Deposit_Four.setText(0 + "");
		txtP_Depositdate_Four.clear();
		txtP_Receipts_Four.clear();
		txtP_Deposit_Five.setText(0 + "");
		txtP_Depositdate_Five.clear();
		txtP_Receipts_Five.clear();
		txtP_Deposit_Six.setText(0 + "");
		txtP_Depositdate_Six.clear();
		txtP_Receipts_Six.clear();
		txtP_Deposit_Seven.setText(0 + "");
		txtP_Depositdate_Seven.clear();
		txtP_Receipts_Seven.clear();
		txtP_SearchDate.clear();
		/* txtP_SearchLicenseenumber.clear(); */
		txtP_SearchCompany.clear();
		txtP_SearchOwner.clear();
		txtP_SearchOnsite.clear();
		tgP_SearchGroup.selectToggle(null);
		txtP_SearchDivision.clear();
		txtP_TotSupplyValue.clear();
		txtP_TotTax.clear();
		txtP_TotTotalmoney.clear();
		txtP_TotPayment.clear();
		txtP_TotArrear.clear();

		selectPurchase = null;

	}
}
