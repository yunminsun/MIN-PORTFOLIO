package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.spi.DirStateFactory.Result;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import model.SalesVO;

public class SalesDAO {
	/***************************
	 * �����Է� �޼ҵ� ��Ʈ�����۸� �̿� append ������� Ŀ������ �Ѵܾ� ���� �������� �����Ͽ���. preparedStatement ��
	 * �̿��Ͽ� ����ڰ� �Է��� ���� �־��ش�. ?�� textfile���� �����״�.
	 * 
	 ***************************************/
	public SalesVO getSalesRegister(SalesVO salesVO) throws Exception {
		// (��Ʈ�� ���۴� ����ȭ�� �������ش�) ����� ������ �̿�����
		StringBuffer sql = new StringBuffer();
		sql.append("insert into sales ");
		sql.append(" (s_number, s_date, s_licenseenumber, s_company, s_owner, s_supplyValue,"
				+ "s_tax, s_totalmoney, s_item, s_onsite, s_collection, s_outstanding, s_duedate,"
				+ "s_contact, s_note,s_depositdate_One,s_receipts_One, s_deposit_One,"
				+ "s_depositdate_Two,s_receipts_Two, s_deposit_Two, s_depositdate_Three,"
				+ "s_receipts_Three, s_deposit_Three, s_depositdate_Four, s_receipts_Four, s_deposit_Four,"
				+ "s_depositdate_Five, s_receipts_Five, s_deposit_Five, s_depositdate_Six,"
				+ "s_receipts_Six, s_deposit_Six, s_depositdate_Seven, s_receipts_Seven, s_deposit_Seven)");
		sql.append(" values (salse_seq.nextval, ?, ?, ?, ?, ?,"
				+ "?,?,?, ?, ?, ?, ?,?, ?,?,?, ?,?,?, ?, ?,?, ?, ?, ?, ?,?, ?, ?, ?,?, ?, ?, ?, ?)");
		// db���ᰪ
		Connection connection = null;
		// ?? ��
		PreparedStatement preparedStatement = null;

		SalesVO sVo = salesVO;

		try {
			// db����
			connection = DBUtil.getConnection();
			// append . sql Ŀ������ ���� ���
			preparedStatement = connection.prepareStatement(sql.toString());
			// ? �ڸ�����
			preparedStatement.setString(1, sVo.getDate());
			preparedStatement.setString(2, sVo.getLicenseenumber());
			preparedStatement.setString(3, sVo.getCompany());
			preparedStatement.setString(4, sVo.getOwner());
			preparedStatement.setLong(5, sVo.getSupplyValue());
			preparedStatement.setLong(6, sVo.getTax());
			preparedStatement.setLong(7, sVo.getTotalmoney());
			preparedStatement.setString(8, sVo.getItem());
			preparedStatement.setString(9, sVo.getOnsite());
			preparedStatement.setLong(10, sVo.getCollection());
			preparedStatement.setLong(11, sVo.getOutstanding());
			preparedStatement.setString(12, sVo.getDuedate());
			preparedStatement.setString(13, sVo.getContact());
			preparedStatement.setString(14, sVo.getNote());
			preparedStatement.setString(15, sVo.getDepositdate_One());
			preparedStatement.setString(16, sVo.getReceipts_One());
			preparedStatement.setLong(17, sVo.getDeposit_One());
			preparedStatement.setString(18, sVo.getDepositdate_Two());
			preparedStatement.setString(19, sVo.getReceipts_Two());
			preparedStatement.setLong(20, sVo.getDeposit_Two());
			preparedStatement.setString(21, sVo.getDepositdate_Three());
			preparedStatement.setString(22, sVo.getReceipts_Three());
			preparedStatement.setLong(23, sVo.getDeposit_Three());
			preparedStatement.setString(24, sVo.getDepositdate_Four());
			preparedStatement.setString(25, sVo.getReceipts_Four());
			preparedStatement.setLong(26, sVo.getDeposit_Four());
			preparedStatement.setString(27, sVo.getDepositdate_Five());
			preparedStatement.setString(28, sVo.getReceipts_Five());
			preparedStatement.setLong(29, sVo.getDeposit_Five());
			preparedStatement.setString(30, sVo.getDepositdate_Six());
			preparedStatement.setString(31, sVo.getReceipts_Six());
			preparedStatement.setLong(32, sVo.getDeposit_Six());
			preparedStatement.setString(33, sVo.getDepositdate_Seven());
			preparedStatement.setString(34, sVo.getReceipts_Seven());
			preparedStatement.setLong(35, sVo.getDeposit_Seven());
			// ������ i�� ��´�.
			int i = preparedStatement.executeUpdate();

		} catch (SQLException e) {
			System.out.println("SQL = [" + e + "]");
			// ����� �־��ֱ�
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
				if (connection != null)
					connection.close();
			} catch (SQLException e) {

			}
		}

		return sVo;

	}

	// ��ü���
	public ArrayList<SalesVO> getSalesTotal() {
		// ��̸���Ʈ�� �����Ͽ� �ν���Ʈ ��Ų��
		ArrayList<SalesVO> list = new ArrayList<>();
		// ����Ʈ�� �ش� ���ϴ� ���� �ִ´�.
		StringBuffer sql = new StringBuffer();
		sql.append("select s_number , s_date , s_licenseenumber , s_company, s_owner , s_supplyValue , "
				+ "s_tax , s_totalmoney , s_item , s_onsite , s_collection , s_outstanding , s_duedate , "
				+ "s_contact, s_note ,s_depositdate_One , s_receipts_One , s_deposit_One , "
				+ "s_depositdate_Two ,s_receipts_Two , s_deposit_Two , s_depositdate_Three , "
				+ "s_receipts_Three , s_deposit_Three , s_depositdate_Four , s_receipts_Four , s_deposit_Four , "
				+ "s_depositdate_Five , s_receipts_Five , s_deposit_Five , s_depositdate_Six , "
				+ "s_receipts_Six , s_deposit_Six , s_depositdate_Seven , s_receipts_Seven , s_deposit_Seven ");

		sql.append(" from sales order by s_date desc ");
		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		SalesVO salesVO = null;
		try {
			// db�� �����ϰ� �ۼ��� Ŀ������ �����о� ������Ʈ��Ʈ�� �ű��� �迭ȭ ��Ű�� �����Ѵ�.
			con = DBUtil.getConnection();
			preparedStatement = con.prepareStatement(sql.toString());
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				salesVO = new SalesVO();
				salesVO.setNumber(resultSet.getInt("s_number"));
				salesVO.setDate(resultSet.getDate("s_date") + "");
				salesVO.setLicenseenumber(resultSet.getString("s_licenseenumber"));
				salesVO.setCompany(resultSet.getString("s_company"));
				salesVO.setOwner(resultSet.getString("s_owner"));
				salesVO.setSupplyValue(resultSet.getLong("s_supplyValue"));
				salesVO.setTax(resultSet.getLong("S_tax"));
				salesVO.setTotalmoney(resultSet.getLong("s_totalmoney"));
				salesVO.setItem(resultSet.getString("s_item"));
				salesVO.setOnsite(resultSet.getString("s_onsite"));
				salesVO.setCollection(resultSet.getLong("s_collection"));
				salesVO.setOutstanding(resultSet.getLong("s_outstanding"));
				salesVO.setDuedate(resultSet.getString("s_duedate"));
				salesVO.setContact(resultSet.getString("s_contact"));
				salesVO.setNote(resultSet.getString("s_note"));
				salesVO.setDepositdate_One(resultSet.getString("s_depositdate_One"));
				salesVO.setReceipts_One(resultSet.getString("s_receipts_One"));
				salesVO.setDeposit_One(resultSet.getLong("s_deposit_One"));
				salesVO.setDepositdate_Two(resultSet.getString("s_depositdate_Two"));
				salesVO.setReceipts_Two(resultSet.getString("s_receipts_Two"));
				salesVO.setDeposit_Two(resultSet.getLong("s_deposit_Two"));
				salesVO.setDepositdate_Three(resultSet.getString("s_depositdate_Three"));
				salesVO.setReceipts_Three(resultSet.getString("s_receipts_Three"));
				salesVO.setDeposit_Three(resultSet.getLong("s_deposit_Three"));
				salesVO.setDepositdate_Four(resultSet.getString("s_depositdate_Four"));
				salesVO.setReceipts_Four(resultSet.getString("s_receipts_Four"));
				salesVO.setDeposit_Four(resultSet.getLong("s_deposit_Four"));
				salesVO.setDepositdate_Five(resultSet.getString("s_depositdate_Five"));
				salesVO.setReceipts_Five(resultSet.getString("s_receipts_Five"));
				salesVO.setDeposit_Five(resultSet.getLong("s_deposit_Five"));
				salesVO.setDepositdate_Six(resultSet.getString("s_depositdate_Six"));
				salesVO.setReceipts_Six(resultSet.getString("s_receipts_Six"));
				salesVO.setDeposit_Six(resultSet.getLong("s_deposit_Six"));
				salesVO.setDepositdate_Seven(resultSet.getString("s_depositdate_Seven"));
				salesVO.setReceipts_Seven(resultSet.getString("s_receipts_Seven"));
				salesVO.setDeposit_Seven(resultSet.getLong("s_deposit_Seven"));
				// ��ȯ���� ���
				list.add(salesVO);
			}
		} catch (SQLException e) {
			System.out.println("selet SQL = [" + e + "]");
		} catch (Exception e) {
			System.out.println("selet �׿ܿ��� = [ " + e + "]");
		} finally {
			try {
				if (resultSet != null)
					resultSet.close();
				if (preparedStatement != null)
					preparedStatement.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {

			}
		}
		return list;

	}

	public ArrayList<String> getColumnName() {

		ArrayList<String> columnName = new ArrayList<>();
		StringBuffer sql = new StringBuffer();
		sql.append("select * from sales ");
		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		// ResultSetMetaData ��ü ���� ����
		// ��Ÿ�����Ͷ� ����� ������ ��ü�� �ƴ϶�, �ش� �����Ϳ����� ������ ���� �����͸� �ǹ��Ѵ�.
		// ������� �����ͺ��̽��� ������ �Ǵ� �������� ũ����õ� �������� �ִٸ� �̷��� ���� ��Ÿ�����Ͷ� �Ҽ��ִ�.
		// �÷���,�÷�Ÿ��,�÷�ī��Ʈ ��� ��� ��Ÿ �������̴�.
		ResultSetMetaData resultSetMetaData = null;

		try {
			con = DBUtil.getConnection();
			preparedStatement = con.prepareStatement(sql.toString());
			resultSet = preparedStatement.executeQuery();

			resultSetMetaData = resultSet.getMetaData();
			// ��Ÿ�����͸��̿� �÷����� ����.
			int cols = resultSetMetaData.getColumnCount();

			for (int i = 1; i < cols; i++) {
				columnName.add(resultSetMetaData.getColumnName(i));

			}

		} catch (SQLException e) {
			System.out.println("�÷� ���� = [" + e + "]");
		} catch (Exception e) {
			System.out.println("�÷����� �׿� = [ " + e + " ]");
		} finally {
			try {
				if (resultSet != null)
					resultSet.close();
				if (preparedStatement != null)
					preparedStatement.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {

			}
		}
		return columnName;

	}

	// ���� Ŀ����
	public void getSalesDelete(int number) throws Exception {
		StringBuffer sql = new StringBuffer();
		sql.append("delete from sales where s_number =?");
		Connection con = null;
		PreparedStatement preparedStatement = null;

		try {
			con = DBUtil.getConnection();
			preparedStatement = con.prepareStatement(sql.toString());
			preparedStatement.setInt(1, number);

			int i = preparedStatement.executeUpdate();

			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("���� ����");
				alert.setHeaderText("���� ���� �Ϸ�.");
				alert.showAndWait();
			} else {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("���� ����");
				alert.setHeaderText("���� ���� ����.");
				alert.showAndWait();
			}
		} catch (SQLException e) {
			System.out.println("���� Ŀ���� = [ " + e + " ]");
		} catch (Exception e) {
			System.out.println("���� = [ " + e + " ]");
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
				if (con != null)
					con.close();
			} catch (Exception e) {

			}
		}
	}

	// ������Ʈ �� ����â Ŀ����
	public SalesVO getSalesUpdate(SalesVO salesVO, int number) throws Exception {

		StringBuffer sql = new StringBuffer();
		sql.append("update sales ");
		sql.append(" set s_date =? , s_licenseenumber =?, s_company =?, s_owner=? , s_supplyValue =?,"
				+ "s_tax =?, s_totalmoney =?, s_item =?, s_onsite =?, s_collection =?, s_outstanding =?, s_duedate=?,"
				+ "s_contact=?, s_note =?,s_depositdate_One =?, s_receipts_One =?, s_deposit_One =?,"
				+ "s_depositdate_Two =?,s_receipts_Two =?, s_deposit_Two =?, s_depositdate_Three =?,"
				+ "s_receipts_Three =?, s_deposit_Three =?, s_depositdate_Four =?, s_receipts_Four =?, s_deposit_Four =?,"
				+ "s_depositdate_Five =?, s_receipts_Five =?, s_deposit_Five =?, s_depositdate_Six =?,"
				+ "s_receipts_Six =?, s_deposit_Six =?, s_depositdate_Seven =?, s_receipts_Seven =?, s_deposit_Seven=?");
		sql.append(" where S_number = ?");
		Connection con = null;
		PreparedStatement preparedStatement = null;
		// svo���� ������ �̸��� �ߺ��̱⶧���̴�.
		SalesVO sVo = salesVO;

		try {
			con = DBUtil.getConnection();

			preparedStatement = con.prepareStatement(sql.toString());

			preparedStatement.setString(1, sVo.getDate());
			preparedStatement.setString(2, sVo.getLicenseenumber());
			preparedStatement.setString(3, sVo.getCompany());
			preparedStatement.setString(4, sVo.getOwner());
			preparedStatement.setLong(5, sVo.getSupplyValue());
			preparedStatement.setLong(6, sVo.getTax());// ? ������� ��������
			preparedStatement.setLong(7, sVo.getTotalmoney());
			preparedStatement.setString(8, sVo.getItem());
			preparedStatement.setString(9, sVo.getOnsite());
			preparedStatement.setLong(10, sVo.getCollection());
			preparedStatement.setLong(11, sVo.getOutstanding());
			preparedStatement.setString(12, sVo.getDuedate());
			preparedStatement.setString(13, sVo.getContact());
			preparedStatement.setString(14, sVo.getNote());
			preparedStatement.setString(15, sVo.getDepositdate_One());
			preparedStatement.setString(16, sVo.getReceipts_One());
			preparedStatement.setLong(17, sVo.getDeposit_One());
			preparedStatement.setString(18, sVo.getDepositdate_Two());
			preparedStatement.setString(19, sVo.getReceipts_Two());
			preparedStatement.setLong(20, sVo.getDeposit_Two());
			preparedStatement.setString(21, sVo.getDepositdate_Three());
			preparedStatement.setString(22, sVo.getReceipts_Three());
			preparedStatement.setLong(23, sVo.getDeposit_Three());
			preparedStatement.setString(24, sVo.getDepositdate_Four());
			preparedStatement.setString(25, sVo.getReceipts_Four());
			preparedStatement.setLong(26, sVo.getDeposit_Four());
			preparedStatement.setString(27, sVo.getDepositdate_Five());
			preparedStatement.setString(28, sVo.getReceipts_Five());
			preparedStatement.setLong(29, sVo.getDeposit_Five());
			preparedStatement.setString(30, sVo.getDepositdate_Six());
			preparedStatement.setString(31, sVo.getReceipts_Six());
			preparedStatement.setLong(32, sVo.getDeposit_Six());
			preparedStatement.setString(33, sVo.getDepositdate_Seven());
			preparedStatement.setString(34, sVo.getReceipts_Seven());
			preparedStatement.setLong(35, sVo.getDeposit_Seven());

			preparedStatement.setInt(36, number);
			int i = preparedStatement.executeUpdate();
			
		} catch (SQLException e) {
			System.out.println("SQL = [" + e + "]");
		} catch (Exception e) {
			System.out.println("3");
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {

			}
		}

		return salesVO;

	}

	/******************************************
	 * select �Ҷ� %��% �� Ȱ���� �Ǵ°ǰ�! �ƴϸ� �ǹ̾��� Ǯ������ �Է��ؾ��ϴ°ǰ�. (sql���� Ȱ���̵����� �ڹٿ��� Ȱ���� ����
	 * �ʴ´�.)
	 *
	 * 
	 * ����Ǽ��� �����϶��� �ϼ��ߴ�. �Ű������� 2�����༭ ���α����ߴ�. �����°��� ������..
	 ********************************************/

	public ArrayList<SalesVO> getSalesSearch(String one, String two, String three, String four, String five, int i)
			throws Exception {
		ArrayList<SalesVO> list = new ArrayList<>();
		StringBuffer sql = new StringBuffer();
		switch (i) {
		case 1:
			sql.append(" select * from sales ");
			sql.append(" where to_char(s_date,'yyyy-mm-dd') like ? ");
			sql.append(" order by s_date desc");
			break;
		case 2:
			sql.append("select * from sales where s_Licenseenumber like ? order by s_date desc");
			break;
		case 3:
			sql.append("select *  from sales where s_company like ? order by s_date desc");
			break;
		case 4:
			sql.append(" select *  from sales");
			sql.append(" where s_owner like ?");
			sql.append(" order by s_date desc");
			break;
		case 5:
			sql.append(" select *  from sales");
			sql.append(" where s_onsite like ?");
			sql.append(" order by s_date desc");
			break;
		case 6:
			sql.append(" select *  from sales");
			sql.append(" where to_char(s_date,'yyyy-mm-dd') like ? and s_Licenseenumber like ?");
			sql.append(" order by s_date desc");
			break;
		case 7:
			sql.append(" select *  from sales");
			sql.append(" where to_char(s_date,'yyyy-mm-dd') like ? and s_company like ?");
			sql.append(" order by s_date desc");
			break;
		case 8:
			sql.append(" select *  from sales");
			sql.append(" where to_char(s_date,'yyyy-mm-dd') like ? and s_owner like ?");
			sql.append(" order by s_date desc");
			break;
		case 9:
			sql.append(" select *  from sales");
			sql.append(" where to_char(s_date,'yyyy-mm-dd') like ? and s_onsite like ?");
			sql.append(" order by s_date desc");
			break;
		case 10:
			sql.append(" select *  from sales");
			sql.append(" where s_Licenseenumber like ? and s_company like ?");
			sql.append(" order by s_date desc");
			break;
		case 11:
			sql.append(" select *  from sales");
			sql.append(" where s_Licenseenumber like ? and s_owner like ?");
			sql.append(" order by s_date desc");
			break;
		case 12:
			sql.append(" select *  from sales");
			sql.append(" where s_Licenseenumber like ? and s_onsite like ?");
			sql.append(" order by s_date desc");
			break;
		case 13:
			sql.append(" select *  from sales");
			sql.append(" where s_company like ? and s_owner like ?");
			sql.append(" order by s_date desc");
			break;
		case 14:
			sql.append(" select *  from sales");
			sql.append(" where s_company like ? and s_onsite like ?");
			sql.append(" order by s_date desc");
			break;
		case 15:
			sql.append(" select *  from sales");
			sql.append(" where s_owner like ? and s_onsite like ?");
			sql.append(" order by s_date desc");
			break;
		case 16:
			sql.append(" select *  from sales");
			sql.append(" where to_char(s_date,'yyyy-mm-dd') like ?");
			sql.append(" and s_Licenseenumber like ?");
			sql.append(" and s_company like ?");
			sql.append(" order by s_date desc");
			break;
		case 17:
			sql.append(" select *  from sales");
			sql.append(" where to_char(s_date,'yyyy-mm-dd') like ?");
			sql.append(" and s_Licenseenumber like ?");
			sql.append(" and s_owner like ?");
			sql.append(" order by s_date desc");
			break;
		case 18:
			sql.append(" select *  from sales");
			sql.append(" where to_char(s_date,'yyyy-mm-dd') like ?");
			sql.append(" and s_Licenseenumber like ?");
			sql.append(" and s_onsite like ?");
			sql.append(" order by s_date desc");
			break;
		case 19:
			sql.append(" select *  from sales");
			sql.append(" where to_char(s_date,'yyyy-mm-dd') like ?");
			sql.append(" and s_company like ?");
			sql.append(" and s_owner like ?");
			sql.append(" order by s_date desc");
			break;
		case 20:
			sql.append(" select *  from sales");
			sql.append(" where to_char(s_date,'yyyy-mm-dd') like ?");
			sql.append(" and s_company like ?");
			sql.append(" and s_onsite like ?");
			sql.append(" order by s_date desc");
			break;
		case 21:
			sql.append(" select *  from sales");
			sql.append(" where to_char(s_date,'yyyy-mm-dd') like ?");
			sql.append(" and s_owner like ?");
			sql.append(" and s_onsite like ?");
			sql.append(" order by s_date desc");
			break;
		case 22:
			sql.append(" select *  from sales");
			sql.append(" where s_Licenseenumber like ?");
			sql.append(" and s_company like ?");
			sql.append(" and s_owner like ?");
			sql.append(" order by s_date desc");
			break;
		case 23:
			sql.append(" select *  from sales");
			sql.append(" where s_Licenseenumber like ?");
			sql.append(" and s_company like ?");
			sql.append(" and s_onsite like ?");
			sql.append(" order by s_date desc");
			break;
		case 24:
			sql.append(" select *  from sales");
			sql.append(" where s_Licenseenumber like ?");
			sql.append(" and s_owner like ?");
			sql.append(" and s_onsite like ?");
			sql.append(" order by s_date desc");
			break;
		case 25:
			sql.append(" select *  from sales");
			sql.append(" where s_company like ?");
			sql.append(" and s_owner like ?");
			sql.append(" and s_onsite like ?");
			sql.append(" order by s_date desc");
			break;
		case 26:
			sql.append(" select *  from sales");
			sql.append(" where to_char(s_date,'yyyy-mm-dd') like ?");
			sql.append(" and s_Licenseenumber like ?");
			sql.append(" and s_company like ?");
			sql.append(" and s_owner like ?");
			sql.append(" order by s_date desc");
			break;
		case 27:
			sql.append(" select *  from sales");
			sql.append(" where to_char(s_date,'yyyy-mm-dd') like ?");
			sql.append(" and s_Licenseenumber like ?");
			sql.append(" and s_company like ?");
			sql.append(" and s_onsite like ?");
			sql.append(" order by s_date desc");
			break;
		case 28:
			sql.append(" select *  from sales");
			sql.append(" where to_char(s_date,'yyyy-mm-dd') like ?");
			sql.append(" and s_Licenseenumber like ?");
			sql.append(" and s_owner like ?");
			sql.append(" and s_onsite like ?");
			sql.append(" order by s_date desc");
			break;
		case 29:
			sql.append(" select *  from sales");
			sql.append(" where to_char(s_date,'yyyy-mm-dd') like ?");
			sql.append(" and s_company like ?");
			sql.append(" and s_owner like ?");
			sql.append(" and s_onsite like ?");
			sql.append(" order by s_date desc");
			break;
		case 30:
			sql.append(" select *  from sales");
			sql.append(" where s_Licenseenumber like ?");
			sql.append(" and s_company like ?");
			sql.append(" and s_owner like ?");
			sql.append(" and s_onsite like ?");
			sql.append(" order by s_date desc");
			break;
		case 31:
			sql.append(" select *  from sales");
			sql.append(" where to_char(s_date,'yyyy-mm-dd') like ?");
			sql.append(" and s_Licenseenumber like ?");
			sql.append(" and s_company like ?");
			sql.append(" and s_owner like ?");
			sql.append(" and s_onsite like ?");
			sql.append(" order by s_date desc");
			break;

		}
		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		SalesVO salesVO = null;
		try {
			con = DBUtil.getConnection();
			preparedStatement = con.prepareStatement(sql.toString());

			switch (i) {
			case 1:
			case 2:
			case 3:
			case 4:
			case 5:
				preparedStatement.setString(1, "%" + one + "%");
				break;
			case 6:
			case 7:
			case 8:
			case 9:
			case 10:
			case 11:
			case 12:
			case 13:
			case 14:
			case 15:
				preparedStatement.setString(1, "%" + one + "%");
				preparedStatement.setString(2, "%" + two + "%");
				break;
			case 16:
			case 17:
			case 18:
			case 19:
			case 20:
			case 21:
			case 22:
			case 23:
			case 24:
			case 25:
				preparedStatement.setString(1, "%" + one + "%");
				preparedStatement.setString(2, "%" + two + "%");
				preparedStatement.setString(3, "%" + three + "%");
				break;
			case 26:
			case 27:
			case 28:
			case 29:
			case 30:
				preparedStatement.setString(1, "%" + one + "%");
				preparedStatement.setString(2, "%" + two + "%");
				preparedStatement.setString(3, "%" + three + "%");
				preparedStatement.setString(4, "%" + four + "%");
				break;
			case 31:
				preparedStatement.setString(1, "%" + one + "%");
				preparedStatement.setString(2, "%" + two + "%");
				preparedStatement.setString(3, "%" + three + "%");
				preparedStatement.setString(4, "%" + four + "%");
				preparedStatement.setString(5, "%" + five + "%");
			break;

			}

			resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {
				salesVO = new SalesVO();
				salesVO.setNumber(resultSet.getInt("s_number"));
				salesVO.setDate(resultSet.getDate("s_date") + "");
				salesVO.setLicenseenumber(resultSet.getString("s_licenseenumber"));
				salesVO.setCompany(resultSet.getString("s_company"));
				salesVO.setOwner(resultSet.getString("s_owner"));
				salesVO.setSupplyValue(resultSet.getLong("s_supplyValue"));
				salesVO.setTax(resultSet.getLong("S_tax"));
				salesVO.setTotalmoney(resultSet.getLong("s_totalmoney"));
				salesVO.setItem(resultSet.getString("s_item"));
				salesVO.setOnsite(resultSet.getString("s_onsite"));
				salesVO.setCollection(resultSet.getLong("s_collection"));
				salesVO.setOutstanding(resultSet.getLong("s_outstanding"));
				salesVO.setDuedate(resultSet.getString("s_duedate"));
				salesVO.setContact(resultSet.getString("s_contact"));
				salesVO.setNote(resultSet.getString("s_note"));
				salesVO.setDepositdate_One(resultSet.getString("s_depositdate_One"));
				salesVO.setReceipts_One(resultSet.getString("s_receipts_One"));
				salesVO.setDeposit_One(resultSet.getLong("s_deposit_One"));
				salesVO.setDepositdate_Two(resultSet.getString("s_depositdate_Two"));
				salesVO.setReceipts_Two(resultSet.getString("s_receipts_Two"));
				salesVO.setDeposit_Two(resultSet.getLong("s_deposit_Two"));
				salesVO.setDepositdate_Three(resultSet.getString("s_depositdate_Three"));
				salesVO.setReceipts_Three(resultSet.getString("s_receipts_Three"));
				salesVO.setDeposit_Three(resultSet.getLong("s_deposit_Three"));
				salesVO.setDepositdate_Four(resultSet.getString("s_depositdate_Four"));
				salesVO.setReceipts_Four(resultSet.getString("s_receipts_Four"));
				salesVO.setDeposit_Four(resultSet.getLong("s_deposit_Four"));
				salesVO.setDepositdate_Five(resultSet.getString("s_depositdate_Five"));
				salesVO.setReceipts_Five(resultSet.getString("s_receipts_Five"));
				salesVO.setDeposit_Five(resultSet.getLong("s_deposit_Five"));
				salesVO.setDepositdate_Six(resultSet.getString("s_depositdate_Six"));
				salesVO.setReceipts_Six(resultSet.getString("s_receipts_Six"));
				salesVO.setDeposit_Six(resultSet.getLong("s_deposit_Six"));
				salesVO.setDepositdate_Seven(resultSet.getString("s_depositdate_Seven"));
				salesVO.setReceipts_Seven(resultSet.getString("s_receipts_Seven"));
				salesVO.setDeposit_Seven(resultSet.getLong("s_deposit_Seven"));
				list.add(salesVO);

			}

		} catch (SQLException e) {
			System.out.println("SQL - [" + e + "]");
		} catch (Exception e) {
			System.out.println(e + "��ġ��");
		} finally {
			try {
				// Ž���� ������ resultset�� �ݾ�����Ѵ�.
				if (resultSet != null)
					resultSet.close();
				if (preparedStatement != null)
					preparedStatement.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {

			}

		}
		return list;

	}
}
