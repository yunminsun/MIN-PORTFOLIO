package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.BarChartP_VO;
import model.BarChartVO;
import model.SalesVO;

public class ChartDAO {
	
	public ArrayList<BarChartVO> getSalesTotal(BarChartVO barChartVO) throws Exception{
		ArrayList<BarChartVO> list = new ArrayList<>();
		
		StringBuffer sql = new StringBuffer();
		sql.append("select to_char(s_date,'yyyy-mm'), s_supplyvalue from sales");
		sql.append(" order by s_date ");
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		
		try {
			connection = DBUtil.getConnection();
			preparedStatement = connection.prepareStatement(sql.toString());
			resultSet = preparedStatement.executeQuery();
			
			while (resultSet.next()) {
				barChartVO = new BarChartVO();
				barChartVO.setBarS_Date(resultSet.getString(1));
				barChartVO.setBarS_Sum(resultSet.getLong(2));
				list.add(barChartVO);
			}
		}catch (SQLException e) {
			System.out.println("����");
		}catch (Exception e) {
		}finally {
			try {
			if (resultSet != null)
				resultSet.close();
			if (preparedStatement != null)
				preparedStatement.close();
			if (connection != null)
				connection.close();
		} catch (SQLException e) {

		}
	}
	return list;
	}
	
	public ArrayList<BarChartP_VO> getPurchaseTotal(BarChartP_VO barChartP_VO) throws Exception{
		ArrayList<BarChartP_VO> list = new ArrayList<>();
		
		StringBuffer sql = new StringBuffer();
		sql.append("select to_char(p_date,'yyyy-mm'), p_supplyvalue from purchase");
		sql.append(" order by p_date ");
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		
		try {
			connection = DBUtil.getConnection();
			preparedStatement = connection.prepareStatement(sql.toString());
			resultSet = preparedStatement.executeQuery();
			
			while (resultSet.next()) {
				barChartP_VO = new BarChartP_VO();
				barChartP_VO.setBar_Date(resultSet.getString(1));
				barChartP_VO.setBarP_Sum(resultSet.getLong(2));
				list.add(barChartP_VO);
			}
		}catch (SQLException e) {
			System.out.println("����");
		}catch (Exception e) {
		}finally {
			try {
			if (resultSet != null)
				resultSet.close();
			if (preparedStatement != null)
				preparedStatement.close();
			if (connection != null)
				connection.close();
		} catch (SQLException e) {

		}
	}
	return list;
	}
}
