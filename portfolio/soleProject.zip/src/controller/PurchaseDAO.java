package controller;

import java.lang.reflect.Array;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import model.PurchaseVO;

public class PurchaseDAO {
	
	//��� sql Ŀ����
	public PurchaseVO getPurchaseRegister(PurchaseVO purchaseVO) throws Exception {
		//�����ϴ� append Ŀ����
		StringBuffer sql = new StringBuffer();
		sql.append("insert into purchase ");
		sql.append(" (p_number,p_date,P_licenseenumber,p_company,p_owner,p_supplyValue,");
		sql.append(" p_tax,P_totalmoney,p_item,p_onsite,p_transactionaccount,P_accountholder,");
		sql.append(" p_bank,p_payment,p_arrear,p_whether,p_givedate,p_contact,P_division,p_note,");
		sql.append(" p_depositdate_One,p_receipts_One,p_deposit_One,p_depositdate_Two,p_receipts_Two,p_deposit_Two,"
				+ " p_depositdate_Three,p_receipts_Three,p_deposit_Three,p_depositdate_four,p_receipts_four,p_deposit_four,"
				+ " p_depositdate_five,p_receipts_five,p_deposit_five,p_depositdate_six,p_receipts_six,p_deposit_six,"
				+ " p_depositdate_seven,p_receipts_seven,p_deposit_seven)");
		sql.append(" values (purchase_seq.nextval,?,?,?,?,?,?,?,?,?,?  ,?,?,?,?,?,?,?,?,?,"); 
		sql.append(" ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
		
		Connection connection = null;
		
		PreparedStatement preparedStatement = null;
		
		PurchaseVO pVo = purchaseVO;
		
		
		try {
			
			connection = DBUtil.getConnection();
			
			preparedStatement = connection.prepareStatement(sql.toString());
			
			preparedStatement.setString(1, pVo.getDate());
			preparedStatement.setString(2, pVo.getLicenseenumber());
			preparedStatement.setString(3, pVo.getCompany());
			preparedStatement.setString(4, pVo.getOwner());
			preparedStatement.setLong(5, pVo.getSupplyValue());
			preparedStatement.setLong(6, pVo.getTax());
			preparedStatement.setLong(7, pVo.getTotalmoney());
			preparedStatement.setString(8, pVo.getItem());
			preparedStatement.setString(9, pVo.getOnsite());
			preparedStatement.setString(10, pVo.getTransactionaccount());
			preparedStatement.setString(11, pVo.getAccountholder());
			preparedStatement.setString(12, pVo.getBank());
			preparedStatement.setLong(13, pVo.getPayment());
			preparedStatement.setLong(14, pVo.getArrear());
			preparedStatement.setString(15, pVo.getWhether());
			preparedStatement.setString(16, pVo.getGivedate());
			preparedStatement.setString(17, pVo.getContact());
			preparedStatement.setString(18, pVo.getDivision());
			preparedStatement.setString(19, pVo.getNote());
			preparedStatement.setString(20, pVo.getDepositdate_One());
			preparedStatement.setString(21, pVo.getReceipts_One());
			preparedStatement.setLong(22, pVo.getDeposit_One());
			preparedStatement.setString(23, pVo.getDepositdate_Two());
			preparedStatement.setString(24, pVo.getReceipts_Two());
			preparedStatement.setLong(25, pVo.getDeposit_Two());
			preparedStatement.setString(26, pVo.getDepositdate_Three());
			preparedStatement.setString(27, pVo.getReceipts_Three());
			preparedStatement.setLong(28, pVo.getDeposit_Three());
			preparedStatement.setString(29, pVo.getDepositdate_Four());
			preparedStatement.setString(30, pVo.getReceipts_Four());
			preparedStatement.setLong(31, pVo.getDeposit_Four());
			preparedStatement.setString(32, pVo.getDepositdate_Five());
			preparedStatement.setString(33, pVo.getReceipts_Five());
			preparedStatement.setLong(34, pVo.getDeposit_Five());
			preparedStatement.setString(35, pVo.getDepositdate_Six());
			preparedStatement.setString(36, pVo.getReceipts_Six());
			preparedStatement.setLong(37, pVo.getDeposit_Six());
			preparedStatement.setString(38, pVo.getDepositdate_Seven());
			preparedStatement.setString(39, pVo.getReceipts_Seven());
			preparedStatement.setLong(40, pVo.getDeposit_Seven());
			
			int i = preparedStatement.executeUpdate();
		} catch (SQLException e) {
			System.out.println("��� SQL = " + e);
		}catch (Exception e) {
			System.out.println("��� = " + e);
		}finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
				if (connection != null)
					connection.close();
			} catch (SQLException e) {

			}
		}
		return pVo;
	}
	
	public PurchaseVO getPurchaseUpdate(PurchaseVO purchaseVO, int number) throws Exception{
		StringBuffer sql = new StringBuffer();
		sql.append("update purchase ");
		sql.append(" set p_date = ?,P_licenseenumber = ?,p_company = ?,p_owner = ?,p_supplyValue = ?,"); 
		sql.append(" p_tax = ?,P_totalmoney = ?,p_item = ?,p_onsite = ?,p_transactionaccount = ?,P_accountholder = ?,");
		sql.append(" p_bank = ?,p_payment = ?,p_arrear = ?,p_whether = ?,p_givedate = ?,p_contact = ?,P_division = ?,p_note = ?,");
		sql.append(" p_depositdate_One = ?,p_receipts_One = ?,p_deposit_One = ?,p_depositdate_Two = ?,p_receipts_Two = ?,p_deposit_Two = ?," + 
					" p_depositdate_Three = ?,p_receipts_Three = ?,p_deposit_Three = ?,p_depositdate_four = ?,p_receipts_four = ?,p_deposit_four = ?," + 
					" p_depositdate_five = ?,p_receipts_five = ?,p_deposit_five = ?,p_depositdate_six = ?,p_receipts_six = ?,p_deposit_six = ?," + 
					" p_depositdate_seven = ?,p_receipts_seven = ?,p_deposit_seven = ?");
		sql.append(" where p_number =?");
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		PurchaseVO pVo = purchaseVO;
		
		try {
			connection = DBUtil.getConnection();
			
			preparedStatement= connection.prepareStatement(sql.toString());
			
			preparedStatement.setString(1, pVo.getDate());
			preparedStatement.setString(2, pVo.getLicenseenumber());
			preparedStatement.setString(3, pVo.getCompany());
			preparedStatement.setString(4, pVo.getOwner());
			preparedStatement.setLong(5, pVo.getSupplyValue());
			preparedStatement.setLong(6, pVo.getTax());
			preparedStatement.setLong(7, pVo.getTotalmoney());
			preparedStatement.setString(8, pVo.getItem());
			preparedStatement.setString(9, pVo.getOnsite());
			preparedStatement.setString(10, pVo.getTransactionaccount());
			preparedStatement.setString(11, pVo.getAccountholder());
			preparedStatement.setString(12, pVo.getBank());
			preparedStatement.setLong(13, pVo.getPayment());
			preparedStatement.setLong(14, pVo.getArrear());
			preparedStatement.setString(15, pVo.getWhether());
			preparedStatement.setString(16, pVo.getGivedate());
			preparedStatement.setString(17, pVo.getContact());
			preparedStatement.setString(18, pVo.getDivision());
			preparedStatement.setString(19, pVo.getNote());
			preparedStatement.setString(20, pVo.getDepositdate_One());
			preparedStatement.setString(21, pVo.getReceipts_One());
			preparedStatement.setLong(22, pVo.getDeposit_One());
			preparedStatement.setString(23, pVo.getDepositdate_Two());
			preparedStatement.setString(24, pVo.getReceipts_Two());
			preparedStatement.setLong(25, pVo.getDeposit_Two());
			preparedStatement.setString(26, pVo.getDepositdate_Three());
			preparedStatement.setString(27, pVo.getReceipts_Three());
			preparedStatement.setLong(28, pVo.getDeposit_Three());
			preparedStatement.setString(29, pVo.getDepositdate_Four());
			preparedStatement.setString(30, pVo.getReceipts_Four());
			preparedStatement.setLong(31, pVo.getDeposit_Four());
			preparedStatement.setString(32, pVo.getDepositdate_Five());
			preparedStatement.setString(33, pVo.getReceipts_Five());
			preparedStatement.setLong(34, pVo.getDeposit_Five());
			preparedStatement.setString(35, pVo.getDepositdate_Six());
			preparedStatement.setString(36, pVo.getReceipts_Six());
			preparedStatement.setLong(37, pVo.getDeposit_Six());
			preparedStatement.setString(38, pVo.getDepositdate_Seven());
			preparedStatement.setString(39, pVo.getReceipts_Seven());
			preparedStatement.setLong(40, pVo.getDeposit_Seven());
			//������ ��ȣ
			preparedStatement.setLong(41, number);
			int i = preparedStatement.executeUpdate();
			
			
			
			
			
		} catch (SQLException e) {
			System.out.println("SQL = [" + e + "]");
		} catch (Exception e) {
			System.out.println("3");
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
				if (connection != null)
					connection.close();
			} catch (SQLException e) {

			}
		}

		return purchaseVO;

	}
	//��ü���
	public ArrayList<PurchaseVO> getPurchaseTotal(){
		ArrayList<PurchaseVO> list = new ArrayList<>();
		StringBuffer sql = new StringBuffer();
		sql.append("select p_number,P_date,P_licenseenumber,p_company,p_owner,p_supplyValue,");
		sql.append(" p_tax,P_totalmoney,p_item,p_onsite,p_transactionaccount,P_accountholder,");
		sql.append(" p_bank,p_payment,p_arrear,p_whether,p_givedate,p_contact,P_division,p_note,");
		sql.append(" p_depositdate_One,p_receipts_One,p_deposit_One,p_depositdate_Two,p_receipts_Two,p_deposit_Two," + 
					" p_depositdate_Three,p_receipts_Three,p_deposit_Three,p_depositdate_four,p_receipts_four,p_deposit_four," + 
					" p_depositdate_five,p_receipts_five,p_deposit_five,p_depositdate_six,p_receipts_six,p_deposit_six," + 
					" p_depositdate_seven,p_receipts_seven,p_deposit_seven");
		sql.append(" from purchase order by p_date desc");
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		PurchaseVO purchaseVO = null;
		
		try {
			connection = DBUtil.getConnection();
			preparedStatement = connection.prepareStatement(sql.toString());
			resultSet = preparedStatement.executeQuery();
			//vo�� �̿� �� ������ �Է��ϰ� �������� �迭�� �����Ѵ�.
			while (resultSet.next()) {
				purchaseVO = new PurchaseVO();
				purchaseVO.setNumber(resultSet.getInt("p_number"));
				purchaseVO.setDate(resultSet.getDate("P_date")+"");
				purchaseVO.setLicenseenumber(resultSet.getString("p_licenseenumber"));
				purchaseVO.setCompany(resultSet.getString("p_company"));
				purchaseVO.setOwner(resultSet.getString("p_owner"));
				purchaseVO.setSupplyValue(resultSet.getLong("p_supplyValue"));
				purchaseVO.setTax(resultSet.getLong("p_tax"));
				purchaseVO.setTotalmoney(resultSet.getLong("p_totalmoney"));
				purchaseVO.setItem(resultSet.getString("p_item"));
				purchaseVO.setOnsite(resultSet.getString("p_onsite"));
				purchaseVO.setTransactionaccount(resultSet.getString("p_transactionaccount"));
				purchaseVO.setAccountholder(resultSet.getString("p_accountholder"));
				purchaseVO.setBank(resultSet.getString("p_bank"));
				purchaseVO.setPayment(resultSet.getLong("p_payment"));
				purchaseVO.setArrear(resultSet.getLong("p_arrear"));
				purchaseVO.setWhether(resultSet.getString("p_whether"));
				purchaseVO.setGivedate(resultSet.getString("p_givedate"));
				purchaseVO.setContact(resultSet.getString("p_contact"));
				purchaseVO.setDivision(resultSet.getString("P_division"));
				purchaseVO.setNote(resultSet.getString("p_note"));
				purchaseVO.setDepositdate_One(resultSet.getString("p_depositdate_One"));
				purchaseVO.setReceipts_One(resultSet.getString("p_receipts_One"));
				purchaseVO.setDeposit_One(resultSet.getLong("p_deposit_One"));
				purchaseVO.setDepositdate_Two(resultSet.getString("p_depositdate_Two"));
				purchaseVO.setReceipts_Two(resultSet.getString("p_receipts_Two"));
				purchaseVO.setDeposit_Two(resultSet.getLong("p_deposit_Two"));
				purchaseVO.setDepositdate_Three(resultSet.getString("p_depositdate_Three"));
				purchaseVO.setReceipts_Three(resultSet.getString("p_receipts_Three"));
				purchaseVO.setDeposit_Three(resultSet.getLong("p_deposit_Three"));
				purchaseVO.setDepositdate_Four(resultSet.getString("p_depositdate_Four"));
				purchaseVO.setReceipts_Four(resultSet.getString("p_receipts_Four"));
				purchaseVO.setDeposit_Four(resultSet.getLong("p_deposit_Four"));
				purchaseVO.setDepositdate_Five(resultSet.getString("p_depositdate_Five"));
				purchaseVO.setReceipts_Five(resultSet.getString("p_receipts_Five"));
				purchaseVO.setDeposit_Five(resultSet.getLong("p_deposit_Five"));
				purchaseVO.setDepositdate_Six(resultSet.getString("p_depositdate_Six"));
				purchaseVO.setReceipts_Six(resultSet.getString("p_receipts_Six"));
				purchaseVO.setDeposit_Six(resultSet.getLong("p_deposit_Six"));
				purchaseVO.setDepositdate_Seven(resultSet.getString("p_depositdate_Seven"));
				purchaseVO.setReceipts_Seven(resultSet.getString("p_receipts_Seven"));
				purchaseVO.setDeposit_Seven(resultSet.getLong("p_deposit_Seven"));
				
				list.add(purchaseVO);
			}
		} catch (SQLException e) {
			System.out.println("selet SQL = [" + e + "]");
		} catch (Exception e) {
			System.out.println("selet �׿ܿ��� = [ " + e + "]");
		} finally {
			try {
				if (resultSet != null)
					resultSet.close();
				if (preparedStatement != null)
					preparedStatement.close();
				if (connection != null)
					connection.close();
			} catch (SQLException e) {

			}
		}
		return list;
	}
	public ArrayList<String> getColumnName() {
		
		ArrayList<String> columnName =new ArrayList<>();
		StringBuffer sql = new StringBuffer();
		sql.append("select * from purchase");
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		//�÷��� ����
		ResultSetMetaData resultSetMetaData = null;
		
		try {
			connection = DBUtil.getConnection();
			preparedStatement = connection.prepareStatement(sql.toString());
			resultSet = preparedStatement.executeQuery();
			
			resultSetMetaData = resultSet.getMetaData();
			//�÷����� ī��Ʈ
			int cols = resultSetMetaData.getColumnCount();
			
			for (int i = 1; i < cols; i++) {
				columnName.add(resultSetMetaData.getColumnTypeName(i));
				
			}
		
		
		} catch (SQLException e) {
			System.out.println("�÷��� SQL = [" + e + "]");
		} catch (Exception e) {
			System.out.println("�÷��� = [ " + e + " ]");
		} finally {
			try {
				if (resultSet != null)
					resultSet.close();
				if (preparedStatement != null)
					preparedStatement.close();
				if (connection != null)
					connection.close();
			} catch (SQLException e) {

			}
		}
		
		return columnName;
		
	}
	
	public void getPurchaseDelete(int number) throws Exception {
		StringBuffer sql = new StringBuffer();
		sql.append("delete from purchase where P_number = ?");
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		try {
			connection = DBUtil.getConnection();
			preparedStatement = connection.prepareStatement(sql.toString());
			preparedStatement.setInt(1, number);
			
			int i = preparedStatement.executeUpdate();
			
			
			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("���� ����");
				alert.setHeaderText("���� ���� �Ϸ�.");
				alert.showAndWait();
			} else {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("���� ����");
				alert.setHeaderText("���� ���� ����.");
				alert.showAndWait();
			}
			
		} catch (SQLException e) {
			System.out.println("���� Ŀ���� = [ " + e + " ]");
		} catch (Exception e) {
			System.out.println("���� = [ " + e + " ]");
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
				if (connection != null)
					connection.close();
			} catch (Exception e) {

			}
		}
	}
	
	public ArrayList<PurchaseVO> getPurchaseSearch(
			String one, String two, String three, String four, String five, String six, int i) throws Exception{
		ArrayList<PurchaseVO> list = new ArrayList<>();
		StringBuffer sql = new StringBuffer();

		sql.append(" select * from purchase ");
		switch(i) {
		case 1:
			sql.append(" where to_char(P_DATE,'yyyy-mm-dd') like ? ");
			break;
		case 2:
			sql.append(" where P_COMPANY like ? ");
			break;
		case 3:
			sql.append(" where P_OWNER like ? ");
			break;
		case 4:
			sql.append(" where P_ONSITE like ? ");
			break;
		case 5:
			sql.append(" where P_WHETHER like ? ");
			break;
		case 6:
			sql.append(" where P_DIVISION like ? ");
			break;
		case 7:
			sql.append(" where to_char(p_date,'yyyy-mm-dd') like ? and P_COMPANY like ?");
			break;
		case 8:
			sql.append(" where to_char(p_date,'yyyy-mm-dd') like ? and P_OWNER like ?");
			break;
		case 9:
			sql.append(" where to_char(p_date,'yyyy-mm-dd') like ? and P_ONSITE like ?");
			break;
		case 10:
			sql.append(" where to_char(p_date,'yyyy-mm-dd') like ? and P_WHETHER like ?");
			break;
		case 11:
			sql.append(" where to_char(p_date,'yyyy-mm-dd') like ? and P_DIVISION like ?");
			break;
		case 12:
			sql.append(" where P_COMPANY like ? and P_OWNER like ?");
			break;
		case 13:
			sql.append(" where P_COMPANY like ? and P_ONSITE like ?");
			break;
		case 14:
			sql.append(" where P_COMPANY like ? and P_WHETHER like ?");
			break;
		case 15:
			sql.append(" where P_COMPANY like ? and P_DIVISION like ?");
			break;
		case 16:
			sql.append(" where P_OWNER like ? and P_ONSITE like ?");
			break;
		case 17:
			sql.append(" where P_OWNER like ? and P_WHETHER like ?");
			break;
		case 18:
			sql.append(" where P_OWNER like ? and P_DIVISION like ?");
			break;
		case 19:
			sql.append(" where P_ONSITE like ? and P_WHETHER like ?");
			break;
		case 20:
			sql.append(" where P_ONSITE like ? and P_DIVISION like ?");
			break;
		case 21:
			sql.append(" where P_WHETHER like ? and P_DIVISION like ?");
			break;
		case 22:
			sql.append(" where to_char(p_date,'yyyy-mm-dd') like ? and P_COMPANY like ?");
			sql.append(" and P_OWNER like ?");
			break;
		case 23:
			sql.append(" where to_char(p_date,'yyyy-mm-dd') like ? and P_COMPANY like ?");
			sql.append(" and P_ONSITE like ?");
			break;
		case 24:
			sql.append(" where to_char(p_date,'yyyy-mm-dd') like ? and P_COMPANY like ?");
			sql.append(" and P_WHETHER like ?");
			break;
		case 25:
			sql.append(" where to_char(p_date,'yyyy-mm-dd') like ? and P_COMPANY like ?");
			sql.append(" and P_DIVISION like ?");
			break;
		case 26:
			sql.append(" where to_char(p_date,'yyyy-mm-dd') like ? and P_OWNER like ?");
			sql.append(" and P_ONSITE like ?");
			break;
		case 27:
			sql.append(" where to_char(p_date,'yyyy-mm-dd') like ? and P_OWNER like ?");
			sql.append(" and P_WHETHER like ?");
			break;
		case 28:
			sql.append(" where to_char(p_date,'yyyy-mm-dd') like ? and P_OWNER like ?");
			sql.append(" and P_DIVISION like ?");
			break;
		case 29:
			sql.append(" where to_char(p_date,'yyyy-mm-dd') like ? and P_ONSITE like ?");
			sql.append(" and P_WHETHER like ?");
			break;
		case 30:
			sql.append(" where to_char(p_date,'yyyy-mm-dd') like ? and P_ONSITE like ?");
			sql.append(" and P_DIVISION like ?");
			break;
		case 31:
			sql.append(" where to_char(p_date,'yyyy-mm-dd') like ? and P_WHETHER like ?");
			sql.append(" and P_DIVISION like ?");
			break;
		case 32:
			sql.append(" where P_COMPANY like ? and P_OWNER like ?");
			sql.append(" and P_ONSITE like ?");
			break;
		case 33:
			sql.append(" where P_COMPANY like ? and P_OWNER like ?");
			sql.append(" and P_WHETHER like ?");
			break;
		case 34:
			sql.append(" where P_COMPANY like ? and P_OWNER like ?");
			sql.append(" and P_DIVISION like ?");
			break;
		case 35:
			sql.append(" where P_COMPANY like ? and P_ONSITE like ?");
			sql.append(" and P_WHETHER like ?");
			break;
		case 36:
			sql.append(" where P_COMPANY like ? and P_ONSITE like ?");
			sql.append(" and P_DIVISION like ?");
			break;
		case 37:
			sql.append(" where P_COMPANY like ? and P_WHETHER like ?");
			sql.append(" and P_DIVISION like ?");
			break;
		case 38:
			sql.append(" where P_OWNER like ? and P_ONSITE like ?");
			sql.append(" and P_WHETHER like ?");
			break;
		case 39:
			sql.append(" where P_OWNER like ? and P_ONSITE like ?");
			sql.append(" and P_DIVISION like ?");
			break;
		case 40:
			sql.append(" where P_OWNER like ? and P_WHETHER like ?");
			sql.append(" and P_DIVISION like ?");
			break;
		case 41:
			sql.append(" where P_ONSITE like ? and P_WHETHER like ?");
			sql.append(" and P_DIVISION like ?");
			break;
		case 42:
			sql.append(" where to_char(p_date,'yyyy-mm-dd') like ? and P_COMPANY like ?");
			sql.append(" and P_OWNER like ? and P_ONSITE like ?");
			break;
		case 43:
			sql.append(" where to_char(p_date,'yyyy-mm-dd') like ? and P_COMPANY like ?");
			sql.append(" and P_OWNER like ? and P_WHETHER like ?");
			break;
		case 44:
			sql.append(" where to_char(p_date,'yyyy-mm-dd') like ? and P_COMPANY like ?");
			sql.append(" and P_OWNER like ? and P_DIVISION like ?");
			break;
		case 45:
			sql.append(" where to_char(p_date,'yyyy-mm-dd') like ? and P_COMPANY like ?");
			sql.append(" and P_ONSITE like ? and P_WHETHER like ?");
			break;
		case 46:
			sql.append(" where to_char(p_date,'yyyy-mm-dd') like ? and P_COMPANY like ?");
			sql.append(" and P_ONSITE like ? and P_DIVISION like ?");
			break;
		case 47:
			sql.append(" where to_char(p_date,'yyyy-mm-dd') like ? and P_COMPANY like ?");
			sql.append(" and P_WHETHER like ? and P_DIVISION like ?");
			break;
		case 48:
			sql.append(" where to_char(p_date,'yyyy-mm-dd') like ? and P_OWNER like ?");
			sql.append(" and P_ONSITE like ? and P_WHETHER like ?");
			break;
		case 49:
			sql.append(" where to_char(p_date,'yyyy-mm-dd') like ? and P_OWNER like ?");
			sql.append(" and P_ONSITE like ? and P_DIVISION like ?");
			break;
		case 50:
			sql.append(" where to_char(p_date,'yyyy-mm-dd') like ? and P_OWNER like ?");
			sql.append(" and P_WHETHER like ? and P_DIVISION like ?");
			break;
		case 51:
			sql.append(" where to_char(p_date,'yyyy-mm-dd') like ? and P_ONSITE like ?");
			sql.append(" and P_WHETHER like ? and P_DIVISION like ?");
			break;
		case 52:
			sql.append(" where P_COMPANY like ? and P_OWNER like ?");
			sql.append(" and P_ONSITE like ? and P_WHETHER like ?");
			break;
		case 53:
			sql.append(" where P_COMPANY like ? and P_OWNER like ?");
			sql.append(" and P_ONSITE like ? and P_DIVISION like ?");
			break;
		case 54:
			sql.append(" where P_COMPANY like ? and P_OWNER like ?");
			sql.append(" and P_WHETHER like ? and P_DIVISION like ?");
			break;
		case 55:
			sql.append(" where P_COMPANY like ? and P_ONSITE like ?");
			sql.append(" and P_WHETHER like ? and P_DIVISION like ?");
			break;
		case 56:
			sql.append(" where P_OWNER like ? and P_ONSITE like ?");
			sql.append(" and P_WHETHER like ? and P_DIVISION like ?");
			break;
		case 57:
			sql.append(" where to_char(p_date,'yyyy-mm-dd') like ? and P_COMPANY like ?");
			sql.append(" and P_OWNER like ? and P_ONSITE like ? and P_WHETHER like ?");
			break;
		case 58:
			sql.append(" where to_char(p_date,'yyyy-mm-dd') like ? and P_COMPANY like ?");
			sql.append(" and P_OWNER like ? and P_ONSITE like ? and P_DIVISION like ?");
			break;
		case 59:
			sql.append(" where to_char(p_date,'yyyy-mm-dd') like ? and P_COMPANY like ?");
			sql.append(" and P_OWNER like ? and P_WHETHER like ? and P_DIVISION like ?");
			break;
		case 60:
			sql.append(" where to_char(p_date,'yyyy-mm-dd') like ? and P_COMPANY like ?");
			sql.append(" and P_ONSITE like ? and P_WHETHER like ? and P_DIVISION like ?");
			break;
		case 61:
			sql.append(" where to_char(p_date,'yyyy-mm-dd') like ? and P_OWNER like ?");
			sql.append(" and P_ONSITE like ? and P_WHETHER like ? and P_DIVISION like ?");
			break;
		case 62:
			sql.append(" where P_COMPANY like ? and P_OWNER like ?");
			sql.append(" and P_ONSITE like ? and P_WHETHER like ? and P_DIVISION like ?");
			break;
		case 63:
			sql.append(" where to_char(p_date,'yyyy-mm-dd') like ? and P_COMPANY like ?");
			sql.append(" and P_OWNER like ? and P_ONSITE like ? and P_WHETHER like ?");
			sql.append(" and P_DIVISION like ? ");
			break;
		
		}
		sql.append(" order by P_DATE desc");
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		PurchaseVO purchaseVO = null;
		
		try {
			connection = DBUtil.getConnection();
			preparedStatement = connection.prepareStatement(sql.toString());
			
			switch (i) {
			
			case 1:
			case 2:
			case 3:
			case 4:
			case 5:
			case 6:
				preparedStatement.setString(1, "%" + one + "%");
				break;
			case 7:
			case 8:
			case 9:
			case 10:
			case 11:
			case 12:
			case 13:
			case 14:
			case 15:
			case 16:
			case 17:
			case 18:
			case 19:
			case 20:
			case 21:
				preparedStatement.setString(1, "%" + one + "%");
				preparedStatement.setString(2, "%" + two + "%");
				break;
			case 22:
			case 23:
			case 24:
			case 25:
			case 26:
			case 27:
			case 28:
			case 29:
			case 30:
			case 31:
			case 32:
			case 33:
			case 34:
			case 35:
			case 36:
			case 37:
			case 38:
			case 39:
			case 40:
			case 41:
				preparedStatement.setString(1, "%" + one + "%");
				preparedStatement.setString(2, "%" + two + "%");
				preparedStatement.setString(3, "%" + three + "%");
				break;
			case 42:
			case 43:
			case 44:
			case 45:
			case 46:
			case 47:
			case 48:
			case 49:
			case 50:
			case 51:
			case 52:
			case 53:
			case 54:
			case 55:
			case 56:
				preparedStatement.setString(1, "%" + one + "%");
				preparedStatement.setString(2, "%" + two + "%");
				preparedStatement.setString(3, "%" + three + "%");
				preparedStatement.setString(4, "%" + four + "%");
				break;
			case 57:
			case 58:
			case 59:
			case 60:
			case 61:
			case 62:
				preparedStatement.setString(1, "%" + one + "%");
				preparedStatement.setString(2, "%" + two + "%");
				preparedStatement.setString(3, "%" + three + "%");
				preparedStatement.setString(4, "%" + four + "%");
				preparedStatement.setString(5, "%" + five + "%");
				break;
			case 63:
				preparedStatement.setString(1, "%" + one + "%");
				preparedStatement.setString(2, "%" + two + "%");
				preparedStatement.setString(3, "%" + three + "%");
				preparedStatement.setString(4, "%" + four + "%");
				preparedStatement.setString(5, "%" + five + "%");
				preparedStatement.setString(6, "%" + six + "%");
				break;
			}
			
			resultSet = preparedStatement.executeQuery();
			
			
			while (resultSet.next()) {
				purchaseVO = new PurchaseVO();
				
				purchaseVO.setNumber(resultSet.getInt("P_number"));
				purchaseVO.setDate(resultSet.getDate("P_date") + "");
				purchaseVO.setLicenseenumber(resultSet.getString("P_licenseenumber"));
				purchaseVO.setCompany(resultSet.getString("P_company"));
				purchaseVO.setOwner(resultSet.getString("P_owner"));
				purchaseVO.setSupplyValue(resultSet.getLong("P_supplyValue"));
				purchaseVO.setTax(resultSet.getLong("P_tax"));
				purchaseVO.setTotalmoney(resultSet.getLong("P_totalmoney"));
				purchaseVO.setItem(resultSet.getString("P_item"));
				purchaseVO.setOnsite(resultSet.getString("P_onsite"));
				purchaseVO.setTransactionaccount(resultSet.getString("P_Transactionaccount"));
				purchaseVO.setAccountholder(resultSet.getString("p_Accountholder"));
				purchaseVO.setBank(resultSet.getString("P_Bank"));
				purchaseVO.setPayment(resultSet.getLong("p_Payment"));
				purchaseVO.setArrear(resultSet.getLong("p_Arrear"));
				purchaseVO.setWhether(resultSet.getString("p_Whether"));
				purchaseVO.setGivedate(resultSet.getString("p_Givedate"));
				purchaseVO.setContact(resultSet.getString("p_Contact"));
				purchaseVO.setDivision(resultSet.getString("P_Division"));
				purchaseVO.setNote(resultSet.getString("P_note"));
				purchaseVO.setDepositdate_One(resultSet.getString("P_depositdate_One"));
				purchaseVO.setReceipts_One(resultSet.getString("P_receipts_One"));
				purchaseVO.setDeposit_One(resultSet.getLong("P_deposit_One"));
				purchaseVO.setDepositdate_Two(resultSet.getString("P_depositdate_Two"));
				purchaseVO.setReceipts_Two(resultSet.getString("P_receipts_Two"));
				purchaseVO.setDeposit_Two(resultSet.getLong("P_deposit_Two"));
				purchaseVO.setDepositdate_Three(resultSet.getString("P_depositdate_Three"));
				purchaseVO.setReceipts_Three(resultSet.getString("P_receipts_Three"));
				purchaseVO.setDeposit_Three(resultSet.getLong("P_deposit_Three"));
				purchaseVO.setDepositdate_Four(resultSet.getString("P_depositdate_Four"));
				purchaseVO.setReceipts_Four(resultSet.getString("P_receipts_Four"));
				purchaseVO.setDeposit_Four(resultSet.getLong("P_deposit_Four"));
				purchaseVO.setDepositdate_Five(resultSet.getString("P_depositdate_Five"));
				purchaseVO.setReceipts_Five(resultSet.getString("P_receipts_Five"));
				purchaseVO.setDeposit_Five(resultSet.getLong("P_deposit_Five"));
				purchaseVO.setDepositdate_Six(resultSet.getString("P_depositdate_Six"));
				purchaseVO.setReceipts_Six(resultSet.getString("P_receipts_Six"));
				purchaseVO.setDeposit_Six(resultSet.getLong("P_deposit_Six"));
				purchaseVO.setDepositdate_Seven(resultSet.getString("P_depositdate_Seven"));
				purchaseVO.setReceipts_Seven(resultSet.getString("P_receipts_Seven"));
				purchaseVO.setDeposit_Seven(resultSet.getLong("P_deposit_Seven"));
				list.add(purchaseVO);
			}
			
			
			
			
		} catch (SQLException e) {
			System.out.println("SQL - [" + e + "]");
		} catch (Exception e) {
			System.out.println(e + "��ġ��");
		} finally {
			try {
				// Ž���� ������ resultset�� �ݾ�����Ѵ�.
				if (resultSet != null)
					resultSet.close();
				if (preparedStatement != null)
					preparedStatement.close();
				if (connection != null)
					connection.close();
			} catch (SQLException e) {

			}

		}
				return list;
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
