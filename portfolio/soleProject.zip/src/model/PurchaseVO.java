package model;

public class PurchaseVO {
	private int number;
	private String date;
	private String licenseenumber;
	private String company;
	private String owner;
	private long supplyValue;
	private long tax;
	private long totalmoney;
	private String item;
	private String onsite;
	private String transactionaccount;
	private String accountholder;
	private String bank;
	private long payment;
	private long arrear;
	private String whether;
	private String givedate;
	private String contact;
	private String division;
	private String note;
	private String depositdate_One;
	private String receipts_One;
	private long deposit_One;
	private String depositdate_Two;
	private String receipts_Two;
	private long deposit_Two;
	private String depositdate_Three;
	private String receipts_Three;
	private long deposit_Three;
	private String depositdate_Four;
	private String receipts_Four;
	private long deposit_Four;
	private String depositdate_Five;
	private String receipts_Five;
	private long deposit_Five;
	private String depositdate_Six;
	private String receipts_Six;
	private long deposit_Six;
	private String depositdate_Seven;
	private String receipts_Seven;
	private long deposit_Seven;
	
	
	
	public PurchaseVO() {
		super();
	}
	public PurchaseVO(int number, String date, String licenseenumber, String company, String owner, long supplyValue,
			long tax, long totalmoney, String item, String onsite, String transactionaccount, String accountholder,
			String bank, long payment, long arrear, String whether, String givedate, String contact, String division,
			String note, String depositdate_One, String receipts_One, long deposit_One, String depositdate_Two,
			String receipts_Two, long deposit_Two, String depositdate_Three, String receipts_Three, long deposit_Three,
			String depositdate_Four, String receipts_Four, long deposit_Four, String depositdate_Five,
			String receipts_Five, long deposit_Five, String depositdate_Six, String receipts_Six, long deposit_Six,
			String depositdate_Seven, String receipts_Seven, long deposit_Seven) {
		super();
		this.number = number;
		this.date = date;
		this.licenseenumber = licenseenumber;
		this.company = company;
		this.owner = owner;
		this.supplyValue = supplyValue;
		this.tax = tax;
		this.totalmoney = totalmoney;
		this.item = item;
		this.onsite = onsite;
		this.transactionaccount = transactionaccount;
		this.accountholder = accountholder;
		this.bank = bank;
		this.payment = payment;
		this.arrear = arrear;
		this.whether = whether;
		this.givedate = givedate;
		this.contact = contact;
		this.division = division;
		this.note = note;
		this.depositdate_One = depositdate_One;
		this.receipts_One = receipts_One;
		this.deposit_One = deposit_One;
		this.depositdate_Two = depositdate_Two;
		this.receipts_Two = receipts_Two;
		this.deposit_Two = deposit_Two;
		this.depositdate_Three = depositdate_Three;
		this.receipts_Three = receipts_Three;
		this.deposit_Three = deposit_Three;
		this.depositdate_Four = depositdate_Four;
		this.receipts_Four = receipts_Four;
		this.deposit_Four = deposit_Four;
		this.depositdate_Five = depositdate_Five;
		this.receipts_Five = receipts_Five;
		this.deposit_Five = deposit_Five;
		this.depositdate_Six = depositdate_Six;
		this.receipts_Six = receipts_Six;
		this.deposit_Six = deposit_Six;
		this.depositdate_Seven = depositdate_Seven;
		this.receipts_Seven = receipts_Seven;
		this.deposit_Seven = deposit_Seven;
	}
	public PurchaseVO(String date, String licenseenumber, String company, String owner, long supplyValue, long tax,
			long totalmoney, String item, String onsite, String transactionaccount, String accountholder, String bank,
			long payment, long arrear, String whether, String givedate, String contact, String division, String note,
			String depositdate_One, String receipts_One, long deposit_One, String depositdate_Two, String receipts_Two,
			long deposit_Two, String depositdate_Three, String receipts_Three, long deposit_Three,
			String depositdate_Four, String receipts_Four, long deposit_Four, String depositdate_Five,
			String receipts_Five, long deposit_Five, String depositdate_Six, String receipts_Six, long deposit_Six,
			String depositdate_Seven, String receipts_Seven, long deposit_Seven) {
		super();
		this.date = date;
		this.licenseenumber = licenseenumber;
		this.company = company;
		this.owner = owner;
		this.supplyValue = supplyValue;
		this.tax = tax;
		this.totalmoney = totalmoney;
		this.item = item;
		this.onsite = onsite;
		this.transactionaccount = transactionaccount;
		this.accountholder = accountholder;
		this.bank = bank;
		this.payment = payment;
		this.arrear = arrear;
		this.whether = whether;
		this.givedate = givedate;
		this.contact = contact;
		this.division = division;
		this.note = note;
		this.depositdate_One = depositdate_One;
		this.receipts_One = receipts_One;
		this.deposit_One = deposit_One;
		this.depositdate_Two = depositdate_Two;
		this.receipts_Two = receipts_Two;
		this.deposit_Two = deposit_Two;
		this.depositdate_Three = depositdate_Three;
		this.receipts_Three = receipts_Three;
		this.deposit_Three = deposit_Three;
		this.depositdate_Four = depositdate_Four;
		this.receipts_Four = receipts_Four;
		this.deposit_Four = deposit_Four;
		this.depositdate_Five = depositdate_Five;
		this.receipts_Five = receipts_Five;
		this.deposit_Five = deposit_Five;
		this.depositdate_Six = depositdate_Six;
		this.receipts_Six = receipts_Six;
		this.deposit_Six = deposit_Six;
		this.depositdate_Seven = depositdate_Seven;
		this.receipts_Seven = receipts_Seven;
		this.deposit_Seven = deposit_Seven;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getLicenseenumber() {
		return licenseenumber;
	}
	public void setLicenseenumber(String licenseenumber) {
		this.licenseenumber = licenseenumber;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getOwner() {
		return owner;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}
	public long getSupplyValue() {
		return supplyValue;
	}
	public void setSupplyValue(long supplyValue) {
		this.supplyValue = supplyValue;
	}
	public long getTax() {
		return tax;
	}
	public void setTax(long tax) {
		this.tax = tax;
	}
	public long getTotalmoney() {
		return totalmoney;
	}
	public void setTotalmoney(long totalmoney) {
		this.totalmoney = totalmoney;
	}
	public String getItem() {
		return item;
	}
	public void setItem(String item) {
		this.item = item;
	}
	public String getOnsite() {
		return onsite;
	}
	public void setOnsite(String onsite) {
		this.onsite = onsite;
	}
	public String getTransactionaccount() {
		return transactionaccount;
	}
	public void setTransactionaccount(String transactionaccount) {
		this.transactionaccount = transactionaccount;
	}
	public String getAccountholder() {
		return accountholder;
	}
	public void setAccountholder(String accountholder) {
		this.accountholder = accountholder;
	}
	public String getBank() {
		return bank;
	}
	public void setBank(String bank) {
		this.bank = bank;
	}
	public long getPayment() {
		return payment;
	}
	public void setPayment(long payment) {
		this.payment = payment;
	}
	public long getArrear() {
		return arrear;
	}
	public void setArrear(long arrear) {
		this.arrear = arrear;
	}
	public String getWhether() {
		return whether;
	}
	public void setWhether(String whether) {
		this.whether = whether;
	}
	public String getGivedate() {
		return givedate;
	}
	public void setGivedate(String givedate) {
		this.givedate = givedate;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public String getDivision() {
		return division;
	}
	public void setDivision(String division) {
		this.division = division;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	public String getDepositdate_One() {
		return depositdate_One;
	}
	public void setDepositdate_One(String depositdate_One) {
		this.depositdate_One = depositdate_One;
	}
	public String getReceipts_One() {
		return receipts_One;
	}
	public void setReceipts_One(String receipts_One) {
		this.receipts_One = receipts_One;
	}
	public long getDeposit_One() {
		return deposit_One;
	}
	public void setDeposit_One(long deposit_One) {
		this.deposit_One = deposit_One;
	}
	public String getDepositdate_Two() {
		return depositdate_Two;
	}
	public void setDepositdate_Two(String depositdate_Two) {
		this.depositdate_Two = depositdate_Two;
	}
	public String getReceipts_Two() {
		return receipts_Two;
	}
	public void setReceipts_Two(String receipts_Two) {
		this.receipts_Two = receipts_Two;
	}
	public long getDeposit_Two() {
		return deposit_Two;
	}
	public void setDeposit_Two(long deposit_Two) {
		this.deposit_Two = deposit_Two;
	}
	public String getDepositdate_Three() {
		return depositdate_Three;
	}
	public void setDepositdate_Three(String depositdate_Three) {
		this.depositdate_Three = depositdate_Three;
	}
	public String getReceipts_Three() {
		return receipts_Three;
	}
	public void setReceipts_Three(String receipts_Three) {
		this.receipts_Three = receipts_Three;
	}
	public long getDeposit_Three() {
		return deposit_Three;
	}
	public void setDeposit_Three(long deposit_Three) {
		this.deposit_Three = deposit_Three;
	}
	public String getDepositdate_Four() {
		return depositdate_Four;
	}
	public void setDepositdate_Four(String depositdate_Four) {
		this.depositdate_Four = depositdate_Four;
	}
	public String getReceipts_Four() {
		return receipts_Four;
	}
	public void setReceipts_Four(String receipts_Four) {
		this.receipts_Four = receipts_Four;
	}
	public long getDeposit_Four() {
		return deposit_Four;
	}
	public void setDeposit_Four(long deposit_Four) {
		this.deposit_Four = deposit_Four;
	}
	public String getDepositdate_Five() {
		return depositdate_Five;
	}
	public void setDepositdate_Five(String depositdate_Five) {
		this.depositdate_Five = depositdate_Five;
	}
	public String getReceipts_Five() {
		return receipts_Five;
	}
	public void setReceipts_Five(String receipts_Five) {
		this.receipts_Five = receipts_Five;
	}
	public long getDeposit_Five() {
		return deposit_Five;
	}
	public void setDeposit_Five(long deposit_Five) {
		this.deposit_Five = deposit_Five;
	}
	public String getDepositdate_Six() {
		return depositdate_Six;
	}
	public void setDepositdate_Six(String depositdate_Six) {
		this.depositdate_Six = depositdate_Six;
	}
	public String getReceipts_Six() {
		return receipts_Six;
	}
	public void setReceipts_Six(String receipts_Six) {
		this.receipts_Six = receipts_Six;
	}
	public long getDeposit_Six() {
		return deposit_Six;
	}
	public void setDeposit_Six(long deposit_Six) {
		this.deposit_Six = deposit_Six;
	}
	public String getDepositdate_Seven() {
		return depositdate_Seven;
	}
	public void setDepositdate_Seven(String depositdate_Seven) {
		this.depositdate_Seven = depositdate_Seven;
	}
	public String getReceipts_Seven() {
		return receipts_Seven;
	}
	public void setReceipts_Seven(String receipts_Seven) {
		this.receipts_Seven = receipts_Seven;
	}
	public long getDeposit_Seven() {
		return deposit_Seven;
	}
	public void setDeposit_Seven(long deposit_Seven) {
		this.deposit_Seven = deposit_Seven;
	}
	
	
	
	
}
