package model;

public class BarChartP_VO {
	long barP_Sum;
	String bar_Date;
	public BarChartP_VO(long barP_Sum, String bar_Date) {
		super();
		this.barP_Sum = barP_Sum;
		this.bar_Date = bar_Date;
	}
	public BarChartP_VO() {
		super();
	}
	public long getBarP_Sum() {
		return barP_Sum;
	}
	public void setBarP_Sum(long barP_Sum) {
		this.barP_Sum = barP_Sum;
	}
	public String getBar_Date() {
		return bar_Date;
	}
	public void setBar_Date(String bar_Date) {
		this.bar_Date = bar_Date;
	}
	
	
	
}
