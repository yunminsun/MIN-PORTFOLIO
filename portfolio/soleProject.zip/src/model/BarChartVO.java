package model;

public class BarChartVO {
	long barS_Sum;
	String barS_Date;
	public BarChartVO(long barS_Sum, String barS_Date) {
		super();
		this.barS_Sum = barS_Sum;
		this.barS_Date = barS_Date;
	}
	public BarChartVO() {
		super();
	}
	public long getBarS_Sum() {
		return barS_Sum;
	}
	public void setBarS_Sum(long barS_Sum) {
		this.barS_Sum = barS_Sum;
	}
	public String getBarS_Date() {
		return barS_Date;
	}
	public void setBarS_Date(String barS_Date) {
		this.barS_Date = barS_Date;
	}
	
	
	
	
	
	
	
}
